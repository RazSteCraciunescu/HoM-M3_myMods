# Version and Reference Notes

This starter was prepared for the VCMI 1.7 generation and checked against public VCMI documentation/source examples available on 2026-08-29.

Primary project references:

```text
VCMI home and downloads:
https://vcmi.eu/

VCMI source:
https://github.com/vcmi/vcmi

VCMI documentation:
https://vcmi.eu/developers/Modding/

VCMI HotA content port:
https://github.com/vcmi-mods/horn-of-the-abyss
```

Configuration patterns were based on current VCMI core/mod definitions for creatures, factions, heroes, spells, artifacts, and war machines, including the existing Unicorn Blind, Mighty Gorgon Death Stare, creature casting, Ballista/Catapult, and HotA Cannon patterns.

The VCMI engine log and the exact source/configuration shipped with the installed version remain the final authority. When moving to VCMI 1.8 or later, compare schemas and examples before changing the package compatibility field.

No third-party executables, Heroes III data, HotA assets, WoG assets, or community artwork are redistributed here.
