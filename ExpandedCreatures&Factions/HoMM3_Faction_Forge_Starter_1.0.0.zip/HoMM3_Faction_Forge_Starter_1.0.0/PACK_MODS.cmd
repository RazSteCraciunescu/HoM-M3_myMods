@echo off
setlocal
set "SCRIPT=%~dp0tools\pack_mods.py"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%SCRIPT%" --root "%~dp0"
) else (
  python "%SCRIPT%" --root "%~dp0"
)
exit /b %errorlevel%
