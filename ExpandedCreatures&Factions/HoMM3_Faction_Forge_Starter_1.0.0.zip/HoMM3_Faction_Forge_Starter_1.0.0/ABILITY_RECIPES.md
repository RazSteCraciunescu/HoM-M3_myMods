# Creature ability recipes

These recipes use VCMI’s bonus/entity format. Add them inside a creature’s:

```json
"abilities": {
  ...
}
```

Every ability entry needs a unique local key such as `myFlying`, `myBlind`, or `myCasts`. The key is only your label; the `type`, `subtype`, `val`, and other fields define the mechanic.

Run `VALIDATE_ALL.cmd` after editing, but remember that only VCMI itself can validate whether a particular bonus combination is semantically supported.

## Unicorn-style Blind after attack

```json
"blinds": {
  "type": "SPELL_AFTER_ATTACK",
  "subtype": "blind",
  "val": 20,
  "addInfo": [
    3,
    0
  ]
}
```

Use the original Unicorn pattern first. Change `val` only after confirming it works.

## Mighty Gorgon-style Death Stare

```json
"deathStare": {
  "type": "COMBAT_EVENT_TRIGGER",
  "subtype": "deathStare",
  "val": 10,
  "addInfo": {
    "situation": "melee"
  }
}
```

This calls the original-style Death Stare handler. The handler can incorporate stack-size/original-mechanic rules; `val` should not automatically be described as a flat independent percentage.

## Creature spell casting

```json
"spellpower": {
  "type": "CREATURE_SPELL_POWER",
  "val": 6
},
"castsYourSpell": {
  "type": "SPELLCASTER",
  "subtype": "spell.yourSpellId",
  "val": 2
},
"castsCount": {
  "type": "CASTS",
  "val": 1
}
```

- Change `yourSpellId` to the spell ID in a config listed under `spells` in `mod.json`.
- `val: 1` on `CASTS` means one use per combat.
- The spell must have `type: "ability"` if it is intended only as a creature ability and should not appear normally in mage guilds.

## Shooter

```json
"shooter": {
  "type": "SHOOTER"
}
```

A shooter also needs:

```json
"shots": 12
```

and a shooting-capable battle animation/projectile configuration. Adding `SHOOTER` to a DEF with no proper shooting groups can produce missing or incorrect animation.

## No distance penalty

```json
"noDistancePenalty": {
  "type": "NO_DISTANCE_PENALTY"
}
```

## No wall penalty

```json
"noWallPenalty": {
  "type": "NO_WALL_PENALTY"
}
```

## No retaliation

```json
"noRetaliation": {
  "type": "NO_RETALIATION"
}
```

## Block ranged retaliation

```json
"blocksRangedRetaliation": {
  "type": "BLOCKS_RANGED_RETALIATION"
}
```

## Flying

```json
"flying": {
  "type": "FLYING"
}
```

A correct flying animation should visually support the movement. This does not grant siege-wall bypass semantics beyond the engine’s normal flying rules.

## Undead

```json
"undead": {
  "type": "UNDEAD"
}
```

This affects morale, resurrection/healing interactions, and other mechanics that check undead status.

## Spell-resistance aura like Unicorns

```json
"spellResistAura": {
  "type": "SPELL_RESISTANCE_AURA",
  "val": 20
}
```

## Siege-weapon identity

```json
"siegeWeapon": {
  "type": "SIEGE_WEAPON"
}
```

This is part of defining war machines. It is not enough by itself to create an equippable machine; an artifact must point to the creature through `warMachine`.

## CPU-controlled war machine

```json
"cpuControlled": {
  "type": "CPU_CONTROLLED"
}
```

Whether a hero skill permits manual control depends on the associated war-machine logic and skills.

## Catapult-style wall attack

```json
"catapult": {
  "type": "CATAPULT",
  "subtype": "catapultShot"
}
```

This connects the creature to the existing Catapult shot spell/handler. A custom siege-shot spell can be defined, but a Ram that physically approaches and strikes a wall is not the same mechanic and needs more than this data block.

## First Aid Tent-style healing

```json
"heals": {
  "type": "HEALER",
  "subtype": "firstAid"
}
```

A Battle Horn that buffs the army is not a direct replacement for this bonus. Create the Horn as a separate war-machine creature/artifact and implement the aura or combat-start effect; do not rename `HEALER` and expect it to become a buff.

## Ammo Cart-style inactive support machine

```json
"inactive": {
  "type": "NOT_ACTIVE"
}
```

The actual unlimited-ammunition effect is supplied by the engine’s Ammo Cart behavior/context, not simply by this line for every arbitrary machine.

## Ability descriptions and icons

Many bonuses can include:

```json
"description": "{Ability Name}\nLong description shown in the creature window.",
"icon": "yourNamespace/abilities/yourIcon.png"
```

Place the icon under:

```text
Content\data\yourNamespace\abilities\yourIcon.png
```

Support for display details varies by bonus type.

## Combining abilities safely

A practical sequence is:

1. Start with the creature clone and no new abilities.
2. Add one known bonus.
3. Test battle AI and manual combat.
4. Add the next bonus.
5. Test retaliation, morale/luck, spell immunity, quick combat, siege, and multiplayer separately.

A combination can be valid JSON yet still create unexpected ordering. For example, Death Stare, Blind-after-attack, multiple attacks, and no retaliation all interact after or around the same attack sequence.

## When an ability needs Lua or C++ instead

Use Lua/combat scripts when the requirement reads like an event rule:

```text
When this creature lands a melee hit, if the target is living and not immune,
create a disease effect on adjacent hexes for three rounds.
```

Use C++ when the requirement needs a new engine concept:

```text
This unit creates a ladder object attached to a wall segment and changes which
hexes are reachable for every allied walker until the ladder is destroyed.
```

See `LIMITS_ENGINE_EXTENSIONS.md`.
