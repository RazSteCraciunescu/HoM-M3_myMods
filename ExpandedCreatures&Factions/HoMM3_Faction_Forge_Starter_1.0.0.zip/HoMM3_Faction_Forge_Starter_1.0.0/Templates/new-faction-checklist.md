# New Faction Checklist

## Identity

- [ ] Unique stable faction ID
- [ ] Display name and description
- [ ] Alignment
- [ ] Native terrain
- [ ] Town-name list
- [ ] Mod metadata/version/author
- [ ] Dependencies declared

## Creatures

- [ ] Seven base creatures
- [ ] Seven standard upgrades
- [ ] Upgrade links resolve
- [ ] Correct faction on each creature
- [ ] Stats/cost/growth/AI values
- [ ] Battle animations
- [ ] Adventure-map animations
- [ ] Small/large icons
- [ ] Sounds
- [ ] Ability descriptions
- [ ] Neutral/manual placement tests

## Town

- [ ] Seven-tier roster in correct order
- [ ] Dwelling and upgrade buildings
- [ ] Costs and prerequisites
- [ ] Hall slots
- [ ] Mage Guild level and spell layout
- [ ] Marketplace/resource silo
- [ ] Tavern and hero availability
- [ ] Blacksmith machine
- [ ] Special buildings
- [ ] Grail building
- [ ] Creature growth buildings
- [ ] Town scene background
- [ ] Building structures and click regions
- [ ] Construction icons
- [ ] Adventure-map town animations
- [ ] Selector icons
- [ ] Music/video/UI backgrounds
- [ ] Puzzle map

## Siege

- [ ] Background
- [ ] Gate and arch
- [ ] Moat and moat ability
- [ ] Walls
- [ ] Towers and battlements
- [ ] Shooter creature
- [ ] Placement coordinates
- [ ] Catapult/wall damage test
- [ ] Attacker and defender test

## Heroes

- [ ] Might class
- [ ] Magic class
- [ ] Starting primary skills
- [ ] Low/high-level growth chances
- [ ] Secondary-skill probabilities
- [ ] Map and battle animations
- [ ] Tavern chances
- [ ] Hero pool
- [ ] Portraits and specialties
- [ ] Starting armies/spells/skills
- [ ] Names and biographies

## Quality

- [ ] `VALIDATE_ALL.cmd` passes
- [ ] Clean VCMI log on load
- [ ] Map Editor placement
- [ ] New game faction selection
- [ ] Build every structure
- [ ] Recruit/upgrade every creature
- [ ] Normal battle
- [ ] Siege battle
- [ ] Autocombat
- [ ] AI player
- [ ] Save/load
- [ ] Multiplayer
- [ ] Other-mod compatibility
- [ ] Credits and asset permissions
- [ ] Release ZIP has one folder level before `mod.json`
