# Corpse Launcher / Disease Hazard Specification

## Player-visible rule

The Corpse Launcher fires a diseased payload. On impact it deals damage and may infect units or contaminate nearby hexes for a limited number of rounds.

## Choose one initial scope

### Scope A: on-hit debuff

Apply an existing Attack/Defense/speed/morale penalty to the struck stack for N rounds.

### Scope B: impact area

Apply the debuff to stacks within a supported radius at impact.

### Scope C: persistent infected hexes

Create battlefield hazards that trigger damage/debuff on entry, turn start, or round end.

Start with A. Do not begin with C.

## Persistent-hazard engine needs

- hazard entity with owner/source/duration;
- occupied hex set;
- entry/exit/turn/round event hooks;
- visual loop and expiration animation;
- immunity and resistance rules;
- pathfinding/AI hazard cost;
- deterministic damage/effect rolls;
- save/load and multiplayer serialization;
- interaction with cleansing/dispel/fire/terrain if desired.

## Rules to decide

```text
Can it target empty hexes?
Does initial impact deal physical damage?
Which creatures are immune?
Can disease stack or refresh?
Does it affect both sides?
How long does contamination last?
Does movement through a tile trigger it?
Can it spread?
Can it be cleansed?
Can it damage walls or machines?
```

## First milestone

Create a Ballista-compatible shooter with custom art that applies one existing timed debuff to the directly hit stack. Prove AI, autocombat, save/load, and multiplayer before adding an area or persistent tiles.
