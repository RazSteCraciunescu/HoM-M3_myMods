# Escalade / Siege Ladder Engine Specification

## Player-visible rule

The attacker may place a limited number of ladders against eligible wall segments. Eligible infantry can cross at those segments while the ladder remains intact.

## Required engine capabilities

- ladder placement action and target UI;
- persistent battlefield ladder entity;
- mapping from wall side hex to interior side hex;
- dynamic passability/pathfinding edge;
- animation and click/hover feedback;
- unit eligibility rules;
- destruction/removal rules;
- AI placement and path use;
- deterministic multiplayer state;
- save/load serialization.

## Rules to decide before coding

```text
Who carries/deploys ladders?
How many per battle?
Does placement consume a turn?
Which wall segments are valid?
Can two-wide units use them?
Can flying/teleporting units interact?
Can defenders push them down?
Can ranged attacks destroy them?
Does the wall need to be intact?
What happens when a unit is crossing as the ladder is destroyed?
```

## First milestone

On one fixed wall segment of one test siege battlefield, toggle one pathfinding connection via a debug action. Do not build production art or generalized placement until deterministic movement works for human and AI turns.
