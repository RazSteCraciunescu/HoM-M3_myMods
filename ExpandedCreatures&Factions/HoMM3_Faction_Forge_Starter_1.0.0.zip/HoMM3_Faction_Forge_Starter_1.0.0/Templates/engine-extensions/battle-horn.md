# Battle Horn Specification

## Player-visible rule

A support war machine strengthens allied stacks instead of healing. Proposed starter effect: all allied living creatures receive +2 Attack while the Horn is present.

## Implementation levels

### Level 1: passive existing bonus

Use an existing propagated Attack/Defense bonus if the engine can attach it to the machine and scope it to allied stacks.

### Level 2: battle-start script

At battle start, detect the equipped Horn and apply a timed/per-battle existing bonus to valid allies.

### Level 3: active once-per-combat Horn blast

Add an action button/AI action, animation, sound, one charge, valid targets, and duration.

### Level 4: destruction-aware aura

Remove the effect when the Horn is destroyed and restore it correctly after save/load.

## Rules to decide

```text
Attack, Defense, damage, morale, or combination?
Living creatures only?
Does it affect undead, constructs, summons, war machines?
Passive or activated?
Duration?
Can it be dispelled?
Does destruction remove the buff?
Which machine slot?
How does it interact with duplicate bonuses?
```

## Test cases

- no Horn;
- Horn present;
- Horn destroyed before/after activation;
- undead and constructs;
- summoned stacks;
- dispel/anti-magic;
- autocombat and AI;
- save/load;
- multiplayer;
- two allied Horn effects.
