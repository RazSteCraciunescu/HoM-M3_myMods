# Engine Extension Design Notes

These files are design specifications, not active JSON mods and not pretend drop-in C++ patches.

Use them before changing the VCMI engine. A good specification should separate:

- content data that remains in the mod;
- reusable engine capability;
- battle action/state changes;
- UI and input;
- AI;
- save/load and multiplayer;
- test cases.

Prefer a general engine hook that other mods can reuse over hardcoding one faction or one asset name into the engine.
