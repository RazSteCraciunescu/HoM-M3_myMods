# Siege Ram Engine Specification

## Player-visible rule

An attacking hero equipped with a Ram may deploy it in sieges. The Ram approaches a valid gate or wall target and performs a close-range strike. It cannot attack normal creature stacks unless explicitly designed to do so.

## Minimal data fields

```text
war-machine creature ID
artifact ID and slot
movement speed or deployment position
valid target types: gate / wall segment
base wall damage
skill scaling
strike cooldown or action frequency
animation resources
sounds
```

## Required engine capabilities

- identify siege wall/gate components as selectable targets;
- create a Ram-specific action rather than a ranged projectile;
- reserve/validate a legal position adjacent to the target;
- animate approach/strike/return or persistent position;
- apply deterministic wall damage;
- handle destroyed target and invalidated path;
- AI target scoring;
- save/load current target, position, and cooldown;
- multiplayer action serialization;
- combat log and targeting feedback.

## Edge cases

- no fortifications;
- gate already destroyed/open;
- chosen wall destroyed before the Ram acts;
- no reachable adjacent position;
- Ram blocked by creatures/obstacles;
- teleport/displacement effects;
- machine destroyed mid-action;
- multiple Rams;
- autocombat;
- battle replay/save restoration.

## First milestone

Implement a siege-only machine that is deployed at a fixed valid hex and can strike only the gate once per round using placeholder art. Add movement only after target selection, damage, AI, save/load, and multiplayer are stable.
