#!/usr/bin/env python3
"""Static validator for the Faction Forge starter mods.

This catches malformed JSON, missing files, duplicate entity IDs, and obvious
required-field mistakes. It does not replace launching VCMI, whose own schemas
and logs remain the final authority.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable

CONFIG_SECTIONS = {
    "creatures", "spells", "factions", "heroClasses", "heroes", "artifacts",
    "objects", "skills", "battlefields", "terrains", "rivers", "roads",
    "obstacles", "biomes"
}
ASSET_KEYS = {
    "animation", "editorAnimation", "map", "iconSmall", "iconLarge", "image",
    "scenarioBonus", "projectile", "campaignBonus", "border", "area",
    "guildBackground", "townBackground", "guildWindow", "buildingsIcons",
    "hallBackground", "creatureBackground", "affect", "cast", "attack",
    "defend", "killed", "move", "wince", "shoot"
}
LOCAL_PREFIXES = ("factionforge/", "yourNamespace/")
CONTENT_ROOTS = ("data", "sprites", "sounds", "music", "video", "maps", "config")


class Results:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.passes: list[str] = []

    def error(self, message: str) -> None:
        self.errors.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)

    def ok(self, message: str) -> None:
        self.passes.append(message)


def read_json(path: Path, results: Results) -> Any | None:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except json.JSONDecodeError as exc:
        results.error(f"{path}: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}")
    except OSError as exc:
        results.error(f"{path}: cannot read file: {exc}")
    return None


def find_case_insensitive(root: Path, rel: str) -> Path | None:
    parts = Path(rel.replace("\\", "/")).parts
    current = root
    for part in parts:
        if not current.is_dir():
            return None
        direct = current / part
        if direct.exists():
            current = direct
            continue
        lowered = part.lower()
        match = next((p for p in current.iterdir() if p.name.lower() == lowered), None)
        if match is None:
            return None
        current = match
    return current


def resolve_content_asset(mod_dir: Path, asset: str) -> Path | None:
    clean = asset.split(":", 1)[0].replace("\\", "/")
    content = mod_dir / "Content"
    for root_name in CONTENT_ROOTS:
        found = find_case_insensitive(content / root_name, clean)
        if found and found.is_file():
            return found
    # Allow extensionless references by trying common VCMI formats.
    if not Path(clean).suffix:
        for extension in (".json", ".png", ".bmp", ".pcx", ".def", ".wav", ".ogg"):
            for root_name in CONTENT_ROOTS:
                found = find_case_insensitive(content / root_name, clean + extension)
                if found and found.is_file():
                    return found
    return None


def walk_assets(node: Any, key: str | None = None) -> Iterable[tuple[str, str]]:
    if isinstance(node, dict):
        for child_key, value in node.items():
            if child_key in ASSET_KEYS:
                if isinstance(value, str):
                    yield child_key, value
                elif isinstance(value, list):
                    for item in value:
                        if isinstance(item, str):
                            yield child_key, item
                elif isinstance(value, dict):
                    yield from walk_assets(value, child_key)
            else:
                yield from walk_assets(value, child_key)
    elif isinstance(node, list):
        for value in node:
            yield from walk_assets(value, key)


def validate_animation_json(path: Path, mod_dir: Path, results: Results) -> None:
    data = read_json(path, results)
    if not isinstance(data, dict):
        return
    basepath = data.get("basepath")
    sequences = data.get("sequences")
    if not isinstance(basepath, str) or not isinstance(sequences, list):
        results.error(f"{path}: animation JSON requires string 'basepath' and list 'sequences'")
        return
    for seq_index, sequence in enumerate(sequences):
        if not isinstance(sequence, dict) or not isinstance(sequence.get("frames"), list):
            results.error(f"{path}: sequence {seq_index} requires a frames list")
            continue
        for frame in sequence["frames"]:
            if not isinstance(frame, str):
                results.error(f"{path}: non-string animation frame in sequence {seq_index}")
                continue
            asset = basepath.rstrip("/") + "/" + frame
            if resolve_content_asset(mod_dir, asset) is None:
                results.error(f"{path}: missing animation frame '{asset}'")


def require_fields(entity_type: str, entity_id: str, entity: Any, source: Path, results: Results) -> None:
    if not isinstance(entity, dict):
        results.error(f"{source}: {entity_type} '{entity_id}' must be an object")
        return
    requirements: dict[str, tuple[str, ...]] = {
        "creatures": ("name", "level", "faction", "attack", "defense", "hitPoints", "speed", "damage", "graphics"),
        "spells": ("type", "name", "targetType", "levels"),
        "factions": ("name", "alignment", "nativeTerrain", "creatureBackground"),
        "heroClasses": ("name", "faction", "affinity", "primarySkills", "lowLevelChance", "highLevelChance", "secondarySkills"),
        "heroes": ("class", "images", "texts", "army"),
        "artifacts": ("type", "class", "text", "graphics"),
    }
    for field in requirements.get(entity_type, ()):
        if field not in entity:
            results.error(f"{source}: {entity_type} '{entity_id}' is missing required starter field '{field}'")

    if entity_type == "creatures":
        damage = entity.get("damage")
        if isinstance(damage, dict):
            if damage.get("min", 0) > damage.get("max", 0):
                results.error(f"{source}: creature '{entity_id}' has damage.min greater than damage.max")
        if entity.get("level", 0) < 0:
            results.error(f"{source}: creature '{entity_id}' has a negative level")
    elif entity_type == "factions":
        if "town" not in entity:
            results.warn(f"{source}: faction '{entity_id}' has no town and is therefore a non-town faction")
    elif entity_type == "heroes":
        images = entity.get("images")
        if isinstance(images, dict):
            for field in ("large", "small", "specialtyLarge", "specialtySmall"):
                if field not in images:
                    results.error(f"{source}: hero '{entity_id}' images missing '{field}'")


def validate_mod(mod_dir: Path, results: Results) -> None:
    mod_json_path = mod_dir / "mod.json"
    if not mod_json_path.is_file():
        results.error(f"{mod_dir}: missing mod.json")
        return
    manifest = read_json(mod_json_path, results)
    if not isinstance(manifest, dict):
        return
    for field in ("name", "description", "version", "modType"):
        if not manifest.get(field):
            results.error(f"{mod_json_path}: missing manifest field '{field}'")

    seen_by_section: dict[str, set[str]] = {}
    config_files: list[tuple[str, Path]] = []
    for section in CONFIG_SECTIONS:
        entries = manifest.get(section, [])
        if entries is None:
            continue
        if not isinstance(entries, list):
            results.error(f"{mod_json_path}: '{section}' must be a list")
            continue
        for rel in entries:
            if not isinstance(rel, str):
                results.error(f"{mod_json_path}: non-string entry in '{section}'")
                continue
            config_path = mod_dir / "Content" / rel
            if not config_path.is_file():
                results.error(f"{mod_json_path}: listed {section} file does not exist: Content/{rel}")
                continue
            config_files.append((section, config_path))

    for section, config_path in config_files:
        data = read_json(config_path, results)
        if not isinstance(data, dict):
            results.error(f"{config_path}: top level must be an object")
            continue
        seen = seen_by_section.setdefault(section, set())
        for entity_id, entity in data.items():
            if entity_id in seen:
                results.error(f"{config_path}: duplicate {section} ID '{entity_id}' inside the same mod namespace")
            seen.add(entity_id)
            require_fields(section, entity_id, entity, config_path, results)
        for asset_key, asset in walk_assets(data):
            if asset.startswith(LOCAL_PREFIXES):
                resolved = resolve_content_asset(mod_dir, asset)
                if resolved is None:
                    results.error(f"{config_path}: local asset in '{asset_key}' not found: {asset}")
                elif resolved.suffix.lower() == ".json" and "sprites" in resolved.parts:
                    validate_animation_json(resolved, mod_dir, results)

    # Validate every sprite JSON, including ones only reached through another JSON.
    for animation in (mod_dir / "Content" / "sprites").rglob("*.json") if (mod_dir / "Content" / "sprites").exists() else []:
        validate_animation_json(animation, mod_dir, results)

    results.ok(f"{mod_dir.name}: manifest and {len(config_files)} listed config files passed static checks")


def main() -> int:
    parser = argparse.ArgumentParser(description="Static validator for VCMI starter mods")
    parser.add_argument("mods_dir", nargs="?", default=str(Path(__file__).resolve().parents[1] / "Mods"))
    args = parser.parse_args()
    mods_dir = Path(args.mods_dir).resolve()
    results = Results()

    if not mods_dir.is_dir():
        print(f"ERROR: Mods directory not found: {mods_dir}")
        return 2

    mod_dirs = sorted(p for p in mods_dir.iterdir() if p.is_dir())
    if not mod_dirs:
        print(f"ERROR: No mod folders found in {mods_dir}")
        return 2
    for mod_dir in mod_dirs:
        validate_mod(mod_dir, results)

    print("\nSTATIC VALIDATION REPORT")
    print("=" * 72)
    for message in results.passes:
        print(f"PASS  {message}")
    for message in results.warnings:
        print(f"WARN  {message}")
    for message in results.errors:
        print(f"ERROR {message}")
    print("-" * 72)
    print(f"Passes: {len(results.passes)}  Warnings: {len(results.warnings)}  Errors: {len(results.errors)}")
    if results.errors:
        print("Result: FAILED static validation")
        return 1
    print("Result: PASSED static validation")
    print("Next authority: VCMI Launcher plus VCMI_Client_log.txt / VCMI_Server_log.txt.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
