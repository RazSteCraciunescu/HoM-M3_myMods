#!/usr/bin/env python3
"""Create a new editable VCMI creature mod without third-party Python packages."""
from __future__ import annotations

import argparse
import json
import re
import struct
import zlib
from pathlib import Path


def safe_id(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value):
        raise argparse.ArgumentTypeError("ID must start with a letter and contain only letters, numbers, and underscore")
    return value


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def write_png(path: Path, width: int, height: int, seed: int = 0) -> None:
    """Write a small RGBA PNG using only Python's standard library."""
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for y in range(height):
        row = bytearray([0])
        for x in range(width):
            edge = x in (0, width - 1) or y in (0, height - 1)
            cx, cy = width / 2, height / 2
            body = ((x - cx) / max(1, width * .34)) ** 2 + ((y - cy) / max(1, height * .27)) ** 2 < 1
            if edge:
                rgba = (190, 135, 220, 255)
            elif body:
                rgba = (55 + seed % 40, 30, 75 + seed % 50, 255)
            else:
                rgba = (0, 0, 0, 0)
            row.extend(rgba)
        rows.append(bytes(row))
    raw = b"".join(rows)
    def chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    path.write_bytes(png)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a minimal editable VCMI creature mod")
    parser.add_argument("--id", required=True, type=safe_id, help="camelCase or underscore identifier")
    parser.add_argument("--name", required=True, help="Singular display name")
    parser.add_argument("--plural", help="Plural display name; defaults to NAME + s")
    parser.add_argument("--faction", default="neutral")
    parser.add_argument("--level", type=int, default=4)
    parser.add_argument("--base", choices=("unicorn", "war-unicorn", "ballista"), default="unicorn")
    parser.add_argument("--output", default=str(Path(__file__).resolve().parents[1] / "Mods"))
    args = parser.parse_args()

    plural = args.plural or args.name + "s"
    mod_id = "factionforge-" + re.sub(r"_", "-", args.id.lower())
    output = Path(args.output).resolve()
    mod = output / mod_id
    if mod.exists():
        print(f"ERROR: destination already exists: {mod}")
        return 2

    prefix = f"factionforge/generated/{args.id}"
    icon_small = f"{prefix}/small.png"
    icon_large = f"{prefix}/large.png"
    map_path = f"{prefix}/map/map.json"
    write_png(mod / "Content" / "data" / icon_small, 32, 32, 1)
    write_png(mod / "Content" / "data" / icon_large, 58, 64, 2)
    frames = []
    for i in range(4):
        frame = f"frame_{i}.png"
        write_png(mod / "Content" / "sprites" / prefix / "map" / frame, 64, 64, i)
        frames.append(frame)
    write_json(mod / "Content" / "sprites" / prefix / "map" / "map.json", {
        "basepath": f"{prefix}/map/",
        "sequences": [{"group": 0, "frames": frames, "generateShadow": 2, "generateOverlay": 1}]
    })

    if args.base == "ballista":
        animation, sounds, double_wide = "SMBAL.DEF", {"killed":"BALLKILL.wav","shoot":"BALLSHOT.wav","wince":"BALLWNCE.wav"}, True
        abilities = {"shooter":{"type":"SHOOTER"}}
    else:
        upgraded = args.base == "war-unicorn"
        animation = "CWUNIC.DEF" if upgraded else "CUNICO.DEF"
        prefix_sound = "WUNC" if upgraded else "UNIC"
        sounds = {"attack":prefix_sound+"ATTK.wav","defend":prefix_sound+"DFND.wav","killed":prefix_sound+"KILL.wav","move":prefix_sound+"MOVE.wav","wince":prefix_sound+"WNCE.wav"}
        double_wide = True
        abilities = {}

    creature = {
        args.id: {
            "name": {"singular": args.name, "plural": plural},
            "level": args.level, "special": False, "faction": args.faction,
            "cost": {"gold": 500}, "fightValue": 700, "aiValue": 750,
            "growth": 4, "attack": 10, "defense": 10, "hitPoints": 40, "speed": 7,
            "damage": {"min": 7, "max": 10}, "horde": 3, "spellPoints": 0,
            "advMapAmount": {"min": 8, "max": 15}, "doubleWide": double_wide,
            "abilities": abilities,
            "graphics": {"animation": animation, "map": map_path, "iconSmall": icon_small, "iconLarge": icon_large},
            "sound": sounds
        }
    }
    write_json(mod / "Content" / "config" / "factionforge" / f"{args.id}.json", creature)
    write_json(mod / "mod.json", {
        "name": f"Faction Forge - {args.name}",
        "description": f"Generated editable creature mod for {args.name}.",
        "author": "Faction Forge generator", "version": "0.1.0", "modType": "Creatures",
        "compatibility": {"min": "1.7.0"},
        "creatures": [f"config/factionforge/{args.id}.json"]
    })
    print(f"Created: {mod}")
    print("Next: edit its creature JSON, run VALIDATE_ALL.cmd, copy it to the VCMI Mods folder, and enable it in VCMI Launcher.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
