#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Package each VCMI mod as a separate ZIP")
    root_default = Path(__file__).resolve().parents[1]
    parser.add_argument("--root", default=str(root_default))
    args = parser.parse_args()
    root = Path(args.root).resolve()
    mods = root / "Mods"
    ready = root / "Ready-to-install"
    ready.mkdir(parents=True, exist_ok=True)
    if not mods.is_dir():
        print(f"ERROR: missing Mods folder: {mods}")
        return 2
    count = 0
    for mod in sorted(p for p in mods.iterdir() if p.is_dir()):
        target_base = ready / mod.name
        archive = target_base.with_suffix(".zip")
        if archive.exists():
            archive.unlink()
        shutil.make_archive(str(target_base), "zip", root_dir=mods, base_dir=mod.name)
        print(f"Created {archive.name}")
        count += 1
    print(f"Packaged {count} mod(s) into {ready}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
