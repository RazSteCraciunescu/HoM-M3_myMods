# Limits, Scripts, and C++ Engine Extensions

## 1. Why this package does not patch native HotA

The native Horn of the Abyss executable is a finished expansion, not a publicly documented general-purpose SDK for arbitrary third-party town slots, creature IDs, combat actions, and siege systems. A binary patch tied to one exact executable version would be fragile and could break after an update.

This package therefore targets VCMI, where entity data is mod-defined and the engine source is available. You can still install the maintained VCMI HotA content port for a HotA-oriented game setup.

## 2. Decide the implementation layer

| Idea | First implementation layer | Why |
|---|---|---|
| New creature with changed stats | JSON | Existing creature schema. |
| Clone Unicorn and replace art/sounds | JSON + assets | Existing animation/sound hooks. |
| Blind or Death Stare | JSON | Existing bonus/event handlers. |
| One cast per battle | JSON | `SPELLCASTER`, `CASTS`, and supported spell effects. |
| New direct-damage ability spell | JSON | Existing spell effect. |
| New faction using existing town art | JSON | Existing faction/town schema. |
| Original town screen and siege art | JSON + substantial assets/coordinates | Existing systems, large art workload. |
| Ballista-like Glaive Thrower | JSON + assets | Existing war-machine behavior. |
| Battle-start allied bonus Horn | Existing bonus or Lua first | Depends on propagation/event conditions. |
| On-hit disease debuff | Existing spell/bonus or Lua | Existing effects may be sufficient. |
| Persistent infected battlefield hexes | Lua if hooks suffice; otherwise C++ | Needs persistent battlefield state/events/visuals. |
| Physical gate Ram | C++ | New siege action, targeting, AI, animation/state. |
| Ladder crossing walls | C++ | Changes pathfinding/passability and siege state. |
| A brand-new equipment machine slot | C++ + UI/save/network | Engine and interface model change. |
| Completely new secondary-skill effect | Lua or C++ | New rule and AI evaluation. |

## 3. Do not fake unsupported mechanics

Changing an entity's name and icon does not change its handler.

Examples:

- A renamed Ballista still uses Ballista targeting.
- A renamed First Aid Tent still uses its healing behavior unless its actual effect changes.
- A Catapult sprite shaped like a Ram still performs Catapult actions.
- A static ladder image does not make wall hexes passable.
- A projectile impact animation does not create a persistent disease tile.

Prototypes are useful, but label them by the mechanics they truly implement.

## 4. When to use Lua or scripting

Use scripting when the required event hooks already exist and the mechanic can be expressed without changing core pathfinding, UI protocol, serialization, or targeting models.

Good candidates:

- apply an existing bonus at battle start;
- react to a stack taking damage;
- limited conditional spell effects;
- custom visit/reward logic for a map object;
- timed effects built from existing bonus types.

Before committing to Lua, verify the exact VCMI version's scripting API and events. APIs evolve, and examples written for another branch may not load unchanged.

## 5. When C++ is justified

Choose a C++ engine extension when the feature needs one or more of:

- new battle action type;
- new target-selection UI;
- pathfinding/passability changes;
- new persistent battlefield entity;
- new siege wall/gate state;
- new AI planning logic;
- network messages;
- save-format state;
- new bonus/effect handler unavailable to scripts;
- editor support for a new object model.

## 6. Safe C++ development workflow

Do not modify your only VCMI installation directly.

1. Install and confirm an unmodified stable VCMI build works with your game data.
2. Fork or clone the official VCMI source repository.
3. Check out the tag matching the stable version you intend to support.
4. Follow the official build instructions for that exact tag and platform.
5. Build and launch the unmodified source first.
6. Create a feature branch, for example:

```text
feature/siege-ram
```

7. Write the mechanic as a small technical specification before coding.
8. Identify all affected layers: data schema, client UI, battle server/state, AI, serialization, map editor, tests.
9. Add one minimal mechanic with placeholder art.
10. Add automated tests where the project supports them.
11. Test single-player, AI, save/load, and multiplayer.
12. Keep content data in a separate mod so art/balance can change without rebuilding the engine.
13. Rebase/merge carefully when moving to a newer VCMI release.

The exact compiler/dependency commands must come from the official build page for the checked-out version. Copying old build commands into a current branch is a common source of wasted time.

## 7. Engine feature specification template

Before coding a new mechanic, answer:

```text
Feature name:
Player-visible rule:
When it is available:
Who selects the action:
Valid targets:
Invalid targets:
Resources/charges/cooldown:
Animation sequence:
Damage/effect formula:
How it interacts with walls/obstacles:
How it interacts with spells/skills/artifacts:
What happens when destroyed:
AI decision rule:
Autocombat rule:
Save/load state:
Multiplayer synchronization:
Map Editor representation:
Backward compatibility:
Failure/fallback behavior:
```

The `Templates/engine-extensions` folder applies this to your Ram, Escalade, Battle Horn, and Corpse Launcher ideas.

## 8. Multiplayer and save compatibility

A custom C++ mechanic that works locally can still desynchronize multiplayer or corrupt/reject saves.

Treat these as required features, not final polish:

- deterministic results for all clients;
- serialized action parameters;
- serialized persistent state;
- version checks between clients;
- safe behavior when a content mod is missing;
- stable entity IDs;
- migration or explicit incompatibility for old saves.

## 9. Recommended project split

Keep three repositories/folders:

```text
vcmi-engine-fork       Only engine changes
factionforge-content   JSON, art, sounds, balance, maps
factionforge-tests     Test maps, expected results, regression checklist
```

This keeps legal game data out of source control and prevents content changes from becoming tangled with engine builds.

## 10. Native HotA experimental work

Binary reverse engineering can be a legitimate personal learning exercise in some jurisdictions, but it is version-specific and raises compatibility, distribution, and licensing concerns. This starter does not provide executable patches, injected DLLs, bypasses, or redistributed game code.

For a maintainable creator-facing toolkit, implement features in VCMI or contribute generally useful engine hooks upstream rather than tying the project to one native HotA executable build.
