# Quick start: turn the included Unicorn clone into your creature

Work on the standalone creature first. Its folder is:

```text
Mods\factionforge-nightmare\
```

The main creature file is:

```text
Mods\factionforge-nightmare\Content\config\factionforge\nightmare.json
```

Use VS Code or Notepad++. Do not use Word.

## 1 — Change the displayed name

Find:

```json
"name": {
  "singular": "Nightmare",
  "plural": "Nightmares"
}
```

Replace both values. Keep the internal ID `nightmare` unchanged until your test map works. Display names can change safely; internal IDs are referenced by maps, saves, upgrades, spells, and other configs.

## 2 — Change tier, faction, price, growth, and stats

The important fields are:

```json
"level": 6,
"faction": "neutral",
"cost": {
  "gold": 950
},
"fightValue": 1650,
"aiValue": 1820,
"growth": 2,
"attack": 16,
"defense": 14,
"hitPoints": 100,
"speed": 9,
"damage": {
  "min": 18,
  "max": 25
},
"horde": 2
```

Meaning:

- `level` — creature tier. Normal town creatures generally use 1–7. Special/war-machine creatures can use 0 or other values supported by their design.
- `faction` — affiliation. Examples: `neutral`, `rampart`, `inferno`, or `dreadwood` when defined in the same enabled mod/dependency set.
- `cost` — resources paid per creature. You can add `wood`, `ore`, `mercury`, `sulfur`, `crystal`, and `gems` beside `gold`.
- `fightValue` — tactical value used in combat estimation.
- `aiValue` — strategic value used by AI and map calculations.
- `growth` — base weekly dwelling growth.
- `attack`, `defense`, `hitPoints`, `speed` — normal creature combat statistics.
- `damage.min` and `damage.max` — per-creature damage range.
- `horde` — amount used by several map-generation/stack-size calculations.

After every edit, save and run:

```text
VALIDATE_ALL.cmd
```

## 3 — Change the affiliation

### Neutral

```json
"faction": "neutral"
```

### Inferno

```json
"faction": "inferno"
```

This changes the creature’s faction identity. It does **not** automatically put the creature into Inferno’s seven-tier town roster. To recruit it from Inferno dwellings, you must also override/extend the Inferno faction definition or create a new town faction roster.

### Dreadwood

Inside the Dreadwood mod, use:

```json
"faction": "dreadwood"
```

If a separate mod references Dreadwood entities, add the correct mod dependency to its `mod.json`, for example:

```json
"depends": [
  "factionforge-dreadwood"
]
```

The precise dependency identifier shown by the launcher can include parent/submod namespaces for repository mods. For these manually installed top-level folders, the folder/mod identifier is the expected starting point.

## 4 — Change Death Stare

The included creature has:

```json
"deathStare": {
  "type": "COMBAT_EVENT_TRIGGER",
  "subtype": "deathStare",
  "val": 15,
  "addInfo": {
    "situation": "melee"
  },
  "description": "Death Stare: after a melee attack, has a chance to kill additional creatures."
}
```

Change:

```json
"val": 15
```

and test the result.

Important: VCMI’s `deathStare` subtype invokes the Mighty Gorgon-style handler. Its result can depend on stack size and the original Death Stare algorithm; `val` should be treated as that handler’s chance coefficient, not blindly described as a guaranteed flat “15% once per attack” in every circumstance. Start from the original-style value `10`, then test values such as `15`, `20`, and `25` on controlled stack sizes.

To limit it to ranged situations, another supported situation value would have to exist in the handler. The shipped example deliberately uses the known `melee` situation.

## 5 — Restore Unicorn Blind instead of Death Stare

Delete the entire `deathStare` object, including its comma placement, and add this inside `abilities`:

```json
"blinds": {
  "type": "SPELL_AFTER_ATTACK",
  "subtype": "blind",
  "val": 20,
  "addInfo": [
    3,
    0
  ],
  "description": "20% chance to cast Blind after an attack."
}
```

`val: 20` is the Unicorn-style chance value. The `addInfo` array is part of the existing Blind-after-attack configuration and should not be casually removed.

You can keep both Death Stare and Blind, but test carefully because multiple after-attack effects can produce much stronger balance than their individual numbers suggest.

## 6 — Change the once-per-combat cast

The creature currently has three related bonuses:

```json
"spellpower": {
  "type": "CREATURE_SPELL_POWER",
  "val": 6
},
"castsDreadHowl": {
  "type": "SPELLCASTER",
  "subtype": "spell.dreadHowl",
  "val": 2
},
"castsCount": {
  "type": "CASTS",
  "val": 1
}
```

Meaning:

- `CREATURE_SPELL_POWER val` — creature spell power used in the spell’s effect formula.
- `SPELLCASTER subtype` — spell the creature can cast.
- `SPELLCASTER val` — assumed mastery level. In the shipped sample, `2` is used for Advanced mastery.
- `CASTS val` — number of casts available to the stack per battle.

### One cast per battle

```json
"castsCount": {
  "type": "CASTS",
  "val": 1
}
```

### Three casts per battle

```json
"castsCount": {
  "type": "CASTS",
  "val": 3
}
```

### Remove casting entirely

Delete these three ability objects:

```text
spellpower
castsDreadHowl
castsCount
```

Remember to repair commas so the JSON remains valid.

## 7 — Change Dread Howl’s damage

Open:

```text
Mods\factionforge-nightmare\Content\config\factionforge\dreadHowl.json
```

The spell’s main scaling fields are:

```json
"power": 6
```

and the mastery-level values:

```json
"none": {
  "power": 6
},
"basic": {
  "power": 7
},
"advanced": {
  "power": 9
},
"expert": {
  "power": 11
}
```

The direct-damage effect is:

```json
"battleEffects": {
  "directDamage": {
    "type": "core:damage"
  }
}
```

The exact final damage uses the engine’s spell-effect formula, including caster spell power and the selected mastery level. Change one number at a time and compare the combat preview/result.

## 8 — Replace the battle sprite with an authorized WoG/community sprite

The included battle animation is only a reference to your original game data:

```json
"animation": "CUNICO.DEF"
```

### Example file names often associated with WoG assets

Commonly encountered WoG resource names include:

```text
Nightmare battle:   ZM172N.DEF
Nightmare map:      ZMM172N.DEF
Hell Steed battle:  ZM195Z.DEF
Hell Steed map:     ZMM195Z.DEF
```

Resource packs can rename files. Verify what your authorized source actually provides.

### Exact copy procedure

1. Obtain the sprite with a license or creator permission suitable for your use.
2. Create this folder:

   ```text
   Mods\factionforge-nightmare\Content\sprites\factionforge\nightmare\battle\
   ```

3. Copy the battle DEF there.
4. Rename it:

   ```text
   nightmare.def
   ```

5. If you also have a map DEF, place it here:

   ```text
   Mods\factionforge-nightmare\Content\sprites\factionforge\nightmare\map\nightmare.def
   ```

6. In `nightmare.json`, change:

   ```json
   "animation": "CUNICO.DEF"
   ```

   to:

   ```json
   "animation": "factionforge/nightmare/battle/nightmare.def"
   ```

7. Change:

   ```json
   "map": "factionforge/nightmare/map/map.json"
   ```

   to:

   ```json
   "map": "factionforge/nightmare/map/nightmare.def"
   ```

8. Save.
9. Run `VALIDATE_ALL.cmd`.
10. Run `INSTALL_TO_VCMI.cmd` again.
11. Test in Map Editor and battle.

If the DEF faces the wrong direction, has incorrect group numbers, bad palette transparency, or a shifted anchor, the asset itself needs conversion/fixing. See `ASSET_PIPELINE.md`.

## 9 — Replace sounds

Create:

```text
Mods\factionforge-nightmare\Content\sounds\factionforge\nightmare\
```

Copy legally usable sounds there, preferably short PCM WAV files, for example:

```text
attack.wav
defend.wav
die.wav
move.wav
wince.wav
```

Then change:

```json
"sound": {
  "attack": "factionforge/nightmare/attack.wav",
  "defend": "factionforge/nightmare/defend.wav",
  "killed": "factionforge/nightmare/die.wav",
  "move": "factionforge/nightmare/move.wav",
  "wince": "factionforge/nightmare/wince.wav"
}
```

VCMI searches sounds under the mod’s `Content/sounds` root.

## 10 — Create another creature without copying folders manually

From a Command Prompt opened in the starter folder:

```bat
py -3 tools\new_creature_mod.py --id shadowStag --name "Shadow Stag" --plural "Shadow Stags" --base unicorn --faction neutral --level 5
```

Other base presets:

```bat
py -3 tools\new_creature_mod.py --id blackCharger --name "Black Charger" --base war-unicorn --faction inferno --level 6
```

```bat
py -3 tools\new_creature_mod.py --id boltEngine --name "Bolt Engine" --base ballista --faction neutral --level 5
```

The generator creates a new mod under `Mods`, including placeholder icons and a map animation. It does not automatically add that new folder to `INSTALL_TO_VCMI.cmd`; copy it manually or add its folder name to the script’s `for %%M in (...)` list.

## 11 — Safe edit cycle

Use this exact loop:

1. Edit one logical thing.
2. Save.
3. Run `VALIDATE_ALL.cmd`.
4. Run `INSTALL_TO_VCMI.cmd`.
5. Restart VCMI completely.
6. Test on the smallest possible map.
7. Read the first relevant VCMI log error if it fails.
8. Only then make the next change.
