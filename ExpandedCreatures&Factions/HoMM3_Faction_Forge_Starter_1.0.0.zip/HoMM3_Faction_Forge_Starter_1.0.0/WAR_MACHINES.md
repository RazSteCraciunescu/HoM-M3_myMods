# War Machines: Glaive Thrower, Ram, Escalade, Battle Horn, and Corpse Launcher

## 1. How a VCMI war machine is represented

A functional war-machine mod normally has two linked entities:

1. A special creature used on the battlefield.
2. A hero artifact that places that creature into a machine slot.

The included lab demonstrates both.

Creature:

```text
Mods\factionforge-war-machines\Content\config\factionforge\glaiveThrowerCreature.json
```

Artifact:

```text
Mods\factionforge-war-machines\Content\config\factionforge\glaiveThrowerArtifact.json
```

The link is:

```json
"warMachine": "glaiveThrower"
```

The artifact uses:

```json
"slot": "MACH1"
```

`MACH1` is the Ballista-style slot, so the included Glaive Thrower competes with other machines occupying that slot.

## 2. Included Glaive Thrower

Its creature abilities are:

```json
"abilities": {
  "siegeWeapon": {"type": "SIEGE_WEAPON"},
  "shooter": {"type": "SHOOTER"},
  "cpuControlled": {"type": "CPU_CONTROLLED"}
}
```

It starts with the base Ballista battle animation/projectile:

```json
"animation": "SMBAL.DEF",
"missile": {
  "projectile": "SMBALX.DEF"
}
```

This is intentional. It proves the creature-artifact-machine connection before custom art or mechanics are introduced.

### Test it

1. Enable `Faction Forge - War Machine Lab`.
2. Open VCMI Map Editor.
3. Create a tiny map and place a hero.
4. Add `Glaive Thrower` to that hero's artifacts, or place the artifact as a map pickup if it appears in the object browser.
5. Give the hero an army and create an enemy stack.
6. Start combat and verify the machine appears and shoots.
7. Test with and without Artillery.
8. Test a siege and a normal field battle.

Do not place the special creature into an ordinary seven-stack army. The artifact is the intended entry point.

## 3. Make Dreadwood sell the Glaive Thrower

In Dreadwood's `faction.json`, find:

```json
"blacksmith": {
  "warMachine": "firstAidTent"
}
```

Change it to:

```json
"blacksmith": {
  "warMachine": "glaiveThrower"
}
```

Enable both mods and add this top-level field to Dreadwood's `mod.json`:

```json
"depends": [
  "factionforge-war-machines"
]
```

VCMI uses the mod folder name as the mod identifier. The dependency lets Dreadwood resolve entities defined by the War Machine Lab.

## 4. Change Glaive Thrower balance

Open `glaiveThrowerCreature.json` and edit:

```json
"attack": 11,
"defense": 10,
"hitPoints": 250,
"damage": {"min": 2, "max": 4},
"shots": 24
```

War-machine final damage may also depend on hero skills and the engine's existing machine formulas. Test with heroes of different Attack values and Artillery mastery before judging these numbers.

Replace art and sounds using `ASSET_PIPELINE.md`.

## 5. Ram design

There are two different interpretations.

### A. Catapult-like Ram prototype

A machine can reuse an existing wall-targeting handler such as the Catapult's supported bonus/subtype. This can prove wall targeting, but visually and mechanically it remains a Catapult-style attack.

Relevant existing concept:

```json
{
  "type": "CATAPULT",
  "subtype": "catapultShot"
}
```

Use a current Catapult definition from your exact VCMI version as the source of truth before activating this. The configuration details can change with engine version.

### B. True physical Ram

A ram that moves to the gate/wall, spends turns striking it, can be intercepted, and uses a unique animation needs new engine behavior:

- siege-only placement rules;
- path/position rules near walls;
- valid wall/gate targets;
- custom action and animation timing;
- wall damage calculation;
- AI decisions;
- network serialization for multiplayer;
- save/load state;
- combat log and UI feedback.

That is a C++ engine extension, not a reliable JSON rename. See `Templates/engine-extensions/ram.md`.

## 6. Escalade or siege ladder

A ladder that allows units to cross a wall changes battlefield accessibility. It requires the pathfinder and siege obstacle model to understand a temporary crossing.

Minimum engine work:

- create/target a wall segment;
- place a persistent ladder entity or battlefield feature;
- change passability between specific hexes;
- define which unit types may use it;
- handle destruction/removal;
- teach AI to place and use it;
- synchronize it in multiplayer and saves.

This cannot be represented honestly as an ordinary passive artifact. See `Templates/engine-extensions/escalade.md`.

## 7. Battle Horn

This is the closest of the proposed ideas to a data/script implementation.

Possible design:

- make it a war-machine artifact occupying a chosen slot;
- give its battlefield creature `SIEGE_WEAPON` and possibly `NOT_ACTIVE` so it is not controlled as a normal attacker;
- at battle start, apply Attack, Defense, morale, or damage bonuses to allied living stacks;
- optionally let it activate once to apply a timed buff;
- remove or disable the bonus when the Horn is destroyed, if the desired rules require that.

A permanent army-wide modifier may be expressible through an existing propagated bonus. A once-per-combat button, custom target selection, destruction-aware aura, or special animation may require Lua or C++ hooks.

Do not copy First Aid Tent's healing handler and merely rename it; that would still heal unless the actual effect is replaced.

See `Templates/engine-extensions/battle-horn.md`.

## 8. Corpse Launcher

A simple version can be a Ballista/Cannon-like shooter with custom art, projectile, sound, and damage.

The requested disease concept has several levels:

1. **On-hit debuff:** use an existing spell/bonus after attack, when a suitable disease-like modifier already exists.
2. **Area spell on impact:** use a supported spell-like attack or script that affects stacks in a target area.
3. **Persistent infected hexes:** create battlefield hazards that remain for turns and trigger when entered/occupied.
4. **Siege-only morale/attrition effect:** apply a custom siege event to defenders.

Levels 1-2 may be possible with existing bonuses or Lua. Level 3 generally needs persistent battlefield entities, event hooks, visuals, path/AI awareness, serialization, and possibly C++ changes. See `Templates/engine-extensions/corpse-launcher.md`.

## 9. Slot conflicts

A hero cannot normally equip two artifacts in the same war-machine slot. Decide which existing role your machine replaces:

- Ballista/Cannon/Glaive-like offensive machine;
- Ammo Cart support role;
- First Aid Tent support role;
- Catapult/siege role.

Do not assume a new string such as `MACH5` creates a fifth slot. A genuinely new equipment slot requires engine/UI/save-format support.

## 10. Release test matrix

For every war machine, test:

- hero with no related secondary skill;
- Basic/Advanced/Expert Artillery or relevant skill;
- normal battle;
- siege attacker;
- siege defender where applicable;
- autocombat;
- machine destroyed before acting;
- no ammunition / maximum turns;
- spell interactions;
- save and reload before battle;
- save and reload during battle if supported;
- multiplayer host and client;
- AI-controlled hero;
- two mods that use the same slot.
