# New Spells, Map Objects, Artifacts, Points of Interest, and Secondary Skills

The starter contains one active custom ability spell and one active artifact. It leaves custom map objects and secondary skills as templates/workflows because their handlers and schemas should be cloned from the exact VCMI build and content port you install.

## 1. How a custom spell is loaded

A mod manifest includes:

```json
"spells": [
  "config/factionforge/dreadHowl.json"
]
```

The included spell is an **ability spell**:

```json
"type": "ability"
```

That makes it suitable for creature casting and prevents it from becoming a normal Mage Guild spell through ordinary gain chances.

The creature connects to it with:

```json
"castsDreadHowl": {
  "type": "SPELLCASTER",
  "subtype": "spell.dreadHowl",
  "val": 2
},
"castsCount": {
  "type": "CASTS",
  "val": 1
}
```

Here, `val: 2` selects Advanced mastery in the existing creature-caster pattern, and `CASTS: 1` allows one cast per battle.

## 2. Edit Dread Howl damage

Open:

```text
Mods\factionforge-nightmare\Content\config\factionforge\dreadHowl.json
```

The direct-damage effect is:

```json
"battleEffects": {
  "directDamage": {
    "type": "core:damage"
  }
}
```

Per-mastery power values are under:

```json
"none":     {"power": 6},
"basic":    {"power": 7},
"advanced": {"power": 9},
"expert":   {"power": 11}
```

The creature also has:

```json
"spellpower": {
  "type": "CREATURE_SPELL_POWER",
  "val": 6
}
```

Treat spell effect, spell level/mastery, and creature spell power as separate balance controls. Test the real result rather than assuming a simple one-number formula.

## 3. Turn it into a buff, debuff, or area spell

Do not invent effect names. Find a current VCMI spell that already behaves like the desired effect and clone its `battleEffects`, targeting, flags, and levels.

Safe workflow:

1. Copy `Templates/direct-damage-ability-spell.template.json` into a new mod config file.
2. Give the spell a unique stable ID.
3. Add the file to `mod.json` under `spells`.
4. Keep `type: ability` while it is creature-only.
5. Replace the effect section with a known working current spell pattern.
6. Add its `SPELLCASTER` bonus to one creature.
7. Set `CASTS` to 1.
8. Test one target, invalid targets, immunities, autocombat, and AI use.
9. Only then alter range, area, duration, or unusual conditions.

## 4. Make a normal hero spell

A normal spell needs more than a combat effect. Depending on its category, it may need:

- spell school flags;
- level;
- mana costs at mastery levels;
- gain chances/faction availability;
- target type and target modifiers;
- battle or adventure effects;
- icons and animation;
- AI evaluation;
- immunity/dispelling behavior;
- descriptions for all mastery levels.

Clone the closest current spell from your installed VCMI version. Keep the first version simple: one existing effect with new numbers and art.

## 5. Artifacts

The Glaive Thrower artifact is registered through:

```json
"artifacts": [
  "config/factionforge/glaiveThrowerArtifact.json"
]
```

A normal artifact can grant supported bonuses instead of linking a war machine. Use an existing artifact with the desired slot/class/bonus style as a source and replace:

- ID;
- name/description/event text;
- class and value;
- allowed slots;
- graphics;
- bonuses.

Do not make up slot names or bonus identifiers. Clone a current known-good item first.

## 6. New adventure-map objects and Points of Interest

The basic pieces are:

1. An `objects` entry in `mod.json`.
2. A config file containing a unique object group/type.
3. At least one map template with animation, footprint/mask, and visit direction.
4. A handler that defines what happens when visited.
5. Text, rewards, guards, cooldown/revisit rules, and sounds as needed.

`Templates/map-object.template.json` is intentionally not loaded by any included mod. It is a planning scaffold, not a promise that one generic handler fits every object.

### Choose the closest existing handler

Start from an object that already matches the concept:

- one-time resource/reward pickup;
- guarded reward site;
- repeatable weekly object;
- creature dwelling;
- creature bank;
- market/trading object;
- shrine/spell-granting object;
- stat/skill visit object;
- quest or key-gated object;
- teleport/entrance pair.

Copy its current definition, change the ID and assets, then alter rewards. Handler-specific fields differ, so a universal fake example would be more harmful than helpful.

### New POI test sequence

1. Make it appear in the Map Editor.
2. Confirm footprint and passability.
3. Confirm the hero can approach from intended directions.
4. Confirm visit text and cancel behavior.
5. Confirm reward/guards.
6. Confirm revisit behavior.
7. Confirm AI can evaluate/use it.
8. Save/load before and after visiting.
9. Test random-map placement only after manual placement works.

## 7. Creature dwellings

A standalone dwelling needs:

- map object template and visit behavior;
- creature or creature list;
- growth/availability behavior;
- ownership/capture rules if applicable;
- map animation and footprint;
- editor registration.

Clone a current external dwelling whose ownership and recruitment behavior match yours. Then replace the creature reference with your custom creature ID.

## 8. New secondary skills

A new secondary skill is more involved than a new creature bonus. It needs:

- skill registration and localized name/descriptions;
- Basic/Advanced/Expert effects;
- level-up probabilities for hero classes;
- icons/UI integration;
- hero specialty behavior if used;
- AI valuation;
- save/load and network serialization support;
- interactions with Witch Huts, Scholars, Seer's Huts, artifacts, and map settings.

Existing effect combinations may be data-driven. A genuinely new rule may require scripting or C++.

Recommended process:

1. Clone the closest current skill definition from the exact VCMI source/content version.
2. Rename its stable ID.
3. Keep its existing effect type and change only values.
4. Add a small non-zero chance to one test hero class.
5. Test level-up acquisition and all three mastery levels.
6. Test hero screen, save/load, AI, and specialty interactions.
7. Only after that introduce a new effect handler.

## 9. Placeholder content strategy

For spells, items, and POIs, use placeholder art and existing effects first:

- new name and icon;
- existing effect type;
- conservative values;
- one controlled test map.

Once the entity loads and works, replace mechanics independently from art. This avoids debugging schema, gameplay, and animation simultaneously.

## 10. Namespaces and dependencies

Keep each real project in its own mod folder and use unique IDs. Avoid generic IDs such as `fireSword`, `darkKnight`, or `newTown` that another mod may also use.

A practical prefix pattern:

```text
projectCreatureName
projectSpellName
projectArtifactName
projectTownName
```

Never change IDs casually after maps use them. When one mod references another mod's creature/spell/artifact, declare a dependency and test both load orders in the Launcher.
