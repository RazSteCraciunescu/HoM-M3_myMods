# Troubleshooting and Recovery

## 1. The mod does not appear in VCMI Launcher

Check the folder depth. Correct:

```text
Documents\My Games\vcmi\Mods\factionforge-nightmare\mod.json
```

Wrong extra nesting:

```text
Documents\My Games\vcmi\Mods\factionforge-nightmare\factionforge-nightmare\mod.json
```

Run `INSTALL_TO_VCMI.cmd` again or copy the folder manually.

## 2. JSON parse error

Run:

```text
VALIDATE_ALL.cmd
```

Typical causes:

- missing comma between fields;
- trailing comma after the final field/array entry;
- single quotes instead of JSON double quotes;
- unescaped backslash or quote in text;
- missing closing `]` or `}`;
- comments inserted into strict JSON.

Restore the previous working file, then reapply one small edit.

## 3. Unresolved creature, spell, faction, hero, or artifact ID

Check:

- spelling and letter case;
- that the definition file is listed in `mod.json`;
- that the referenced mod is enabled;
- that a dependency is declared where required;
- that the ID was not renamed in only one file;
- that you did not confuse a display name with an internal ID.

Examples:

```text
Display name: Dreadwood Nightmare
Internal ID:  dreadwoodNightmare
```

## 4. Missing image, animation, or sound

For custom assets, verify the root:

```text
Content/data     for icons/portraits/interface images
Content/sprites  for animations/DEF/PNG frames
Content/sounds   for WAV
```

A config path must not include `Content/data/` or `Content/sprites/` itself.

Example config path:

```json
"iconSmall": "factionforge/nightmare/icons/small.png"
```

Actual file:

```text
Content\data\factionforge\nightmare\icons\small.png
```

Check case even on Windows; a release may later run on a case-sensitive filesystem.

## 5. Creature is black, boxed, shifted, or flickering

See `ASSET_PIPELINE.md`. Check alpha, palette conversion, frame canvas sizes, offsets, and animation group consistency.

For first diagnosis, temporarily return to:

```json
"animation": "CUNICO.DEF"
```

If combat works again, the custom battle animation is the problem rather than the creature stats.

## 6. Creature appears but cannot use Dread Howl

Check all four pieces:

1. Spell file listed in `mod.json` under `spells`.
2. Creature has `SPELLCASTER` subtype `spell.dreadHowl`.
3. Creature has `CASTS` greater than zero.
4. The target is valid and not blocked by immunity/target modifiers.

Also check the VCMI log for an unresolved spell identifier or unsupported effect.

## 7. Death Stare seems too weak or too strong

The included `val` follows the existing Death Stare event handler pattern; do not assume it means a simple flat percentage displayed to the player. Test controlled stack sizes and repeated attacks before balancing.

Use a test map with fixed armies and record at least dozens of attacks. Change one value at a time.

## 8. Dreadwood does not appear as a selectable town

Enable only Dreadwood and its required base content. Then check:

- `factions` entry in `mod.json`;
- top-level faction ID in `faction.json`;
- hero classes reference `"faction": "dreadwood"`;
- custom creatures reference `"faction": "dreadwood"`;
- roster IDs all resolve;
- every town art resource referenced from Rampart exists in the installed data set;
- VCMI log for the first error, not the final cascade.

A missing hero class or unresolved roster creature can prevent a faction from completing registration.

## 9. Town opens, but a building is missing or cannot be bought

Check:

- building exists in `town.buildings`;
- it appears in `town.hallSlots` where appropriate;
- prerequisites resolve;
- no circular construction dependency;
- structure presentation exists under `town.structures`;
- required resource/cost fields cloned from a working town are valid.

Temporarily restore the matching Rampart-derived building definition to isolate the issue.

## 10. Glaive Thrower does not appear in combat

Check:

- both creature and artifact files are listed in `mod.json`;
- the hero owns/equips the **artifact**, not the special creature stack;
- no other machine occupies `MACH1`;
- the artifact's `warMachine` matches `glaiveThrower` exactly;
- the War Machine Lab is enabled;
- the map/save was created or reopened after enabling the mod.

To sell it from Dreadwood, also change the Blacksmith reference as described in `WAR_MACHINES.md`.

## 11. VCMI crashes or returns to launcher

1. Do not keep relaunching unchanged.
2. Open the newest VCMI client/launcher log in your VCMI user-data folder.
3. Find the first `error`, `critical`, unresolved identifier, or missing resource near the load attempt.
4. Disable all Faction Forge mods.
5. Enable only Nightmare.
6. Then War Machine Lab.
7. Then Dreadwood.
8. Re-enable other third-party mods one at a time.

The first reported schema/resource error is usually more useful than later cascading errors.

## 12. Find the VCMI user folder and logs

Default Windows user-data root used by this package:

```text
%USERPROFILE%\Documents\My Games\vcmi
```

Look inside this root and its log/config subfolders for the newest Launcher, client, server, or editor logs. Exact filenames may differ between VCMI versions.

You can paste this into File Explorer:

```text
%USERPROFILE%\Documents\My Games\vcmi
```

## 13. Static validator passes, but VCMI rejects the mod

The included validator verifies file structure, JSON syntax, manifest references, local assets, and selected required fields. It is not the VCMI engine and cannot prove every schema field, bonus subtype, or runtime interaction.

Use the engine log as final authority. Add the discovered rule to your own test notes so the same error does not return.

## 14. Safe binary-search recovery

When a formerly working file fails:

1. Save the failing version separately.
2. Restore the last working version.
3. Reapply half of the changes.
4. Test.
5. Keep the half that reproduces the issue.
6. Repeat until one edit remains.

This is much faster than visually inspecting hundreds of lines.

## 15. Clean reinstall of the included mods

1. Close VCMI Launcher, game, and Map Editor.
2. Run `UNINSTALL_FROM_VCMI.cmd`.
3. Confirm these folders are gone from the user Mods folder:

```text
factionforge-nightmare
factionforge-dreadwood
factionforge-war-machines
```

4. Extract a fresh package copy.
5. Run `VALIDATE_ALL.cmd`.
6. Run `INSTALL_TO_VCMI.cmd`.
7. Enable one mod at a time.

This does not remove VCMI, HotA port data, maps, saves, or unrelated mods.

## 16. Useful bug-report bundle

When documenting a problem, include:

```text
VCMI version:
VCMI HotA port version:
Operating system:
Enabled mods and versions:
Exact reproduction steps:
Expected result:
Actual result:
First relevant log error:
Modified files:
Last known working change:
Minimal test map:
Screenshots/video where visual:
```

Never post copyrighted game data or private creator assets as part of a public bug report.
