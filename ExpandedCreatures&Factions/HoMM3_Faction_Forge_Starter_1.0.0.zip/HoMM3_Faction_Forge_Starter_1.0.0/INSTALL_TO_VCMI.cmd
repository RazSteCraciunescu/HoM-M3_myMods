@echo off
setlocal EnableExtensions
set "SOURCE=%~dp0Mods"
set "DEST=%USERPROFILE%\Documents\My Games\vcmi\Mods"

echo Faction Forge VCMI installer
echo Source: %SOURCE%
echo Target: %DEST%
echo.

if not exist "%SOURCE%" (
  echo ERROR: Source Mods folder is missing.
  exit /b 2
)

if not exist "%DEST%" mkdir "%DEST%"

for %%M in (factionforge-nightmare factionforge-dreadwood factionforge-war-machines) do (
  echo Installing %%M...
  if exist "%DEST%\%%M" rmdir /s /q "%DEST%\%%M"
  xcopy "%SOURCE%\%%M" "%DEST%\%%M\" /E /I /Y /Q >nul
  if errorlevel 1 (
    echo ERROR: Could not copy %%M.
    exit /b 1
  )
)

echo.
echo Installation complete.
echo Open VCMI Launcher, select Mods, and enable the three Faction Forge mods one at a time for first testing.
exit /b 0
