@echo off
setlocal EnableExtensions
set "DEST=%USERPROFILE%\Documents\My Games\vcmi\Mods"
echo This removes only these folders:
echo   factionforge-nightmare
echo   factionforge-dreadwood
echo   factionforge-war-machines
echo From: %DEST%
echo.
set /p "ANSWER=Type REMOVE and press Enter to continue: "
if /I not "%ANSWER%"=="REMOVE" (
  echo Cancelled.
  exit /b 0
)
for %%M in (factionforge-nightmare factionforge-dreadwood factionforge-war-machines) do (
  if exist "%DEST%\%%M" rmdir /s /q "%DEST%\%%M"
)
echo Removed.
exit /b 0
