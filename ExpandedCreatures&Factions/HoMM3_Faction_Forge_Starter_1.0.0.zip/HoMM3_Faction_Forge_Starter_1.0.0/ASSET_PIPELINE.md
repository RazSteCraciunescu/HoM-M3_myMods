# Creature, Town, Hero, Sound, and Animation Asset Pipeline

This package intentionally uses original placeholder PNG files and references animation/sound files from your legal Heroes III installation. Follow this workflow when replacing placeholders.

## 1. VCMI content roots

Inside a mod, use these roots:

```text
Content/config   JSON definitions
Content/data     icons, portraits, interface images, miscellaneous data
Content/sprites  animation JSON, PNG frames, and DEF files
Content/sounds   WAV files
Content/music    music files
Content/video    video files
Content/maps     maps when a mod includes them
```

A graphics path is normally relative to the matching content root. Example:

```json
"iconSmall": "factionforge/nightmare/icons/small.png"
```

means:

```text
Content/data/factionforge/nightmare/icons/small.png
```

This path:

```json
"map": "factionforge/nightmare/map/map.json"
```

means:

```text
Content/sprites/factionforge/nightmare/map/map.json
```

## 2. Two animation approaches

### Reference an existing DEF

The starter uses:

```json
"animation": "CUNICO.DEF"
```

VCMI resolves that from the installed game data. This is the safest way to clone a creature while working on stats and abilities.

To use a legally obtained custom DEF, copy it into your mod's `Content/sprites` folder and reference its filename/path. Keep the extension and letter case consistent.

### Use PNG frames with animation JSON

The included map sprites use this form:

```json
{
  "basepath": "factionforge/nightmare/map/",
  "sequences": [
    {
      "group": 0,
      "frames": [
        "map_0.png",
        "map_1.png",
        "map_2.png",
        "map_3.png"
      ],
      "generateShadow": 2,
      "generateOverlay": 1
    }
  ]
}
```

`basepath` is relative to `Content/sprites`. Frame files are relative to `basepath`.

This is convenient for original art because you can paint frames in PNG and avoid rebuilding a DEF during early iteration.

## 3. Battle animation warning

An adventure-map creature can often start with a simple group-0 loop. A battle creature requires the animation groups expected for its actions, such as:

- standing/idle;
- movement;
- turn;
- attack up/straight/down;
- defend/wince;
- death;
- shooting and projectile behavior for shooters;
- spell-cast behavior for caster animations where applicable.

Do not create a one-group battle animation and expect every combat action to work. The easiest workflow is:

1. Reference a known working creature DEF.
2. Finish stats and abilities.
3. Replace it with a custom DEF whose groups mirror the source creature.
4. Test every action and facing in combat.

For a horse-shaped Nightmare, cloning the Unicorn or War Unicorn group layout is practical.

## 4. The exact Nightmare swap

Current battle sprite:

```json
"animation": "CUNICO.DEF"
```

Possible WoG resource filenames commonly associated with the requested concepts are:

```text
Nightmare battle: ZM172N.DEF
Nightmare map:    ZMM172N.DEF
Hell Steed battle: ZM195Z.DEF
Hell Steed map:    ZMM195Z.DEF
```

These files are **not included**. Only use files you lawfully obtained and may use.

After placing a permitted battle DEF in:

```text
Mods\factionforge-nightmare\Content\sprites\factionforge\nightmare\battle\
```

change:

```json
"animation": "CUNICO.DEF"
```

to an appropriate relative reference, for example:

```json
"animation": "factionforge/nightmare/battle/ZM172N.DEF"
```

For the map DEF, place it in the mod and change the `map` field from the included JSON animation to the custom resource path supported by your VCMI build. Keep the original JSON map animation as a backup until the replacement loads.

## 5. Creature portraits and common starter dimensions

The package uses:

```text
small creature icon: 32 x 32 PNG
large creature icon: 58 x 64 PNG
```

Replace:

```text
Content\data\factionforge\nightmare\icons\small.png
Content\data\factionforge\nightmare\icons\large.png
```

Keep the same dimensions at first. Once the mod works, you can compare against a current working VCMI/HotA asset set if a particular UI expects another size.

The Dreadwood placeholder hero files use:

```text
small hero portrait:       48 x 32
large hero portrait:       58 x 64
small specialty portrait:  32 x 32
large specialty portrait:  44 x 44
```

Keep transparent backgrounds clean and inspect the result in the tavern, hero screen, combat, and scenario selection.

## 6. Alpha, palette, and visual artifacts

PNG assets should use true alpha transparency. Common problems:

- black rectangle: alpha was removed or flattened;
- colored/cyan rectangle: palette-key transparency from an old DEF workflow was imported incorrectly;
- fuzzy halo: image was composited against a light/dark matte before saving;
- shifted sprite: frame canvas sizes or anchor offsets differ;
- flicker: frame canvases are inconsistent or the subject jumps between frames.

For old indexed assets, preserve the source palette until extraction is complete, then convert carefully to RGBA for PNG use.

## 7. Sound replacement

Nightmare currently references original Unicorn sounds:

```json
"sound": {
  "attack": "UNICATTK.wav",
  "defend": "UNICDFND.wav",
  "killed": "UNICKILL.wav",
  "move": "UNICMOVE.wav",
  "wince": "UNICWNCE.wav"
}
```

To use custom sounds:

1. Create:

```text
Content\sounds\factionforge\nightmare\
```

2. Add short WAV files, for example:

```text
attack.wav
defend.wav
killed.wav
move.wav
wince.wav
```

3. Change the paths:

```json
"attack": "factionforge/nightmare/attack.wav"
```

Repeat for each event.

Use PCM WAV first. Avoid unusual codecs while debugging. Normalize levels so one creature is not drastically louder than the base game, and trim silence from the start of attacks and movement sounds.

## 8. Projectile replacement

The Glaive Thrower uses:

```json
"missile": {
  "projectile": "SMBALX.DEF"
}
```

Replace `SMBALX.DEF` with your own projectile DEF in `Content/sprites`, or with a supported animation resource matching the VCMI format used by a current shooter. Test shots at multiple distances and elevations.

A projectile's appearance does not change its gameplay logic. Ballista-compatible targeting remains Ballista-compatible until bonuses, scripts, or engine code change it.

## 9. Town asset replacement

Dreadwood currently reuses Rampart resources. The relevant sections are in `faction.json`:

```text
town.mapObject.templates
town.structures
town.musicTheme
town.tavernVideo
town.guildBackground
town.townBackground
town.guildWindow
town.buildingsIcons
town.hallBackground
town.icons
town.siege
puzzleMap
```

Replace one section at a time.

For a new town screen, you need more than a background image. Each building requires:

- visible animation/image;
- position;
- click/selection geometry as supported by the structure definition;
- built/unbuilt relationships;
- correct building ID;
- construction icon;
- prerequisites and cost.

For a new siege screen, every wall/tower/gate/moat element and creature coordinate must align with the art. Copying Rampart coordinates onto unrelated art will place units and impacts incorrectly.

## 10. Hero map and battle animations

The starter hero classes currently use generic original references:

```json
"battle": {
  "female": "CH00.DEF",
  "male": "CH00.DEF"
}
```

and:

```json
"animation": "AH00_.def"
```

Treat these as placeholders. When replacing them, clone the data structure and animation groups from a known working hero class whose movement and combat presentation matches your intended design.

## 11. Recommended free tools

Useful categories include:

- an image editor with indexed and RGBA PNG support;
- a DEF viewer/extractor/compiler compatible with Heroes III resources;
- an audio editor that exports PCM WAV;
- VS Code for JSON editing;
- Git for backups and change history.

Third-party DEF utilities vary by version and license. Scan downloads, keep their source links, and do not bundle them inside a published mod unless their license permits redistribution.

## 12. Copyright and creator permission

A technically accessible resource is not automatically free to republish.

Safe options:

- your own original art/audio;
- base-game resources read from each player's legal installation;
- openly licensed assets used within their license terms;
- creator-provided files with explicit permission for your project.

Keep an `ASSET_CREDITS.md` in any real mod. Record creator, source, license/permission, modifications, and required attribution before you lose track of where a file came from.
