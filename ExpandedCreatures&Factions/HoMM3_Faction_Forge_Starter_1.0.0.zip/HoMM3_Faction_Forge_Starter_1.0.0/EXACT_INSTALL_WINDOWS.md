# Exact Windows installation and first test

Target environment for this kit:

- Windows 10 or Windows 11, 64-bit;
- Heroes of Might and Magic III Complete Edition data;
- VCMI 1.7.x — this package was prepared against the 1.7 mod format and current 1.7-era examples;
- optional VCMI Horn of the Abyss port;
- no paid modding tools.

## Part 1 — Install a legal Heroes III data source

### Recommended: GOG Heroes III Complete

1. Sign in to GOG.
2. Open your library entry for **Heroes of Might and Magic 3: Complete**.
3. Select **Download offline backup game installers**.
4. Download the `.exe` installer and every `.bin` file belonging to it into one folder, for example:

   ```text
   C:\Installers\Heroes3Complete\
   ```

5. Run the GOG installer.
6. Install the game into a simple path that is not under `Program Files`, for example:

   ```text
   C:\Games\Heroes3Complete\
   ```

7. Launch the original game once and close it. This confirms the installation is complete.

Official store page:

```text
https://www.gog.com/en/game/heroes_of_might_and_magic_3_complete_edition
```

### Existing CD / Complete / Shadow of Death installation

A complete installation of Heroes III Complete or Shadow of Death can also provide the required game data. Complete is recommended because it avoids missing campaigns/resources.

### Do not use the Ubisoft “HD Edition” as the only data source

The Steam/Ubisoft HD Edition is based on Restoration of Erathia and lacks the full Armageddon’s Blade/Shadow of Death data expected by the usual VCMI setup. It is not a substitute for Heroes III Complete.

## Part 2 — Keep native HotA separate

You may keep a normal native HotA installation for playing native HotA, but do not use its executable as this mod workspace’s engine.

A clean arrangement is:

```text
C:\Games\Heroes3Complete\        original Complete data source
C:\Games\Heroes3-HotA-Native\   optional separate native HotA copy
C:\Program Files\VCMI\           VCMI engine, if installed there
```

Do not overwrite your only clean Complete installation with experimental files.

## Part 3 — Install VCMI

1. Open the official VCMI download page:

   ```text
   https://vcmi.eu/download/
   ```

2. Download the current stable Windows installer. At the time this starter was prepared, the current stable release was VCMI 1.7.4.
3. Run the installer with normal Windows permissions.
4. Launch **VCMI Launcher**.
5. When prompted to import game files, use one of these methods:

### Method A — Import the GOG offline installer

1. In VCMI Launcher, choose the option to install/import game files.
2. Select the GOG `.exe` installer.
3. Keep all matching `.bin` files in the same directory as that `.exe`.
4. Allow the launcher to extract and import the data.

### Method B — Import an installed copy

1. Point VCMI Launcher at:

   ```text
   C:\Games\Heroes3Complete\
   ```

2. Let it import the required game data.

### Method C — Manual fallback

If automatic detection fails, copy these folders from the installed game:

```text
C:\Games\Heroes3Complete\Data
C:\Games\Heroes3Complete\Maps
C:\Games\Heroes3Complete\Mp3
```

into:

```text
%USERPROFILE%\Documents\My Games\vcmi\
```

The result should resemble:

```text
%USERPROFILE%\Documents\My Games\vcmi\Data\
%USERPROFILE%\Documents\My Games\vcmi\Maps\
%USERPROFILE%\Documents\My Games\vcmi\Mp3\
```

6. In the launcher, run the base game once before adding mods.
7. Start a tiny scenario, enter a battle, exit, and close VCMI. This proves the base data is usable.

## Part 4 — Optional: install the VCMI HotA port

This is the VCMI content port, not `H3hota.exe`.

1. Open VCMI Launcher.
2. Open **Mods** or **Mod Manager**.
3. Locate **Horn of the Abyss** in the repository.
4. Install the main package and the components you want, such as Cove, Factory, Cannon, HotA balance, map objects, and other submods.
5. Read dependency prompts and let the launcher install required components.
6. Enable the HotA components.
7. Launch a game and confirm Cove/Factory or another selected HotA feature is visible.
8. Close VCMI before installing Faction Forge.

At the time this kit was prepared, the VCMI HotA port repository branch advertised version 1.8.005. The launcher is the authority for the version currently offered to you.

## Part 5 — Extract this starter kit

1. Extract the main ZIP to a normal writable folder, for example:

   ```text
   C:\Games\HoMM3-Modding\HoMM3_Faction_Forge_Starter_1.0.0\
   ```

2. Do not run it from inside the ZIP preview in Explorer.
3. Open the extracted folder.
4. Double-click:

   ```text
   VALIDATE_ALL.cmd
   ```

5. The final line should say:

   ```text
   Result: PASSED static validation
   ```

If Windows says `python` or `py` is missing, install a current Python 3 release from the Microsoft Store or python.org, then run the command again. VCMI itself does not require Python; only these helper scripts do.

## Part 6 — Install the three starter mods

### Automatic method

Double-click:

```text
INSTALL_TO_VCMI.cmd
```

It copies these folders:

```text
factionforge-nightmare
factionforge-dreadwood
factionforge-war-machines
```

to:

```text
%USERPROFILE%\Documents\My Games\vcmi\Mods\
```

### Manual method

Copy each folder from:

```text
HoMM3_Faction_Forge_Starter_1.0.0\Mods\
```

into:

```text
%USERPROFILE%\Documents\My Games\vcmi\Mods\
```

The final structure must be exactly:

```text
%USERPROFILE%\Documents\My Games\vcmi\Mods\factionforge-nightmare\mod.json
%USERPROFILE%\Documents\My Games\vcmi\Mods\factionforge-dreadwood\mod.json
%USERPROFILE%\Documents\My Games\vcmi\Mods\factionforge-war-machines\mod.json
```

A common mistake is an extra nested folder such as:

```text
...\Mods\factionforge-nightmare\factionforge-nightmare\mod.json
```

That is wrong. `mod.json` must be directly inside the mod folder.

## Part 7 — Enable and test the neutral Nightmare first

1. Open VCMI Launcher.
2. Open **Mods**.
3. Search for:

   ```text
   Faction Forge - Nightmare Creature Lab
   ```

4. Enable it.
5. Leave Dreadwood and the War Machine Lab disabled for this first test.
6. Start VCMI Map Editor. Depending on installation, use the launcher’s Tools entry, the Start menu shortcut, or `vcmieditor.exe`/`VCMI_mapeditor.exe` from the VCMI installation.
7. Create a small new map with at least two players.
8. Place a hero for the human player.
9. Find the `Nightmare` in the creature/monster object list and place a stack near the hero. Custom creatures may be grouped under their mod or under neutral monsters, depending on editor version.
10. Open the stack properties and set a test amount, for example 20.
11. Save the map as:

    ```text
    %USERPROFILE%\Documents\My Games\vcmi\Maps\FactionForge_Nightmare_Test.vmap
    ```

12. Start VCMI.
13. Open the test map.
14. Fight the Nightmare.
15. Confirm:
    - the placeholder map creature is visible;
    - the battle creature uses the Unicorn battle animation;
    - its creature information shows Death Stare and Dread Howl-related abilities;
    - it can cast Dread Howl once;
    - it cannot cast it a second time in the same combat.

## Part 8 — Test the Glaive Thrower

1. Exit VCMI.
2. Enable **Faction Forge - War Machine Lab**.
3. In Map Editor, place the `Glaive Thrower` artifact on a test map, or add it to a hero’s artifacts in hero properties.
4. Ensure that hero does not also start with a normal Ballista; both use the `MACH1` slot.
5. Start a battle.
6. The machine initially uses the Ballista battle DEF/projectile/sounds and Ballista-compatible targeting. This proves the artifact-to-war-machine connection works before custom art or behavior is added.

## Part 9 — Test Dreadwood last

1. Exit VCMI.
2. Enable **Faction Forge - Dreadwood Town Scaffold**.
3. Create a new random map or editor map.
4. Select or place the `Dreadwood` faction.
5. Confirm the town currently looks like Rampart. This is intentional placeholder reuse.
6. Open the town and verify that tier 6 is:

   ```text
   Dreadwood Nightmare -> Abyssal Nightmare
   ```

7. Confirm Dread Rider and Night Sage heroes can appear.
8. Build tier-6 dwellings and recruit/test both creatures.

## Part 10 — Where VCMI logs are stored

Use these files after any failure:

```text
%USERPROFILE%\Documents\My Games\vcmi\logs\VCMI_Client_log.txt
%USERPROFILE%\Documents\My Games\vcmi\logs\VCMI_Server_log.txt
%USERPROFILE%\Documents\My Games\vcmi\logs\VCMI_Launcher_log.txt
```

Some builds place logs directly under the VCMI user directory instead of the `logs` subfolder. Search this directory if necessary:

```text
%USERPROFILE%\Documents\My Games\vcmi\
```

When troubleshooting, capture the **first error mentioning `factionforge`**, not only the final crash line.

## Updating a mod after edits

The kit in your workspace and the copy under the VCMI user folder are separate.

After each edit, either:

- run `INSTALL_TO_VCMI.cmd` again; or
- edit the installed copy directly while experimenting.

The safer workflow is to keep the master copy in your workspace, run validation, then reinstall it.
