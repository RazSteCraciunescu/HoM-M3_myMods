# Building and Replacing a Complete Faction

This guide uses the included `factionforge-dreadwood` mod as the editable reference town.

Dreadwood is deliberately conservative: it is a **new faction ID** with its own name, roster, creatures, hero classes, and heroes, but it temporarily reuses Rampart's town screen, siege screen, structures, music, and several original creatures. This lets you prove the data model first and replace art one system at a time.

## 1. The five files that form Dreadwood

| File | What it controls |
|---|---|
| `Mods/factionforge-dreadwood/mod.json` | Mod metadata and which definitions VCMI loads. |
| `Content/config/factionforge/dreadwood/faction.json` | Faction identity, town roster, buildings, construction tree, town/map presentation, moat, siege, icons, names, and music. |
| `Content/config/factionforge/dreadwood/creatures.json` | Dreadwood Nightmare and Abyssal Nightmare. |
| `Content/config/factionforge/dreadwood/heroClasses.json` | Might and magic hero classes, skill chances, primary-skill growth, map/battle models, and tavern chances. |
| `Content/config/factionforge/dreadwood/heroes.json` | Individual heroes, portraits, biographies, starting armies, skills, spells, and specialties. |

Do not begin by replacing every file. First prove that the unchanged starter appears in the Map Editor and can finish a test battle.

## 2. Change the seven-tier creature roster

Open:

```text
Mods\factionforge-dreadwood\Content\config\factionforge\dreadwood\faction.json
```

Find:

```json
"creatures": [
  ["centaur", "centaurCaptain"],
  ["dwarf", "battleDwarf"],
  ["woodElf", "grandElf"],
  ["pegasus", "silverPegasus"],
  ["dendroidGuard", "dendroidSoldier"],
  ["dreadwoodNightmare", "abyssalNightmare"],
  ["greenDragon", "goldDragon"]
]
```

The outer array is tier 1 through tier 7. Each inner array contains:

```text
[base creature ID, upgraded creature ID]
```

Example: make a custom tier-3 pair:

```json
["shadowArcher", "eclipseArcher"]
```

Then define both IDs in `creatures.json` and add this to the base creature:

```json
"upgrades": ["eclipseArcher"]
```

### More than one upgrade

VCMI can represent multiple upgrade choices when the town/building design supports them. The creature's `upgrades` array may list more than one ID:

```json
"upgrades": ["eclipseArcher", "thornArcher"]
```

Do this only after the standard base-plus-one-upgrade town works. Alternate upgrades also require the appropriate dwelling/building/UI treatment.

## 3. Understand dwelling links

The standard town building IDs are:

```text
dwellingLvl1 ... dwellingLvl7
dwellingUpLvl1 ... dwellingUpLvl7
```

The creature attached to a dwelling comes from the roster index above. The building definition normally controls costs, prerequisites, upgrades, and special behavior; it does not need to repeat the creature ID.

Example from Dreadwood:

```json
"dwellingLvl6": {
  "requires": [
    "allOf",
    ["dwellingLvl4"],
    ["dwellingLvl5"]
  ]
},
"dwellingUpLvl6": {
  "upgrades": "dwellingLvl6"
}
```

Changing roster slot 6 changes what those two buildings recruit.

## 4. Change construction prerequisites

Inside `town.buildings`, edit `requires`.

Single prerequisite:

```json
"dwellingLvl2": {
  "requires": ["dwellingLvl1"]
}
```

Require all listed branches:

```json
"dwellingLvl6": {
  "requires": [
    "allOf",
    ["dwellingLvl4"],
    ["dwellingLvl5"]
  ]
}
```

An upgrade points back to the base building:

```json
"dwellingUpLvl6": {
  "upgrades": "dwellingLvl6"
}
```

After every construction-tree edit, test the town in-game. A syntactically valid circular dependency can still make a building impossible to construct.

## 5. Change town identity

At the top of `faction.json`:

```json
"name": "Dreadwood",
"description": "...",
"nativeTerrain": ["grass"],
"alignment": "evil",
"boat": "boatCastle"
```

Typical alignment values are:

```text
good
neutral
evil
```

Use valid terrain identifiers already present in your installed VCMI data or HotA port. Begin with one terrain and add more only after the faction loads.

Change generated town names under:

```text
dreadwood.town.names
```

The included list has twelve entries and may be expanded.

## 6. Change the Blacksmith war machine

Dreadwood currently contains:

```json
"blacksmith": {
  "warMachine": "firstAidTent"
}
```

To make its Blacksmith sell the included Glaive Thrower, first enable `factionforge-war-machines`, then change it to:

```json
"blacksmith": {
  "warMachine": "glaiveThrower"
}
```

Because this creates a cross-mod reference, also add this top-level field to Dreadwood's `mod.json` (remember the comma before or after it):

```json
"depends": [
  "factionforge-war-machines"
]
```

The mod folder name is its identifier. Keeping the mods independent until this edit is safer during the first test.

## 7. Change the hero classes

Open:

```text
Content\config\factionforge\dreadwood\heroClasses.json
```

Dreadwood includes:

```text
dreadwoodDreadRider  -> might
dreadwoodNightSage   -> magic
```

Important fields:

```json
"faction": "dreadwood",
"affinity": "might",
"primarySkills": {
  "attack": 2,
  "defence": 2,
  "spellpower": 1,
  "knowledge": 1
}
```

`lowLevelChance` and `highLevelChance` control primary-skill growth chances. `secondarySkills` controls the relative chance of each secondary skill. Zero prevents that class from normally learning the skill through level-up.

Keep the four primary-skill start values at a sensible total for a level-1 hero. Use existing official classes as balance references.

## 8. Change individual heroes

Open:

```text
Content\config\factionforge\dreadwood\heroes.json
```

Each top-level key is a stable hero ID. Example:

```json
"morwen": {
  "female": true,
  "class": "dreadwoodNightSage",
  "spellbook": ["magicArrow"],
  "skills": [
    {"skill": "sorcery", "level": "basic"}
  ]
}
```

Change the starting army:

```json
"army": [
  {"creature": "centaur", "min": 15, "max": 25},
  {"creature": "dwarf", "min": 3, "max": 7},
  {"creature": "dreadwoodNightmare", "min": 1, "max": 1}
]
```

Change the portrait paths under `images`. Keep each path relative to `Content/data` and omit `Content/data/` itself.

A normal skill specialty is represented in this scaffold as:

```json
"specialty": {
  "secondary": "sorcery"
}
```

More unusual specialties should be cloned from a current VCMI hero that already implements the same kind of effect.

## 9. Replace Rampart presentation assets in a safe order

Replace systems in this order:

1. Creature portraits and adventure-map sprites.
2. Creature battle animations and sounds.
3. Hero portraits.
4. Faction selector icons.
5. Town music.
6. Adventure-map town animations.
7. Town background.
8. Building images/animations and clickable structure geometry.
9. Siege background, walls, towers, moat, gate, and coordinates.
10. Puzzle map.

Do not replace the town screen, every building, and the siege screen in one commit. When it fails, you will not know which path or coordinate caused the problem.

## 10. Clone Dreadwood into a second original faction

Make a backup first. Then:

1. Copy:

```text
Mods\factionforge-dreadwood
```

2. Rename the folder, for example:

```text
Mods\factionforge-ashen-order
```

3. In its `mod.json`, change `name`, `description`, `author`, and version.
4. Rename the config folder:

```text
Content\config\factionforge\dreadwood
```

to:

```text
Content\config\factionforge\ashenOrder
```

5. Update every path in `mod.json`.
6. In all JSON files, replace the exact identifier `dreadwood` with `ashenOrder` where it is an entity ID or faction reference.
7. Rename custom creature IDs, class IDs, hero IDs, spell IDs, and asset paths. Do not accidentally replace prose words inside biographies unless intended.
8. Move/rename the asset tree under:

```text
Content\data\factionforge\...
Content\sprites\factionforge\...
```

9. Update every corresponding graphics path.
10. Run `VALIDATE_ALL.cmd`.
11. Enable only the new faction in VCMI Launcher and test a tiny map.

Stable IDs matter. After maps or saves use `ashenOrder`, changing that ID can break those files.

## 11. Full originality checklist

A fully original town eventually needs, at minimum:

- seven base creatures and seven upgrades;
- creature battle animations, map animations, portraits, and sounds;
- at least one might and one magic class;
- a usable hero pool with portraits, armies, skills, biographies, and specialties;
- faction/town selector icons for village/fort states and UI sizes;
- adventure-map town animations for village, fort/castle, and capitol states;
- town background and each building's visible/clickable structure definitions;
- building icons and construction-screen layout;
- siege background, gate, moat, towers, walls, battlements, and coordinates;
- music, tavern video, guild/town windows, creature panel backgrounds;
- puzzle map art and piece positions;
- dwelling costs/prerequisites and economy balance;
- localized names and descriptions if you plan multiple languages.

The provided scaffold lets you postpone most art while you design the faction's gameplay.

## 12. Minimum test map after each change

Create a small map with:

- one human player using Dreadwood;
- one Dreadwood starting town;
- one enemy town;
- one stack of every changed creature;
- one Glaive Thrower artifact when testing war machines;
- abundant resources;
- no timed events or complex scripts.

Test town opening, building, recruitment, upgrading, hero recruitment, map movement, normal battle, siege attack, siege defense, save, load, and map reopening in the editor.
