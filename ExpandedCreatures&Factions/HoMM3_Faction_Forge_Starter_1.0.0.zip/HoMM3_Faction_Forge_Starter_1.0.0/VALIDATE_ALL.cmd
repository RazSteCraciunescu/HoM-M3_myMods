@echo off
setlocal
set "SCRIPT=%~dp0tools\validate_mods.py"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%SCRIPT%" "%~dp0Mods"
) else (
  python "%SCRIPT%" "%~dp0Mods"
)
set "RESULT=%errorlevel%"
echo.
if not "%RESULT%"=="0" echo Validation found errors. Read the lines above before installing.
exit /b %RESULT%
