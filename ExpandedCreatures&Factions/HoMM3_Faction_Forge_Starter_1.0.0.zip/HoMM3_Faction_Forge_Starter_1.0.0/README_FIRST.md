# HoMM3 Faction Forge Starter 1.0.0

This package is a practical starter workspace for creating **new creatures, new playable factions/towns, creature abilities, creature-cast spells, and war-machine variants** for Heroes of Might and Magic III through the open-source **VCMI engine**.

## Read this distinction first

This package does **not** patch `H3hota.exe` and does not modify the native Horn of the Abyss executable. Native HotA is an excellent expansion, but it is not distributed as a public, general-purpose town/creature SDK. Arbitrarily adding more town slots, new creature IDs, and new mechanics directly to native HotA would require version-specific reverse engineering and would be fragile after every HotA update.

VCMI is used instead because it can load legal data from your own Heroes III Complete/Shadow of Death installation and lets mods define entities through readable files. The VCMI Launcher also has a maintained HotA content port, so you can use a HotA-like content set while retaining a mod-friendly engine.

**Recommended setup:** Heroes III Complete data + VCMI 1.7.x + the VCMI HotA port + your own Faction Forge mods.

## What is already included

| Folder | Status | Purpose |
|---|---|---|
| `Mods/factionforge-nightmare` | Enabled working example; statically validated | A neutral Unicorn-derived Nightmare with editable stats, Death Stare, and one Dread Howl cast per combat. |
| `Mods/factionforge-dreadwood` | Enabled playable scaffold; statically validated | A separate playable faction that currently reuses Rampart town/siege/music assets and replaces tier 6 with two custom Nightmare creatures. Includes two hero classes and four placeholder heroes. |
| `Mods/factionforge-war-machines` | Enabled working scaffold; statically validated | A Glaive Thrower connected to a `MACH1` artifact. It deliberately begins with Ballista-compatible behavior. |
| `Templates` | Not loaded by VCMI | Copyable templates for creatures, heroes, hero classes, spells, artifacts, map objects, and deeper engine-extension designs. |
| `tools` | Ready to run | Static validator, per-mod ZIP packer, and new-creature generator. |

“Statically validated” means every shipped JSON file parses, every manifest reference exists, local assets resolve, animation frames exist, and basic required fields are present. This environment cannot launch your Windows copy of VCMI, so the first real engine test must be performed on your computer. VCMI’s own startup logs are the final authority.

## Fastest first run

1. Follow `EXACT_INSTALL_WINDOWS.md`.
2. Double-click `VALIDATE_ALL.cmd`.
3. Double-click `INSTALL_TO_VCMI.cmd`.
4. Open VCMI Launcher.
5. Enable **Faction Forge - Nightmare Creature Lab only**.
6. Launch VCMI Map Editor and place the new `Nightmare` creature on a tiny test map.
7. Only after that succeeds, enable the War Machine Lab, test it, and then enable Dreadwood.

Testing one mod at a time makes the first error easy to identify.

## Files you will edit most often

### Neutral Nightmare

`Mods/factionforge-nightmare/Content/config/factionforge/nightmare.json`

Edit attack, defense, HP, speed, damage, cost, growth, tier, faction, Death Stare, spell power, cast count, and asset paths here.

`Mods/factionforge-nightmare/Content/config/factionforge/dreadHowl.json`

Edit Dread Howl’s damage scaling, mastery levels, target behavior, description, and effect animation here.

### Dreadwood faction

`Mods/factionforge-dreadwood/Content/config/factionforge/dreadwood/faction.json`

Edit the town’s name, alignment, native terrain, town names, seven-tier roster, buildings, town visuals, map-town visuals, music, moat, siege layout, and icons here.

`Mods/factionforge-dreadwood/Content/config/factionforge/dreadwood/creatures.json`

Edit the faction’s tier-6 base and upgrade here.

`Mods/factionforge-dreadwood/Content/config/factionforge/dreadwood/heroClasses.json`

Edit might/magic class probabilities, starting primary skills, secondary-skill chances, map animations, and tavern availability here.

`Mods/factionforge-dreadwood/Content/config/factionforge/dreadwood/heroes.json`

Edit placeholder heroes, armies, portraits, spells, skills, specialties, names, and biographies here.

### Glaive Thrower

`Mods/factionforge-war-machines/Content/config/factionforge/glaiveThrowerCreature.json`

Edit combat stats, shots, battle DEF, projectile DEF, sounds, and abilities here.

`Mods/factionforge-war-machines/Content/config/factionforge/glaiveThrowerArtifact.json`

Edit artifact name, price/value, slot, map animation, and inventory icons here.

## Important legal boundary

The package contains only original placeholder graphics plus text/code written for this starter. It does not redistribute Ubisoft/New World Computing game data, HotA assets, WoG assets, or Discord creators’ work.

You may reference original-game files such as `CUNICO.DEF` because VCMI reads them from **your own legal installation**. To use a WoG Nightmare, Hell Steed, or a community artist’s sprite, obtain the files from a source whose license or creator permission allows your intended use. Do not publish somebody else’s art merely because you can extract it.

## What JSON can and cannot do

Straightforward data-driven work:

- new creatures and upgrades;
- new factions/towns;
- heroes and hero classes;
- most stats and existing bonus types;
- creature spell casting and charge limits;
- new spells built from supported effects;
- artifacts and war-machine creatures;
- many map objects, dwellings, banks, and configurable rewards;
- replacement animations, portraits, sounds, music, and icons.

Likely Lua/combat-script work:

- conditional effects that existing bonuses cannot express;
- custom “after X happens, do Y” behavior;
- aura logic with special targeting rules;
- disease or hazards that persist and tick on battlefield hexes, if supported event hooks are sufficient.

C++ engine-extension work:

- a ladder/escalade that changes wall-crossing pathfinding;
- a completely new siege phase or wall interaction;
- a truly separate Catapult replacement system if current war-machine hooks cannot express it;
- mechanics requiring new targeting UI, network messages, AI decisions, or persistent battlefield entities absent from VCMI’s scripting API.

See `LIMITS_ENGINE_EXTENSIONS.md` before investing art time in one of those mechanics.

## Backups and version control

Before large edits:

1. Copy the entire mod folder.
2. Keep IDs stable after a map/save has used them.
3. Use Git locally if possible.
4. Commit one working change at a time: stats, then ability, then animation, then sounds.
5. Never test ten changes at once when one typo can stop the mod from loading.

## Package scripts

- `VALIDATE_ALL.cmd` — checks all included mods.
- `INSTALL_TO_VCMI.cmd` — copies the three mod folders into your VCMI user Mods folder.
- `UNINSTALL_FROM_VCMI.cmd` — removes only those three folders.
- `PACK_MODS.cmd` — rebuilds individual ZIP packages in `Ready-to-install`.
- `tools/new_creature_mod.py` — generates a new clone-ready creature mod.

Start with `EXACT_INSTALL_WINDOWS.md`, then `QUICK_START_NIGHTMARE.md`.
