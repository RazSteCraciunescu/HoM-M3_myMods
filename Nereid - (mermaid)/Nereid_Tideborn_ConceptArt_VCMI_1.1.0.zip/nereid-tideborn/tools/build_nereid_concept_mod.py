from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import shutil
import sys
import textwrap
import wave
import zipfile
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import cv2
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

# Reuse the already-tested animation/audio helpers from the first Nereid package,
# while replacing every creature visual with the user's supplied concept art.
BASE_SCRIPT = Path('/mnt/data/nereid_work/build_nereid_mod.py')
spec = importlib.util.spec_from_file_location('nereid_base_builder', BASE_SCRIPT)
if spec is None or spec.loader is None:
    raise RuntimeError(f'Could not load {BASE_SCRIPT}')
base = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = base
spec.loader.exec_module(base)

VERSION = '1.1.0'
WORK = Path('/mnt/data/nereid_concept_work')
PACKAGE_ROOT = WORK / f'Nereid_Tideborn_ConceptArt_VCMI_{VERSION}'
MOD = PACKAGE_ROOT / 'nereid-tideborn'
CONTENT = MOD / 'Content'
CONFIG = CONTENT / 'config' / 'nereid'
SPRITES = CONTENT / 'sprites' / 'nereid'
DATA = CONTENT / 'data' / 'nereid'
SOUNDS = CONTENT / 'sounds' / 'nereid'
PREVIEW = MOD / 'preview'
SOURCE = MOD / 'source'
TOOLS = MOD / 'tools'
ZIP_PATH = Path(f'/mnt/data/Nereid_Tideborn_ConceptArt_VCMI_{VERSION}.zip')
SHA_PATH = Path(f'/mnt/data/Nereid_Tideborn_ConceptArt_VCMI_{VERSION}_SHA256.txt')
PREVIEW_PATH = Path('/mnt/data/Nereid_Tideborn_ConceptArt_preview.png')
ASSETS_PREVIEW_PATH = Path('/mnt/data/Nereid_Tideborn_ConceptArt_actual_assets.png')
BASIC_INPUT = Path('/mnt/data/Mermaid_basic(1).png')
UPGRADE_INPUT = Path('/mnt/data/Mermaid_upgrade(1).png')
CONCEPT_POSTER = WORK / 'concept_showcase.png'

FORMS = {
    'nereid': {
        'slug': 'nereid',
        'name': 'Nereid',
        'plural': 'Nereids',
        'form': 'base',
        'target_height': 106,
        'accent': (37, 176, 130),
        'stats': {
            'level': 5,
            'attack': 10,
            'defense': 10,
            'damage': {'min': 8, 'max': 12},
            'hitPoints': 40,
            'speed': 6,
            'growth': 4,
            'cost': {'gold': 550},
            'fightValue': 620,
            'aiValue': 720,
            'advMapAmount': {'min': 4, 'max': 8},
        },
        'luck': 1,
        'description': (
            'Nereids are sea nymphs whose broad fin-mantles resemble wings but cannot sustain flight. '
            'They glide across land on a living current, bend fortune in favor of their allies, and grant '
            'Summon Boat to a spellbook-bearing hero while at least one Nereid remains in that hero army.'
        ),
        'upgrade': 'nereid-tideborn:nereidSiren',
    },
    'nereidSiren': {
        'slug': 'nereid_siren',
        'name': 'Nereid Siren',
        'plural': 'Nereid Sirens',
        'form': 'upgrade',
        'target_height': 114,
        'accent': (67, 137, 226),
        'stats': {
            'level': 5,
            'attack': 12,
            'defense': 12,
            'damage': {'min': 10, 'max': 14},
            'hitPoints': 50,
            'speed': 7,
            'growth': 4,
            'cost': {'gold': 800},
            'fightValue': 780,
            'aiValue': 920,
            'advMapAmount': {'min': 3, 'max': 7},
        },
        'luck': 2,
        'description': (
            'Nereid Sirens are elder tideborn whose song can bless an army or demand a terrible price. '
            'They grant a stronger Luck aura, provide Summon Boat to a spellbook-bearing hero, and each '
            'stack may cast Sacrifice once per combat.'
        ),
        'upgrade': None,
    },
}

# Redirect every helper in the imported builder to the new package.
base.WORK = WORK
base.PACKAGE_ROOT = PACKAGE_ROOT
base.MOD = MOD
base.CONTENT = CONTENT
base.CONFIG = CONFIG
base.SPRITES = SPRITES
base.DATA = DATA
base.SOUNDS = SOUNDS
base.PREVIEW = PREVIEW
base.SOURCE = SOURCE
base.TOOLS = TOOLS
base.ZIP_PATH = ZIP_PATH
base.SHA_PATH = SHA_PATH
base.PREVIEW_PATH = PREVIEW_PATH
base.POSTER = CONCEPT_POSTER
base.FORMS = FORMS
base.MOD_ID = 'nereid-tideborn'
base.RESOURCE_NS = 'nereid'

FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_SERIF_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'


def fnt(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def save_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def crop_alpha(im: Image.Image, pad: int = 0) -> Image.Image:
    im = im.convert('RGBA')
    bbox = im.getbbox()
    if not bbox:
        return im
    x0, y0, x1, y1 = bbox
    x0 = max(0, x0 - pad)
    y0 = max(0, y0 - pad)
    x1 = min(im.width, x1 + pad)
    y1 = min(im.height, y1 + pad)
    return im.crop((x0, y0, x1, y1))


def extract_subject(path: Path) -> Image.Image:
    """Remove the grey concept-art background and the small sparkle mark."""
    bgr = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(path)
    h, w = bgr.shape[:2]
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    mask = np.full((h, w), cv2.GC_PR_BGD, np.uint8)
    border = max(8, int(min(h, w) * 0.025))
    mask[:border, :] = cv2.GC_BGD
    mask[-border:, :] = cv2.GC_BGD
    mask[:, :border] = cv2.GC_BGD
    mask[:, -border:] = cv2.GC_BGD
    # The source images contain a separate white sparkle logo in the lower-right.
    mask[int(h * 0.82):, int(w * 0.84):] = cv2.GC_BGD

    sat = hsv[:, :, 1]
    val = hsv[:, :, 2]
    yy, xx = np.mgrid[:h, :w]
    center = ((xx - w / 2) / (w * 0.52)) ** 2 + ((yy - h * 0.48) / (h * 0.58)) ** 2 < 1
    likely = ((sat > 35) | (val < 165)) & center
    strong = ((sat > 70) | (val < 105)) & center
    mask[likely] = cv2.GC_PR_FGD
    mask[strong] = cv2.GC_FGD

    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    cv2.grabCut(bgr, mask, None, bgd, fgd, 8, cv2.GC_INIT_WITH_MASK)
    alpha = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)

    count, labels, stats, _ = cv2.connectedComponentsWithStats((alpha > 0).astype(np.uint8), 8)
    if count > 1:
        main = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        alpha = np.where(labels == main, 255, 0).astype(np.uint8)
    alpha = cv2.morphologyEx(alpha, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=1)
    alpha = cv2.medianBlur(alpha, 3)
    alpha = cv2.GaussianBlur(alpha, (0, 0), 0.65)

    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    rgba = np.dstack([rgb, alpha])
    subject = crop_alpha(Image.fromarray(rgba, 'RGBA'), 2)
    # Keep the supplied palette, but recover a little crispness after matting.
    subject = subject.filter(ImageFilter.UnsharpMask(radius=0.8, percent=125, threshold=2))
    return subject


def remap_lower_body(im: Image.Image, amplitude: float, phase: float, start: float = 0.42) -> Image.Image:
    """Create a serpentine tail motion without changing the upper torso."""
    arr = np.asarray(im.convert('RGBA'))
    h, w = arr.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    progress = np.clip((yy / max(h - 1, 1) - start) / max(1e-6, 1 - start), 0, 1)
    shift = amplitude * (progress ** 1.45) * np.sin(phase + progress * math.pi * 1.15)
    map_x = np.clip(xx - shift, 0, w - 1).astype(np.float32)
    map_y = yy.astype(np.float32)
    warped = cv2.remap(arr, map_x, map_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    # Smoothly blend around the transition line.
    feather = np.clip((progress - 0.02) / 0.12, 0, 1)[..., None]
    out = arr.astype(np.float32) * (1 - feather) + warped.astype(np.float32) * feather
    return crop_alpha(Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), 'RGBA'), 2)


def fold_fin_mantle(im: Image.Image, fold: float) -> Image.Image:
    """Compress or expand the base form's side fins around the body; it still remains non-flying."""
    arr = np.asarray(im.convert('RGBA'))
    h, w = arr.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    xn = xx / max(w - 1, 1)
    yn = yy / max(h - 1, 1)
    side = np.clip((np.abs(xn - 0.5) - 0.08) / 0.42, 0, 1)
    vertical = np.clip((0.76 - yn) / 0.62, 0, 1)
    influence = side * vertical
    scale = np.clip(1.0 - fold * influence, 0.62, 1.28)
    source_xn = 0.5 + (xn - 0.5) / scale
    map_x = np.clip(source_xn * (w - 1), 0, w - 1).astype(np.float32)
    map_y = yy.astype(np.float32)
    warped = cv2.remap(arr, map_x, map_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    return crop_alpha(Image.fromarray(warped, 'RGBA'), 2)


def affine_pose(im: Image.Image, angle: float = 0, scale_x: float = 1, scale_y: float = 1,
                shear: float = 0, flip: bool = False, tint: Tuple[int, int, int] | None = None) -> Image.Image:
    out = im.convert('RGBA')
    if flip:
        out = ImageOps.mirror(out)
    if tint is not None:
        arr = np.asarray(out).copy()
        a = arr[..., 3]
        rgb = arr[..., :3].astype(np.float32)
        rgb = rgb * 0.78 + np.array(tint, dtype=np.float32) * 0.22
        arr[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
        arr[..., 3] = a
        out = Image.fromarray(arr, 'RGBA')
    nw = max(1, int(out.width * scale_x))
    nh = max(1, int(out.height * scale_y))
    out = out.resize((nw, nh), Image.Resampling.LANCZOS)
    if abs(shear) > 1e-5:
        shift = abs(shear) * out.height
        out = out.transform(
            (int(out.width + shift), out.height),
            Image.Transform.AFFINE,
            (1, -shear, shift if shear > 0 else 0, 0, 1, 0),
            Image.Resampling.BICUBIC,
        )
    if abs(angle) > 0.01:
        out = out.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
    return crop_alpha(out, 2)


def pose_variants(master: Image.Image, form: str) -> Dict[str, Image.Image]:
    """Create distinct art sources for all VCMI actions from the supplied concept pose."""
    is_base = form == 'base'

    def prep(tail: float = 0, phase: float = 0, fold: float = 0, **kwargs) -> Image.Image:
        im = master
        if abs(tail) > 0.01:
            im = remap_lower_body(im, tail, phase, 0.40 if is_base else 0.43)
        if is_base and abs(fold) > 0.001:
            im = fold_fin_mantle(im, fold)
        return affine_pose(im, **kwargs)

    poses = {
        'idle': prep(tail=3.0, phase=0.0, fold=0.03),
        'walk': prep(tail=11.0, phase=0.8, fold=0.08, angle=-1.5, shear=-0.025),
        'attack_h': prep(tail=8.0, phase=1.8, fold=0.12, angle=-3.0, shear=-0.08, scale_x=1.03),
        'attack_up': prep(tail=7.0, phase=1.4, fold=0.10, angle=5.5, shear=-0.06),
        'attack_down': prep(tail=9.0, phase=2.2, fold=0.11, angle=-6.0, shear=-0.07),
        'cast': prep(tail=5.0, phase=2.7, fold=-0.035 if is_base else 0.0, scale_x=1.02, scale_y=1.02),
        'defend': prep(tail=4.0, phase=3.1, fold=-0.055 if is_base else 0.0, angle=2.5, scale_x=0.96),
        'damage': prep(tail=10.0, phase=4.0, fold=0.11, angle=-9.0, shear=0.04, tint=(170, 55, 75)),
        'death': prep(tail=5.0, phase=4.7, fold=0.16, angle=-57.0, scale_x=0.94, scale_y=0.94),
        'corpse': prep(tail=2.0, phase=5.0, fold=0.18, angle=-87.0, scale_x=0.82, scale_y=0.82, tint=(95, 105, 118)),
        'special': prep(tail=7.0, phase=5.5, fold=-0.02 if is_base else 0.0, angle=1.5, scale_x=1.04, scale_y=1.04),
        'group': prep(tail=10.0, phase=0.2, fold=-0.06 if is_base else 0.0, angle=0.5, scale_x=1.06, scale_y=1.03),
        'turn': prep(tail=6.0, phase=1.0, fold=0.04, flip=True),
        'resurrect': prep(tail=4.0, phase=2.2, fold=0.02, scale_x=1.01, scale_y=1.01),
    }
    return poses


def create_concept_showcase(base_subject: Image.Image, upgrade_subject: Image.Image) -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    w, h = 1400, 820
    canvas = Image.new('RGB', (w, h), (5, 19, 31))
    d = ImageDraw.Draw(canvas)
    # Ocean-like vertical gradient.
    px = canvas.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        for x in range(w):
            glow = max(0, 1 - math.hypot((x - w * .50) / w, (y - h * .30) / h) * 1.8)
            px[x, y] = (int(5 + 9 * glow), int(19 + 27 * glow + 11 * t), int(31 + 42 * glow + 18 * t))
    d = ImageDraw.Draw(canvas)
    d.text((55, 28), 'NEREID TIDEBORN', font=fnt(FONT_SERIF_BOLD, 52), fill=(239, 210, 132))
    d.text((58, 92), 'Concept-art edition • Neutral Tier 5 • non-flying', font=fnt(FONT_REG, 22), fill=(185, 225, 235))
    d.line((55, 130, 1345, 130), fill=(196, 158, 75), width=2)

    panels = [(45, 160, 675, 755), (725, 160, 1355, 755)]
    for box in panels:
        d.rounded_rectangle(box, radius=18, fill=(9, 34, 49), outline=(214, 177, 86), width=3)
    d.text((72, 177), 'Nereid', font=fnt(FONT_SERIF_BOLD, 35), fill=(238, 214, 148))
    d.text((752, 177), 'Nereid Siren', font=fnt(FONT_SERIF_BOLD, 35), fill=(238, 214, 148))

    def place_subject(subject: Image.Image, box: Tuple[int, int, int, int], max_size: Tuple[int, int]) -> None:
        scale = min(max_size[0] / subject.width, max_size[1] / subject.height)
        im = subject.resize((max(1, int(subject.width * scale)), max(1, int(subject.height * scale))), Image.Resampling.LANCZOS)
        x0, y0, x1, y1 = box
        x = x0 + (x1 - x0 - im.width) // 2
        y = y0 + (y1 - y0 - im.height) // 2
        canvas.paste(im, (x, y), im)

    place_subject(base_subject, (70, 220, 650, 590), (555, 355))
    place_subject(upgrade_subject, (750, 220, 1330, 590), (420, 355))

    base_lines = ['Attack 10   Defense 10', 'Damage 8–12   HP 40', 'Speed 6   Growth 4', 'Cost 550 gold', '+1 allied Luck', 'Grants Summon Boat']
    up_lines = ['Attack 12   Defense 12', 'Damage 10–14   HP 50', 'Speed 7   Growth 4', 'Cost 800 gold', '+2 allied Luck', 'Grants Summon Boat', 'Sacrifice: 1 cast / battle']
    for i, line in enumerate(base_lines):
        col = (91, 226, 181) if i >= 4 else (222, 235, 239)
        d.text((95, 600 + i * 28), line, font=fnt(FONT_BOLD, 18), fill=col)
    for i, line in enumerate(up_lines):
        col = (111, 207, 245) if i in (4, 5) else (235, 133, 189) if i == 6 else (222, 235, 239)
        d.text((775, 600 + i * 25), line, font=fnt(FONT_BOLD, 17), fill=col)
    d.text((55, 782), 'The broad green fin-mantle is decorative and defensive; the unit has no Flying bonus.', font=fnt(FONT_REG, 16), fill=(183, 207, 218))
    canvas.save(CONCEPT_POSTER, quality=95)
    canvas.save(PREVIEW_PATH, quality=95)


def build_icons(form_data: dict, source: Dict[str, Image.Image]) -> None:
    slug = form_data['slug']
    accent = tuple(form_data['accent'])
    form = form_data['form']
    out = DATA / slug
    out.mkdir(parents=True, exist_ok=True)
    card = base.ocean_background((232, 256), accent)
    pose = source['idle'].convert('RGBA')
    pose = base.add_outline(pose, 2)
    scale = min(214 / max(1, pose.height), 216 / max(1, pose.width))
    pose = pose.resize((max(1, int(pose.width * scale)), max(1, int(pose.height * scale))), Image.Resampling.LANCZOS)
    card.alpha_composite(pose, ((232 - pose.width) // 2, 242 - pose.height))
    d = ImageDraw.Draw(card)
    d.rounded_rectangle((2, 2, 229, 253), radius=13, outline=(233, 206, 129, 255), width=3)
    d.rounded_rectangle((6, 6, 225, 249), radius=10, outline=(55, 33, 13, 255), width=2)
    marker = 'I' if form == 'base' else 'II'
    d.ellipse((181, 14, 218, 51), fill=(7, 23, 44, 225), outline=(232, 204, 125, 255), width=2)
    bb = d.textbbox((0, 0), marker, font=fnt(FONT_SERIF_BOLD, 18))
    d.text((199 - (bb[2] - bb[0]) / 2, 20), marker, font=fnt(FONT_SERIF_BOLD, 18), fill=(244, 226, 168, 255))
    card.save(out / 'portrait_232x256.png', optimize=False, compress_level=2)
    card.resize((58, 64), Image.Resampling.LANCZOS).save(out / 'icon_large.png', optimize=False, compress_level=2)
    card.resize((32, 32), Image.Resampling.LANCZOS).save(out / 'icon_small.png', optimize=False, compress_level=2)


def ability_block(luck: int, include_sacrifice: bool) -> dict:
    abilities = {
        'tidalFortuneCore': {
            'type': 'LUCK',
            'val': 1,
            'stacking': 'NereidTidalFortuneCore',
            'propagator': 'ARMY',
            'icon': 'nereid/shared/tidal_luck_64.png',
            'description': '{Tidal Fortune}\nWhile this stack is in an army, allied creatures receive +1 Luck. Additional Nereid stacks do not repeat this layer.'
        },
        'summonBoatGift': {
            'type': 'SPELL',
            'subtype': 'core:summonBoat',
            'val': 1,
            'stacking': 'NereidSummonBoat',
            'propagator': 'HERO',
            'icon': 'nereid/shared/summon_boat_64.png',
            'description': '{Call of the Tides}\nA hero carrying at least one Nereid may cast Summon Boat at Basic mastery while carrying a spellbook. The grant disappears when no Nereid remains in that hero army.'
        }
    }
    if luck >= 2:
        abilities['tidalFortuneCore']['hidden'] = True
        abilities['tidalFortuneGreater'] = {
            'type': 'LUCK',
            'val': 1,
            'stacking': 'NereidTidalFortuneGreater',
            'propagator': 'ARMY',
            'icon': 'nereid/shared/tidal_luck_64.png',
            'description': '{Greater Tidal Fortune}\nThe Nereid Siren adds a second non-stacking +1 layer, producing a total +2 Luck from this creature family.'
        }
    if include_sacrifice:
        abilities.update({
            'sacrificeCaster': {
                'type': 'SPELLCASTER',
                'subtype': 'core:sacrifice',
                'val': 1,
                'icon': 'nereid/shared/sacrifice_64.png',
                'description': '{Siren Sacrifice}\nThis stack can cast Sacrifice at Basic mastery once per battle as an alternative action.'
            },
            'sacrificeCharge': {'type': 'CASTS', 'val': 1},
            'sacrificePower': {
                'type': 'CREATURE_SPELL_POWER',
                'val': 50,
                'description': '{Siren Spell Power}\nSacrifice uses 0.5 Spell Power per surviving Nereid Siren in the casting stack.'
            },
            'meleeByDefault': {'type': 'NO_SPELLCAST_BY_DEFAULT'}
        })
    return abilities


def build_configs() -> None:
    creatures = {}
    for cid, form in FORMS.items():
        s = form['stats']
        slug = form['slug']
        entry = {
            'name': {'singular': form['name'], 'plural': form['plural']},
            'description': form['description'],
            'faction': 'neutral',
            'level': s['level'],
            'cost': s['cost'],
            'speed': s['speed'],
            'hitPoints': s['hitPoints'],
            'attack': s['attack'],
            'defense': s['defense'],
            'damage': s['damage'],
            'fightValue': s['fightValue'],
            'aiValue': s['aiValue'],
            'growth': s['growth'],
            'horde': 0,
            'advMapAmount': s['advMapAmount'],
            'doubleWide': False,
            'hasDoubleWeek': False,
            'excludeFromRandomization': False,
            'special': False,
            'abilities': ability_block(int(form['luck']), cid == 'nereidSiren'),
            'graphics': {
                'animation': f"nereid/{slug}/battle/animation.json",
                'map': f"nereid/{slug}/map/animation.json",
                'mapAttackFromLeft': f"nereid/{slug}/map_attack_left.png",
                'mapAttackFromRight': f"nereid/{slug}/map_attack_right.png",
                'iconLarge': f"nereid/{slug}/icon_large.png",
                'iconSmall': f"nereid/{slug}/icon_small.png",
                'animationTime': {'walk': 0.88, 'attack': 0.90, 'idle': 1.22},
                'timeBetweenFidgets': 3.6,
            },
            'sound': {
                'attack': f"nereid/{slug}/attack.wav",
                'defend': f"nereid/{slug}/defend.wav",
                'killed': f"nereid/{slug}/killed.wav",
                'startMoving': f"nereid/{slug}/startMoving.wav",
                'endMoving': f"nereid/{slug}/endMoving.wav",
                'move': f"nereid/{slug}/move.wav",
                'wince': f"nereid/{slug}/wince.wav",
            },
        }
        if form['upgrade']:
            entry['upgrades'] = [form['upgrade']]
        creatures[cid] = entry
    save_json(CONFIG / 'creatures.json', creatures)
    save_json(MOD / 'mod.json', {
        'name': 'Nereid Tideborn',
        'description': 'Adds the neutral Tier 5 Nereid and Nereid Siren upgrade using the supplied green and blue concept art, complete battle/map animations, generated sounds, non-stacking army Luck auras, conditional Summon Boat, and one Sacrifice cast per upgraded stack.',
        'modType': 'Creatures',
        'version': VERSION,
        'author': 'Custom private mod; concept art supplied by the user',
        'language': 'english',
        'compatibility': {'min': '1.8.0'},
        'keepDisabled': False,
        'licenseName': 'Private-use package; see LICENSE_AND_ART_RIGHTS.txt',
        'creatures': ['config/nereid/creatures.json'],
        'changelog': {
            '1.1.0': [
                'Rebuilt all portraits, map sprites and battle animations from the two supplied concept-art images.',
                'Kept both units non-flying; the base form wing-like structures are treated as a fin-mantle.',
                'Added custom icons to the Luck, Summon Boat and Sacrifice ability descriptions.',
                'Retained the balanced Tier 5 statistics and original generated sea/siren audio set.'
            ],
            '1.0.0': [
                'Initial Nereid and Nereid Siren mechanics package.'
            ]
        }
    })


def make_gif(paths: Sequence[Path], out: Path, duration: int = 95) -> None:
    frames = [Image.open(p).convert('RGBA') for p in paths]
    rendered = []
    for fr in frames:
        bg = Image.new('RGBA', fr.size, (13, 31, 45, 255))
        bg.alpha_composite(fr)
        rendered.append(bg.convert('P', palette=Image.Palette.ADAPTIVE))
    rendered[0].save(out, save_all=True, append_images=rendered[1:], duration=duration, loop=0, optimize=False)



def fast_build_battle_animation(form_data: dict, source: Dict[str, Image.Image]):
    """Same complete VCMI animation set as the original builder, with fast PNG output."""
    slug = form_data['slug']
    form = form_data['form']
    accent = tuple(form_data['accent'])
    target = int(form_data['target_height'])
    out = SPRITES / slug / 'battle'
    out.mkdir(parents=True, exist_ok=True)
    groups = {
        0: base.specs_move(), 1: base.specs_fidget(), 2: base.specs_idle(),
        3: base.specs_hit(), 4: base.specs_defend(),
        5: base.specs_death(False), 6: base.specs_death(True),
        7: base.specs_turn(False), 8: base.specs_turn(True),
        11: base.specs_attack('up', 'attack_up'),
        12: base.specs_attack('horizontal', 'attack_h'),
        13: base.specs_attack('down', 'attack_down'),
        14: base.specs_attack('up', 'cast', special=True),
        15: base.specs_attack('horizontal', 'cast', special=True),
        16: base.specs_attack('down', 'cast', special=True),
        17: base.specs_attack('up', 'special', special=True),
        18: base.specs_attack('horizontal', 'special', special=True),
        19: base.specs_attack('down', 'special', special=True),
        20: base.specs_move_edge(True), 21: base.specs_move_edge(False),
        22: [base.FrameSpec('corpse', 1.0, scale=1.0, splash=0.0)],
        23: [base.FrameSpec('corpse', 1.0, scale=1.0, flip=True, splash=0.0)],
        24: base.specs_resurrect(),
        30: base.specs_cast('up'), 31: base.specs_cast('horizontal'),
        32: base.specs_cast('down'),
        40: base.specs_attack('up', 'group', special=True, group=True),
        41: base.specs_attack('horizontal', 'group', special=True, group=True),
        42: base.specs_attack('down', 'group', special=True, group=True),
        50: base.specs_teleport(True), 51: base.specs_teleport(False),
    }
    sequences = []
    paths: Dict[int, List[Path]] = {}
    for group, specs in groups.items():
        names = []
        paths[group] = []
        for idx, spec in enumerate(specs):
            frame = base.render_frame(source, spec, target, accent, form, seed=group * 100 + idx)
            name = f'g{group:02d}_{idx:02d}.png'
            path = out / name
            # PIL's optimize=True performs a costly exhaustive pass for every frame.
            # Level 2 remains lossless and is substantially faster for this many small PNGs.
            frame.save(path, format='PNG', optimize=False, compress_level=2)
            names.append(name)
            paths[group].append(path)
        sequences.append({'group': group, 'frames': names, 'generateShadow': 0, 'generateOverlay': 1})
    anim = {'basepath': f'nereid/{slug}/battle', 'sequences': sequences}
    save_json(out / 'animation.json', anim)
    return anim, paths

def build_preview(group_paths: Dict[str, Dict[int, List[Path]]]) -> None:
    shutil.copy2(CONCEPT_POSTER, PREVIEW / 'Concept_Art_Showcase.png')
    for cid, groups in group_paths.items():
        make_gif(groups[2], PREVIEW / f'{cid}_idle.gif', 115)
        make_gif(groups[12], PREVIEW / f'{cid}_attack_horizontal.gif', 90)
        make_gif(groups[11], PREVIEW / f'{cid}_attack_up.gif', 90)
        make_gif(groups[13], PREVIEW / f'{cid}_attack_down.gif', 90)
        make_gif(groups[4], PREVIEW / f'{cid}_defend.gif', 105)
        make_gif(groups[5], PREVIEW / f'{cid}_death.gif', 110)
        make_gif(groups[31], PREVIEW / f'{cid}_cast.gif', 100)

    w, h = 1420, 840
    canvas = Image.new('RGB', (w, h), (7, 22, 36))
    d = ImageDraw.Draw(canvas)
    d.text((40, 25), 'Nereid Tideborn — Actual Packaged Assets', font=fnt(FONT_SERIF_BOLD, 40), fill=(236, 210, 139))
    d.text((42, 78), 'Concept-art edition • Neutral Tier 5 • non-flying • VCMI 1.8.0+', font=fnt(FONT_REG, 20), fill=(180, 224, 235))
    xcols = [38, 719]
    for col, (cid, form) in enumerate(FORMS.items()):
        x = xcols[col]
        slug = form['slug']
        card = Image.new('RGB', (660, 690), (11, 32, 49))
        cd = ImageDraw.Draw(card)
        cd.rounded_rectangle((2, 2, 657, 687), radius=15, outline=(218, 181, 91), width=3)
        portrait = Image.open(DATA / slug / 'portrait_232x256.png').convert('RGBA')
        card.paste(portrait, (20, 74), portrait)
        cd.text((20, 18), form['name'], font=fnt(FONT_SERIF_BOLD, 30), fill=(238, 215, 153))
        cd.text((280, 74), f"Attack {form['stats']['attack']}   Defense {form['stats']['defense']}", font=fnt(FONT_BOLD, 17), fill=(220, 234, 238))
        cd.text((280, 106), f"Damage {form['stats']['damage']['min']}–{form['stats']['damage']['max']}   HP {form['stats']['hitPoints']}", font=fnt(FONT_BOLD, 17), fill=(220, 234, 238))
        cd.text((280, 138), f"Speed {form['stats']['speed']}   Growth {form['stats']['growth']}", font=fnt(FONT_BOLD, 17), fill=(220, 234, 238))
        cd.text((280, 170), f"Cost {form['stats']['cost']['gold']} gold", font=fnt(FONT_BOLD, 17), fill=(245, 201, 109))
        cd.text((280, 218), f"Tidal Fortune: +{form['luck']} Luck", font=fnt(FONT_BOLD, 18), fill=(99, 230, 189))
        cd.text((280, 254), 'Summon Boat granted', font=fnt(FONT_BOLD, 15), fill=(99, 209, 237))
        if cid == 'nereidSiren':
            cd.text((280, 288), 'Sacrifice: 1 cast / battle', font=fnt(FONT_BOLD, 15), fill=(231, 119, 175))
        samples = [(2, 'Idle'), (0, 'Move'), (11, 'Attack Up'), (12, 'Attack H'), (13, 'Attack Down'), (4, 'Defend'), (3, 'Damage'), (31, 'Cast'), (5, 'Death')]
        sx, sy = 18, 364
        for idx, (group, label) in enumerate(samples):
            paths = group_paths[cid][group]
            fr = Image.open(paths[len(paths) // 2]).convert('RGBA').resize((120, 94), Image.Resampling.LANCZOS)
            bx = sx + (idx % 5) * 126
            by = sy + (idx // 5) * 136
            card.paste(fr, (bx, by), fr)
            cd.text((bx + 4, by + 96), label, font=fnt(FONT_REG, 12), fill=(200, 222, 228))
        canvas.paste(card, (x, 128))
    d.text((41, 817), 'Included: 31 animation groups per form • 448 battle frames • map sprites • portraits • 20 WAV files • source art • QA report', font=fnt(FONT_REG, 17), fill=(185, 211, 219))
    canvas.save(PREVIEW / 'Actual_Assets_Preview.png', quality=95)
    canvas.save(ASSETS_PREVIEW_PATH, quality=95)


def build_docs() -> None:
    readme = rf'''
NEREID TIDEBORN — CONCEPT-ART EDITION — VCMI MOD {VERSION}
===========================================================

THIS IS THE UPDATED PACKAGE
---------------------------
This version replaces the placeholder/generated creature designs from 1.0.0 with the two concept images supplied by the user:

* Green, dark-haired Nereid — base form.
* Blue, blonde Nereid Siren — upgraded form.

The large green side structures are treated as a fin-mantle, not functional wings. Neither creature has the Flying ability.

EXACT WINDOWS INSTALLATION
--------------------------
1. Close VCMI Launcher, VCMI Map Editor and the game.
2. If an older `nereid-tideborn` folder is installed, delete or rename it first.
3. Open:

       Nereid_Tideborn_ConceptArt_VCMI_{VERSION}.zip

4. Extract the one folder named:

       nereid-tideborn

   into:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\

5. Confirm this exact file exists:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\nereid-tideborn\mod.json

6. Start VCMI Launcher, open Mods, and enable `Nereid Tideborn`.
7. Use VCMI 1.8.0 beta/development or newer. Stable VCMI 1.7.x does not contain the corrected two-target creature casting needed by Sacrifice.

CREATURES
---------
Nereid: neutral Tier 5, non-flying, +1 allied Luck, grants Summon Boat to its hero.
Nereid Siren: upgraded neutral Tier 5, non-flying, +2 allied Luck, grants Summon Boat, and casts Sacrifice once per battle.

SUMMON BOAT RULE
----------------
The spell is granted through a HERO-propagated spell bonus. It exists only while the hero carries at least one Nereid-family creature. Normal VCMI rules still require the hero to own a spellbook.

SACRIFICE RULE
--------------
Use the creature's alternative-action/spell control during the Nereid Siren's turn. Each separate Siren stack has one cast per battle. Sacrifice still needs a valid dead friendly living stack and a valid friendly living stack to consume.

ART AND ANIMATION
-----------------
All portraits, army icons, adventure-map sprites and battle frames in this version are derived from the two supplied concept images. The package contains movement, hover/fidget, idle, damage, defend, death, corpse, resurrection, turn, attack-up, attack-horizontal, attack-down, special/group attack, casting and teleport-compatible animation groups.

FILES TO EDIT
-------------
Statistics and abilities:
    Content\config\nereid\creatures.json

Battle frames:
    Content\sprites\nereid\nereid\battle\
    Content\sprites\nereid\nereid_siren\battle\

Original and extracted concept art:
    source\concept_art\

Sounds:
    Content\sounds\nereid\
'''.lstrip()
    (MOD / 'README_FIRST.txt').write_text(readme, encoding='utf-8')

    (MOD / 'UPGRADE_FROM_1.0.0.txt').write_text(f'''UPGRADE FROM 1.0.0\n==================\n\n1. Close VCMI.\n2. Delete the old `Documents\\My Games\\vcmi\\Mods\\nereid-tideborn` folder.\n3. Extract the new `nereid-tideborn` folder from Nereid_Tideborn_ConceptArt_VCMI_{VERSION}.zip into `Documents\\My Games\\vcmi\\Mods`.\n4. Enable it in VCMI Launcher.\n\nDo not keep two folders containing the same mod ID.\n''', encoding='utf-8')

    (MOD / 'ABILITY_DETAILS.md').write_text('''# Ability implementation\n\n## Tidal Fortune\n\nThe base form carries one non-stacking `LUCK +1` layer propagated to its army. The upgrade carries the same shared layer plus a second separately non-stacking `LUCK +1` layer. This produces exactly +1 for the base form and +2 when at least one upgraded form is present, without allowing split stacks to accumulate unlimited Luck.\n\n## Conditional Summon Boat\n\nBoth forms carry a `SPELL` bonus for `core:summonBoat` with the `HERO` propagator. Removing the final Nereid-family stack removes the propagated spell grant. VCMI's ordinary adventure-spell rules still require a spellbook.\n\n## Sacrifice\n\nThe upgraded form uses `SPELLCASTER: core:sacrifice`, one `CASTS` charge, `CREATURE_SPELL_POWER: 50`, and `NO_SPELLCAST_BY_DEFAULT`. VCMI 1.8.0+ is required because Sacrifice has two selected targets.\n''', encoding='utf-8')

    (MOD / 'BALANCE_NOTES.md').write_text('''# Balance notes\n\n| Creature | Tier | Attack | Defense | Damage | HP | Speed | Growth | Cost | AI value |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n| Nereid | 5 | 10 | 10 | 8–12 | 40 | 6 | 4 | 550 | 720 |\n| Nereid Siren | 5 | 12 | 12 | 10–14 | 50 | 7 | 4 | 800 | 920 |\n\nThe base creature has modest direct damage because an always-on army Luck bonus has strategic value even while the stack waits or defends. The upgrade gains moderate statistics, a second Luck point, and a highly situational one-use spell rather than top-tier raw damage.\n''', encoding='utf-8')

    (MOD / 'TROUBLESHOOTING.md').write_text(r'''# Troubleshooting

## Mod not listed
`mod.json` must be directly inside `Documents\My Games\vcmi\Mods\nereid-tideborn`, not inside a second nested folder.

## Incompatible version
Use a VCMI 1.8 beta/development build or a later stable release. VCMI 1.7.x had a known crash when a creature cast a two-target spell such as Sacrifice.

## Summon Boat does not appear
The army must be led by a hero, the hero must own a spellbook, and at least one Nereid or Nereid Siren must remain in that hero army. Reopen the spellbook after changing the army. Test on a map containing water.

## Sacrifice is unavailable
Use the creature alternative-action/spell control. Sacrifice also needs both a legal dead friendly living stack and a legal friendly living stack to destroy.

## Logs
Inspect `%USERPROFILE%\Documents\My Games\vcmi\VCMI_Client_log.txt` and `VCMI_Server_log.txt`. Search for `nereid-tideborn`, `nereidSiren`, `sacrifice`, `summonBoat`, `animation`, or `resource`.
''', encoding='utf-8')

    (MOD / 'LICENSE_AND_ART_RIGHTS.txt').write_text('''The two concept-art images were supplied by the user for this private mod build. Their copyright and redistribution status are not asserted by this package. Use and redistribute them only if you hold the necessary rights.\n\nThe procedural animation derivatives, package code, documentation and generated sound effects were created for this build. Heroes of Might and Magic III and VCMI names and game data remain the property of their respective owners. No original Heroes III game data is included.\n''', encoding='utf-8')


def validate(group_paths: Dict[str, Dict[int, List[Path]]]) -> None:
    errors: List[str] = []
    checks: List[str] = []
    json_files = list(MOD.rglob('*.json'))
    for p in json_files:
        try:
            json.loads(p.read_text(encoding='utf-8'))
        except Exception as exc:
            errors.append(f'JSON parse failure: {p.relative_to(MOD)}: {exc}')
    checks.append(f'Parsed {len(json_files)} JSON files')

    required_groups = {0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 30, 31, 32, 40, 41, 42, 50, 51}
    total_frames = 0
    for cid, form in FORMS.items():
        slug = form['slug']
        anim_path = SPRITES / slug / 'battle' / 'animation.json'
        anim = json.loads(anim_path.read_text(encoding='utf-8'))
        groups = {int(s['group']) for s in anim['sequences']}
        if groups != required_groups:
            errors.append(f'{cid}: animation group mismatch')
        count = 0
        for seq in anim['sequences']:
            for name in seq['frames']:
                p = anim_path.parent / name
                count += 1
                if not p.exists():
                    errors.append(f'{cid}: missing frame {name}')
                    continue
                im = Image.open(p).convert('RGBA')
                if im.size != (180, 140):
                    errors.append(f'{cid}: bad frame size {name}: {im.size}')
                if not im.getbbox():
                    errors.append(f'{cid}: empty frame {name}')
        total_frames += count
        checks.append(f'{cid}: {len(groups)} groups, {count} battle frames')

        for snd in ['attack', 'defend', 'killed', 'startMoving', 'endMoving', 'move', 'wince', 'cast', 'sirenSong', 'summonBoat']:
            p = SOUNDS / slug / f'{snd}.wav'
            try:
                with wave.open(str(p), 'rb') as wf:
                    if (wf.getnchannels(), wf.getsampwidth(), wf.getframerate()) != (1, 2, 44100):
                        errors.append(f'Bad WAV format: {p.relative_to(MOD)}')
            except Exception as exc:
                errors.append(f'WAV failure: {p.relative_to(MOD)}: {exc}')

    creatures = json.loads((CONFIG / 'creatures.json').read_text(encoding='utf-8'))
    if creatures['nereid'].get('upgrades') != ['nereid-tideborn:nereidSiren']:
        errors.append('Upgrade link is incorrect')
    for cid in ('nereid', 'nereidSiren'):
        if creatures[cid].get('doubleWide') is not False:
            errors.append(f'{cid}: expected single-hex creature')
        if 'FLY' in json.dumps(creatures[cid].get('abilities', {})).upper():
            errors.append(f'{cid}: unexpected Flying ability')
        boat = creatures[cid]['abilities']['summonBoatGift']
        if boat.get('type') != 'SPELL' or boat.get('subtype') != 'core:summonBoat' or boat.get('propagator') != 'HERO':
            errors.append(f'{cid}: Summon Boat configuration is incorrect')
    if creatures['nereidSiren']['abilities']['sacrificeCharge'].get('val') != 1:
        errors.append('Sacrifice charge is not one')
    checks.append(f'Verified {total_frames} battle frames, non-flying status, upgrade link, Luck layers, Summon Boat and Sacrifice configuration')
    checks.append('Verified all 20 WAV files are mono PCM 16-bit 44.1 kHz')

    report = ['NEREID TIDEBORN CONCEPT-ART EDITION — STATIC QA', '================================================', *['PASS: ' + c for c in checks]]
    if errors:
        report.extend(['', 'FAILURES:', *['- ' + e for e in errors]])
    else:
        report.extend(['', 'RESULT: PASSED static validation', 'NOTE: A live engine test still requires Heroes III data and a VCMI 1.8+ runtime.'])
    (MOD / 'QA_REPORT.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
    if errors:
        raise RuntimeError('\n'.join(errors))


def write_manifest_and_zip() -> str:
    lines = []
    for p in sorted(MOD.rglob('*')):
        if p.is_file() and p.name != 'MANIFEST_SHA256.txt':
            lines.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(MOD).as_posix()}')
    (MOD / 'MANIFEST_SHA256.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')

    with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as zf:
        for p in sorted(MOD.rglob('*')):
            if p.is_file():
                zf.write(p, Path(MOD.name) / p.relative_to(MOD))
    with zipfile.ZipFile(ZIP_PATH, 'r') as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f'ZIP integrity failure: {bad}')
        if any(not n.startswith('nereid-tideborn/') for n in zf.namelist()):
            raise RuntimeError('Incorrect ZIP top-level folder')
    sha = hashlib.sha256(ZIP_PATH.read_bytes()).hexdigest()
    SHA_PATH.write_text(f'{sha}  {ZIP_PATH.name}\n', encoding='utf-8')
    return sha


def main() -> None:
    if WORK.exists():
        shutil.rmtree(WORK)
    for output in (ZIP_PATH, SHA_PATH, PREVIEW_PATH, ASSETS_PREVIEW_PATH):
        output.unlink(missing_ok=True)
    base.ensure_dirs()
    (SOURCE / 'concept_art').mkdir(parents=True, exist_ok=True)

    basic_subject = extract_subject(BASIC_INPUT)
    upgrade_subject = extract_subject(UPGRADE_INPUT)
    shutil.copy2(BASIC_INPUT, SOURCE / 'concept_art' / 'Mermaid_basic_supplied.png')
    shutil.copy2(UPGRADE_INPUT, SOURCE / 'concept_art' / 'Mermaid_upgrade_supplied.png')
    basic_subject.save(SOURCE / 'concept_art' / 'Nereid_base_transparent.png', optimize=False, compress_level=2)
    upgrade_subject.save(SOURCE / 'concept_art' / 'Nereid_Siren_upgrade_transparent.png', optimize=False, compress_level=2)

    create_concept_showcase(basic_subject, upgrade_subject)
    # Animation derivatives only need a few times the final battle-frame resolution.
    # Downscaling here keeps the build fast while retaining clean pixel detail.
    def working_copy(im: Image.Image, height: int = 420) -> Image.Image:
        scale = height / max(1, im.height)
        return im.resize((max(1, int(im.width * scale)), height), Image.Resampling.LANCZOS)

    sources = {
        'base': pose_variants(working_copy(basic_subject), 'base'),
        'upgrade': pose_variants(working_copy(upgrade_subject), 'upgrade'),
    }
    pose_dir = SOURCE / 'derived_pose_sources'
    pose_dir.mkdir(parents=True, exist_ok=True)
    for form, poses in sources.items():
        for name, im in poses.items():
            im.save(pose_dir / f'{form}_{name}.png', optimize=False, compress_level=2)

    # Preserve the exact supplied palette rather than recoloring the concept art.
    base.recolor_for_form = lambda sprite, form: sprite.convert('RGBA')

    group_paths: Dict[str, Dict[int, List[Path]]] = {}
    for cid, form in FORMS.items():
        _, groups = fast_build_battle_animation(form, sources[form['form']])
        group_paths[cid] = groups
        base.build_map_animation(form, sources[form['form']])
        build_icons(form, sources[form['form']])
        base.build_sounds(form)

    base.build_ability_icons()
    base.build_tide_effect()
    build_configs()
    build_docs()
    build_preview(group_paths)
    shutil.copy2(Path(__file__), TOOLS / 'build_nereid_concept_mod.py')
    validate(group_paths)
    sha = write_manifest_and_zip()
    print(f'Built: {ZIP_PATH}')
    print(f'SHA256: {sha}')
    print(f'Files: {sum(1 for p in MOD.rglob("*") if p.is_file())}')
    print(f'ZIP size: {ZIP_PATH.stat().st_size / 1024 / 1024:.2f} MiB')


if __name__ == '__main__':
    main()
