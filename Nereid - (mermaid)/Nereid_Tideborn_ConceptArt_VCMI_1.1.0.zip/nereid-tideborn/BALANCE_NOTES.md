# Balance notes

| Creature | Tier | Attack | Defense | Damage | HP | Speed | Growth | Cost | AI value |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Nereid | 5 | 10 | 10 | 8–12 | 40 | 6 | 4 | 550 | 720 |
| Nereid Siren | 5 | 12 | 12 | 10–14 | 50 | 7 | 4 | 800 | 920 |

The base creature has modest direct damage because an always-on army Luck bonus has strategic value even while the stack waits or defends. The upgrade gains moderate statistics, a second Luck point, and a highly situational one-use spell rather than top-tier raw damage.
