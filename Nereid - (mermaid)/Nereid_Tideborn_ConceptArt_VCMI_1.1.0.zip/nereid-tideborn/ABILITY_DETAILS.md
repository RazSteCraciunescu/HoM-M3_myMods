# Ability implementation

## Tidal Fortune

The base form carries one non-stacking `LUCK +1` layer propagated to its army. The upgrade carries the same shared layer plus a second separately non-stacking `LUCK +1` layer. This produces exactly +1 for the base form and +2 when at least one upgraded form is present, without allowing split stacks to accumulate unlimited Luck.

## Conditional Summon Boat

Both forms carry a `SPELL` bonus for `core:summonBoat` with the `HERO` propagator. Removing the final Nereid-family stack removes the propagated spell grant. VCMI's ordinary adventure-spell rules still require a spellbook.

## Sacrifice

The upgraded form uses `SPELLCASTER: core:sacrifice`, one `CASTS` charge, `CREATURE_SPELL_POWER: 50`, and `NO_SPELLCAST_BY_DEFAULT`. VCMI 1.8.0+ is required because Sacrifice has two selected targets.
