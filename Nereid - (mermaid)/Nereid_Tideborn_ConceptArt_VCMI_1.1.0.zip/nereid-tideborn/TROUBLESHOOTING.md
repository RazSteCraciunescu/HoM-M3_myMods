# Troubleshooting

## Mod not listed
`mod.json` must be directly inside `Documents\My Games\vcmi\Mods\nereid-tideborn`, not inside a second nested folder.

## Incompatible version
Use a VCMI 1.8 beta/development build or a later stable release. VCMI 1.7.x had a known crash when a creature cast a two-target spell such as Sacrifice.

## Summon Boat does not appear
The army must be led by a hero, the hero must own a spellbook, and at least one Nereid or Nereid Siren must remain in that hero army. Reopen the spellbook after changing the army. Test on a map containing water.

## Sacrifice is unavailable
Use the creature alternative-action/spell control. Sacrifice also needs both a legal dead friendly living stack and a legal friendly living stack to destroy.

## Logs
Inspect `%USERPROFILE%\Documents\My Games\vcmi\VCMI_Client_log.txt` and `VCMI_Server_log.txt`. Search for `nereid-tideborn`, `nereidSiren`, `sacrifice`, `summonBoat`, `animation`, or `resource`.
