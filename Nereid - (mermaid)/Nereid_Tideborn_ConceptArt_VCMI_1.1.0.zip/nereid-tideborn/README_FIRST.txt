NEREID TIDEBORN — CONCEPT-ART EDITION — VCMI MOD 1.1.0
===========================================================

THIS IS THE UPDATED PACKAGE
---------------------------
This version replaces the placeholder/generated creature designs from 1.0.0 with the two concept images supplied by the user:

* Green, dark-haired Nereid — base form.
* Blue, blonde Nereid Siren — upgraded form.

The large green side structures are treated as a fin-mantle, not functional wings. Neither creature has the Flying ability.

EXACT WINDOWS INSTALLATION
--------------------------
1. Close VCMI Launcher, VCMI Map Editor and the game.
2. If an older `nereid-tideborn` folder is installed, delete or rename it first.
3. Open:

       Nereid_Tideborn_ConceptArt_VCMI_1.1.0.zip

4. Extract the one folder named:

       nereid-tideborn

   into:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\

5. Confirm this exact file exists:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\nereid-tideborn\mod.json

6. Start VCMI Launcher, open Mods, and enable `Nereid Tideborn`.
7. Use VCMI 1.8.0 beta/development or newer. Stable VCMI 1.7.x does not contain the corrected two-target creature casting needed by Sacrifice.

CREATURES
---------
Nereid: neutral Tier 5, non-flying, +1 allied Luck, grants Summon Boat to its hero.
Nereid Siren: upgraded neutral Tier 5, non-flying, +2 allied Luck, grants Summon Boat, and casts Sacrifice once per battle.

SUMMON BOAT RULE
----------------
The spell is granted through a HERO-propagated spell bonus. It exists only while the hero carries at least one Nereid-family creature. Normal VCMI rules still require the hero to own a spellbook.

SACRIFICE RULE
--------------
Use the creature's alternative-action/spell control during the Nereid Siren's turn. Each separate Siren stack has one cast per battle. Sacrifice still needs a valid dead friendly living stack and a valid friendly living stack to consume.

ART AND ANIMATION
-----------------
All portraits, army icons, adventure-map sprites and battle frames in this version are derived from the two supplied concept images. The package contains movement, hover/fidget, idle, damage, defend, death, corpse, resurrection, turn, attack-up, attack-horizontal, attack-down, special/group attack, casting and teleport-compatible animation groups.

FILES TO EDIT
-------------
Statistics and abilities:
    Content\config\nereid\creatures.json

Battle frames:
    Content\sprites\nereid\nereid\battle\
    Content\sprites\nereid\nereid_siren\battle\

Original and extracted concept art:
    source\concept_art\

Sounds:
    Content\sounds\nereid\
