# Balance notes

| Creature | Tier | Attack | Defense | Damage | HP | Speed | Growth | Cost | AI value |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Nereid | 5 | 10 | 10 | 8–12 | 40 | 6 | 4 | 550 | 720 |
| Nereid Siren | 5 | 12 | 12 | 10–14 | 50 | 7 | 4 | 800 | 920 |

The base unit deliberately deals less raw damage than aggressive Tier 5 units because a reliable army-wide +1 Luck has value even when the Nereid does not attack. The upgrade gains moderate combat statistics, +2 Luck, and a strategic one-use spell instead of becoming a high-damage striker.

Tuning points:

* Luck values: `tidalFortune.val`.
* Sacrifice charges: `sacrificeCharge.val`.
* Sacrifice scaling: `sacrificePower.val` (100 = 1 Spell Power per creature; this mod uses 50).
* Costs and statistics are in the normal creature fields.
