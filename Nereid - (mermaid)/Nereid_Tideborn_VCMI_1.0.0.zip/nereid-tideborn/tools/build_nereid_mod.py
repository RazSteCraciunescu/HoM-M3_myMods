from __future__ import annotations

import hashlib
import json
import math
import random
import shutil
import textwrap
import wave
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cv2
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps
from scipy import signal

WORK = Path('/mnt/data/nereid_work')
POSTER = Path('/mnt/data/a_high_resolution_game_mod_showcase_poster_adverti.png')
PACKAGE_ROOT = WORK / 'Nereid_Tideborn_VCMI_1.0.0'
MOD = PACKAGE_ROOT / 'nereid-tideborn'
CONTENT = MOD / 'Content'
CONFIG = CONTENT / 'config' / 'nereid'
SPRITES = CONTENT / 'sprites' / 'nereid'
DATA = CONTENT / 'data' / 'nereid'
SOUNDS = CONTENT / 'sounds' / 'nereid'
PREVIEW = MOD / 'preview'
SOURCE = MOD / 'source'
TOOLS = MOD / 'tools'
ZIP_PATH = Path('/mnt/data/Nereid_Tideborn_VCMI_1.0.0.zip')
SHA_PATH = Path('/mnt/data/Nereid_Tideborn_VCMI_1.0.0_SHA256.txt')
PREVIEW_PATH = Path('/mnt/data/Nereid_Tideborn_preview.png')

MOD_ID = 'nereid-tideborn'
RESOURCE_NS = 'nereid'

FORMS = {
    'nereid': {
        'slug': 'nereid',
        'name': 'Nereid',
        'plural': 'Nereids',
        'form': 'base',
        'target_height': 104,
        'accent': (28, 181, 214),
        'stats': {
            'level': 5,
            'attack': 10,
            'defense': 10,
            'damage': {'min': 8, 'max': 12},
            'hitPoints': 40,
            'speed': 6,
            'growth': 4,
            'cost': {'gold': 550},
            'fightValue': 620,
            'aiValue': 720,
            'advMapAmount': {'min': 4, 'max': 8},
        },
        'luck': 1,
        'description': (
            'Nereids are sea nymphs whose calming presence bends fortune around an army. '
            'They travel over land by riding a living ribbon of water, but they do not fly. '
            'A hero carrying at least one Nereid can use Summon Boat while the hero owns a spellbook.'
        ),
        'upgrade': f'{MOD_ID}:nereidSiren',
    },
    'nereidSiren': {
        'slug': 'nereid_siren',
        'name': 'Nereid Siren',
        'plural': 'Nereid Sirens',
        'form': 'upgrade',
        'target_height': 110,
        'accent': (136, 103, 242),
        'stats': {
            'level': 5,
            'attack': 12,
            'defense': 12,
            'damage': {'min': 10, 'max': 14},
            'hitPoints': 50,
            'speed': 7,
            'growth': 4,
            'cost': {'gold': 800},
            'fightValue': 780,
            'aiValue': 920,
            'advMapAmount': {'min': 3, 'max': 7},
        },
        'luck': 2,
        'description': (
            'Nereid Sirens are elder sea nymphs whose song can bless companions or demand a terrible price. '
            'They grant a stronger army-wide luck bonus, provide Summon Boat to a spellbook-bearing hero, '
            'and each stack may cast Sacrifice once per combat.'
        ),
        'upgrade': None,
    },
}

# Center points of generated sprite poses inside the DALL-E showcase poster.
CENTERS = {
    'base': {
        'idle': (60, 699), 'walk': (132, 699), 'attack_h': (208, 699),
        'attack_up': (284, 699), 'attack_down': (360, 699), 'cast': (437, 699), 'defend': (510, 699),
        'damage': (60, 817), 'death': (132, 817), 'corpse': (208, 817),
        'special': (284, 817), 'group': (360, 817), 'turn': (437, 817), 'resurrect': (510, 817),
    },
    'upgrade': {
        'idle': (604, 699), 'walk': (676, 699), 'attack_h': (748, 699),
        'attack_up': (820, 699), 'attack_down': (892, 699), 'cast': (963, 699), 'defend': (1034, 699),
        'damage': (604, 817), 'death': (676, 817), 'corpse': (748, 817),
        'special': (820, 817), 'group': (892, 817), 'turn': (963, 817), 'resurrect': (1034, 817),
    },
}

FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_SERIF = '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'
FONT_SERIF_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'


def fnt(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def save_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def ensure_dirs() -> None:
    if PACKAGE_ROOT.exists():
        shutil.rmtree(PACKAGE_ROOT)
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    if SHA_PATH.exists():
        SHA_PATH.unlink()
    for p in [CONFIG, SPRITES, DATA, SOUNDS, PREVIEW, SOURCE, TOOLS]:
        p.mkdir(parents=True, exist_ok=True)


def largest_region(mask: np.ndarray) -> np.ndarray:
    # Remove thin table/divider lines accidentally present in the generated source sheet.
    clean = mask.copy()
    binary = (clean > 42).astype(np.uint8)
    count0, labels0, stats0, _ = cv2.connectedComponentsWithStats(binary, 8)
    for i in range(1, count0):
        x, y, w0, h0, area = [int(v) for v in stats0[i]]
        touches_edge = x <= 2 or x + w0 >= clean.shape[1] - 2
        if (w0 <= 5 and h0 >= 28) or (touches_edge and w0 <= 9 and h0 >= 20):
            clean[labels0 == i] = 0

    kernel = np.ones((5, 5), np.uint8)
    linked = cv2.morphologyEx(clean, cv2.MORPH_CLOSE, kernel, iterations=2)
    linked = cv2.dilate(linked, np.ones((7, 7), np.uint8), iterations=1)
    count, labels, stats, centroids = cv2.connectedComponentsWithStats((linked > 0).astype(np.uint8), 8)
    if count <= 1:
        return clean
    h, w = clean.shape
    candidates=[]
    for i in range(1, count):
        area = int(stats[i, cv2.CC_STAT_AREA])
        cx, cy = centroids[i]
        if area >= 18 and cy > h * 0.06:
            center_penalty = 1.0 + abs(cx - w/2) / max(w, 1)
            candidates.append((area / center_penalty, i))
    if not candidates:
        return clean
    _, main = max(candidates)
    mx, my, mw, mh, ma = [int(v) for v in stats[main]]
    pad = 16
    ex0, ey0, ex1, ey1 = mx-pad, my-pad, mx+mw+pad, my+mh+pad
    selected=[main]
    for i in range(1, count):
        if i == main:
            continue
        x, y, wi, hi, area = [int(v) for v in stats[i]]
        intersects = not (x+wi < ex0 or x > ex1 or y+hi < ey0 or y > ey1)
        if intersects and area >= max(10, ma * 0.015):
            selected.append(i)
    keep = np.isin(labels, selected).astype(np.uint8) * 255
    keep = cv2.dilate(keep, np.ones((5, 5), np.uint8), iterations=1)
    return cv2.bitwise_and(clean, keep)


def remove_dark_panel_background(image: Image.Image) -> Image.Image:
    rgb = np.asarray(image.convert('RGB')).astype(np.float32)
    h, w, _ = rgb.shape
    border = np.concatenate([
        rgb[:4, :, :].reshape(-1, 3), rgb[-4:, :, :].reshape(-1, 3),
        rgb[:, :4, :].reshape(-1, 3), rgb[:, -4:, :].reshape(-1, 3)
    ])
    # Darkest border pixels best represent the navy panel rather than water particles.
    luminance_border = border.mean(axis=1)
    bg = np.median(border[luminance_border < np.percentile(luminance_border, 65)], axis=0)
    dist = np.linalg.norm(rgb - bg[None, None, :], axis=2)
    lum = rgb.mean(axis=2)
    chroma = rgb.max(axis=2) - rgb.min(axis=2)
    raw = np.maximum((dist - 8.0) * 10.5, (lum - 30.0) * 4.2)
    raw = np.maximum(raw, (chroma - 18.0) * 3.0)
    alpha = np.clip(raw, 0, 255).astype(np.uint8)
    alpha[(dist < 16) & (lum < 72)] = 0
    alpha = cv2.medianBlur(alpha, 3)
    alpha = largest_region(alpha)
    alpha = cv2.GaussianBlur(alpha, (0, 0), 0.65)
    rgba = np.dstack([rgb.astype(np.uint8), alpha])
    result = Image.fromarray(rgba, 'RGBA')
    bbox = result.getbbox()
    if bbox:
        result = result.crop(bbox)
    return result


def extract_sources() -> Dict[str, Dict[str, Image.Image]]:
    poster = Image.open(POSTER).convert('RGB')
    sources: Dict[str, Dict[str, Image.Image]] = {}
    crops_dir = SOURCE / 'extracted_pose_sources'
    crops_dir.mkdir(parents=True, exist_ok=True)
    for form, poses in CENTERS.items():
        sources[form] = {}
        for pose, (cx, cy) in poses.items():
            # Top and bottom rows have similar body extents; crop tightly to exclude labels and borders.
            if cy < 760:
                box = (cx - 30, 665, cx + 30, 746)
            else:
                box = (cx - 30, 773, cx + 30, 858)
            cut = poster.crop(box)
            transparent = remove_dark_panel_background(cut)
            # Preserve compact pixel-like detail while improving clarity.
            transparent = ImageEnhance.Contrast(transparent).enhance(1.08)
            transparent = transparent.filter(ImageFilter.UnsharpMask(radius=0.8, percent=115, threshold=2))
            transparent.save(crops_dir / f'{form}_{pose}.png', optimize=True)
            sources[form][pose] = transparent
    shutil.copy2(POSTER, SOURCE / 'generated_concept_and_showcase.png')
    return sources


def add_outline(sprite: Image.Image, radius: int = 1) -> Image.Image:
    sprite = sprite.convert('RGBA')
    a = sprite.getchannel('A')
    expanded = a.filter(ImageFilter.MaxFilter(radius * 2 + 1))
    outline_alpha = ImageChops.subtract(expanded, a)
    outline = Image.new('RGBA', sprite.size, (2, 8, 15, 0))
    outline.putalpha(outline_alpha.point(lambda p: min(190, int(p * 0.85))))
    return Image.alpha_composite(outline, sprite)


def recolor_for_form(sprite: Image.Image, form: str) -> Image.Image:
    im = sprite.convert('RGBA')
    arr = np.asarray(im).copy()
    rgb = arr[..., :3].astype(np.float32)
    alpha = arr[..., 3]
    # Slight palette separation while preserving the generated design.
    if form == 'base':
        rgb[..., 1] *= 1.04
        rgb[..., 2] *= 1.08
        rgb[..., 0] *= 0.97
    else:
        rgb[..., 0] *= 1.06
        rgb[..., 2] *= 1.11
        rgb[..., 1] *= 0.98
    arr[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    arr[..., 3] = alpha
    return Image.fromarray(arr, 'RGBA')


@dataclass
class FrameSpec:
    pose: str
    phase: float = 0.0
    scale: float = 1.0
    dx: float = 0.0
    dy: float = 0.0
    angle: float = 0.0
    shear: float = 0.0
    flip: bool = False
    alpha: float = 1.0
    glow: float = 0.0
    splash: float = 0.0
    slash: str | None = None
    teleport: float = 0.0


def transform_sprite(sprite: Image.Image, scale: float, angle: float, shear: float, flip: bool, alpha: float) -> Image.Image:
    im = sprite.convert('RGBA')
    if flip:
        im = ImageOps.mirror(im)
    w = max(1, int(im.width * scale))
    h = max(1, int(im.height * scale))
    im = im.resize((w, h), Image.Resampling.LANCZOS)
    if abs(shear) > 0.001:
        shift = abs(shear) * h
        nw = int(w + shift)
        im = im.transform((nw, h), Image.Transform.AFFINE, (1, -shear, shift if shear > 0 else 0, 0, 1, 0), Image.Resampling.BICUBIC)
    if abs(angle) > 0.01:
        im = im.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
    if alpha < 0.999:
        a = im.getchannel('A').point(lambda p: int(p * max(0.0, min(1.0, alpha))))
        im.putalpha(a)
    return add_outline(im, 1)


def draw_water_ring(layer: Image.Image, center: Tuple[int, int], phase: float, accent: Tuple[int, int, int], strength: float) -> None:
    if strength <= 0:
        return
    d = ImageDraw.Draw(layer)
    cx, cy = center
    for k in range(3):
        r = int(12 + 16 * ((phase + k * 0.26) % 1.0))
        a = int(120 * strength * (1 - ((phase + k * 0.26) % 1.0)))
        d.ellipse((cx - r * 1.65, cy - r * 0.35, cx + r * 1.65, cy + r * 0.35), outline=(*accent, max(0, a)), width=2)


def draw_particles(layer: Image.Image, seed: int, accent: Tuple[int, int, int], amount: float, region=(30, 25, 150, 128)) -> None:
    if amount <= 0:
        return
    rng = random.Random(seed)
    d = ImageDraw.Draw(layer)
    n = int(8 + amount * 22)
    x0, y0, x1, y1 = region
    for _ in range(n):
        x = rng.randint(x0, x1)
        y = rng.randint(y0, y1)
        r = rng.choice([1, 1, 1, 2, 2, 3])
        a = rng.randint(55, 180)
        col = (*accent, int(a * min(1.0, amount)))
        d.ellipse((x-r, y-r, x+r, y+r), fill=col)


def draw_magic_glow(layer: Image.Image, center: Tuple[int, int], radius: int, accent: Tuple[int, int, int], strength: float) -> None:
    if strength <= 0:
        return
    glow = Image.new('RGBA', layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(glow)
    cx, cy = center
    for r in range(radius, 2, -4):
        alpha = int(9 * strength * (1 - r / max(radius, 1)) + 8 * strength)
        d.ellipse((cx-r, cy-r, cx+r, cy+r), fill=(*accent, alpha))
    glow = glow.filter(ImageFilter.GaussianBlur(max(2, radius / 5)))
    layer.alpha_composite(glow)


def draw_slash(layer: Image.Image, direction: str, phase: float, accent: Tuple[int, int, int]) -> None:
    if phase < 0.2 or phase > 0.92:
        return
    d = ImageDraw.Draw(layer)
    p = (phase - 0.2) / 0.72
    a = int(210 * math.sin(math.pi * p))
    if direction == 'up':
        pts = [(106, 112), (119, 84), (130, 48)]
    elif direction == 'down':
        pts = [(104, 73), (122, 96), (143, 116)]
    else:
        pts = [(101, 84), (126, 79), (153, 75)]
    for off, width in [(0, 4), (3, 2)]:
        shifted = [(x, y+off) for x, y in pts]
        d.line(shifted, fill=(*accent, max(0, a - off * 35)), width=width, joint='curve')


def render_frame(source: Dict[str, Image.Image], spec: FrameSpec, target_height: int, accent: Tuple[int, int, int], form: str, seed: int, canvas=(180, 140)) -> Image.Image:
    pose = source.get(spec.pose) or source['idle']
    pose = recolor_for_form(pose, form)
    base_scale = target_height / max(1, pose.height)
    obj = transform_sprite(pose, base_scale * spec.scale, spec.angle, spec.shear, spec.flip, spec.alpha)
    layer = Image.new('RGBA', canvas, (0, 0, 0, 0))
    w, h = canvas
    # A soft generated shadow is more natural than a hard drop shadow.
    shadow = Image.new('RGBA', canvas, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    shadow_w = max(30, int(obj.width * 0.72))
    sd.ellipse((w//2-shadow_w//2+int(spec.dx), h-17, w//2+shadow_w//2+int(spec.dx), h-8), fill=(0, 0, 0, int(82 * spec.alpha)))
    shadow = shadow.filter(ImageFilter.GaussianBlur(2.1))
    layer.alpha_composite(shadow)
    draw_magic_glow(layer, (w//2+12+int(spec.dx), h//2+10+int(spec.dy)), 38, accent, spec.glow)
    draw_water_ring(layer, (w//2+int(spec.dx), h-12), spec.phase, accent, spec.splash)
    draw_particles(layer, seed, accent, spec.glow + spec.splash * 0.45, (35, 20, 158, 130))
    x = int((w - obj.width) / 2 + spec.dx)
    y = int(h - 10 - obj.height + spec.dy)
    layer.alpha_composite(obj, (x, y))
    if spec.slash:
        draw_slash(layer, spec.slash, spec.phase, accent)
    if spec.teleport > 0:
        bands = Image.new('RGBA', canvas, (0, 0, 0, 0))
        bd = ImageDraw.Draw(bands)
        for k in range(7):
            yy = int(18 + k * 16 + 5 * math.sin(spec.phase * math.tau + k))
            bd.rectangle((28, yy, 154, yy+2), fill=(*accent, int(45 * spec.teleport)))
        layer.alpha_composite(bands)
    return layer


def specs_idle() -> List[FrameSpec]:
    return [FrameSpec('idle', i/8, scale=1 + 0.015*math.sin(i*math.tau/8), dy=-2*math.sin(i*math.tau/8), angle=1.2*math.sin(i*math.tau/8), splash=0.28) for i in range(8)]


def specs_fidget() -> List[FrameSpec]:
    return [FrameSpec('idle' if i < 2 or i > 6 else 'cast', i/8, scale=1+0.018*math.sin(i*math.pi/4), dy=-2.5*math.sin(i*math.pi/4), angle=(-2+i*0.5), glow=max(0, math.sin(i*math.pi/7))*0.45, splash=0.32) for i in range(8)]


def specs_move() -> List[FrameSpec]:
    return [FrameSpec('walk', i/8, dx=-4 + i, dy=-abs(math.sin(i*math.pi/2))*3, angle=2*math.sin(i*math.pi/2), shear=0.025*math.sin(i*math.pi/2), splash=0.75) for i in range(8)]


def specs_hit() -> List[FrameSpec]:
    vals = [(0,0,0),(2,-2,-4),(4,-3,-7),(3,-1,-4),(1,0,-1),(0,0,0)]
    return [FrameSpec('damage', i/5, dx=dx, dy=dy, angle=ang, splash=0.35) for i,(dx,dy,ang) in enumerate(vals)]


def specs_defend() -> List[FrameSpec]:
    return [FrameSpec('defend', i/5, dx=-2*math.sin(i*math.pi/5), dy=1+2*math.sin(i*math.pi/5), angle=-3*math.sin(i*math.pi/5), scale=1-0.025*math.sin(i*math.pi/5), glow=0.18, splash=0.42) for i in range(6)]


def specs_attack(direction: str, pose: str, special=False, group=False) -> List[FrameSpec]:
    result=[]
    for i in range(8):
        t=i/7
        lunge=math.sin(math.pi*t)
        dy = (-5*lunge if direction=='up' else 4*lunge if direction=='down' else -1*lunge)
        result.append(FrameSpec(pose, t, scale=1+0.045*lunge, dx=10*lunge, dy=dy, angle=(-5 if direction=='up' else 5 if direction=='down' else -2)*lunge, shear=-0.055*lunge, glow=(0.75 if special else 0.25)*lunge, splash=(0.9 if group else 0.65)*lunge, slash=direction))
    return result


def specs_death(ranged=False) -> List[FrameSpec]:
    result=[]
    for i in range(8):
        t=i/7
        pose='death' if i<5 else 'corpse'
        result.append(FrameSpec(pose,t,scale=1-0.04*t,dx=5*t,dy=3*t,angle=(5 if ranged else -4)*math.sin(math.pi*t),alpha=1.0,splash=0.35*(1-t)))
    return result


def specs_turn(right=False) -> List[FrameSpec]:
    return [FrameSpec('turn', i/6, scale=1-0.05*math.sin(i*math.pi/6), dx=(3 if right else -3)*math.sin(i*math.pi/6), flip=right if i>=3 else False, splash=0.22) for i in range(7)]


def specs_move_edge(start=True) -> List[FrameSpec]:
    return [FrameSpec('walk', i/5, dx=(-8+8*i/5) if start else (8*i/5), dy=-2*math.sin(i*math.pi/5), alpha=(0.55+0.45*i/5) if start else (1-0.2*i/5), splash=0.5) for i in range(6)]


def specs_cast(direction: str) -> List[FrameSpec]:
    result=[]
    for i in range(8):
        t=i/7
        peak=math.sin(math.pi*t)
        dy=(-3 if direction=='up' else 2 if direction=='down' else 0)*peak
        result.append(FrameSpec('cast',t,scale=1+0.03*peak,dy=dy,angle=2*math.sin(t*math.tau),glow=1.0*peak,splash=0.55+0.35*peak))
    return result


def specs_teleport(start=True) -> List[FrameSpec]:
    result=[]
    for i in range(8):
        t=i/7
        alpha=(1-t) if start else t
        scale=(1-0.18*t) if start else (0.82+0.18*t)
        result.append(FrameSpec('cast',t,scale=scale,dy=-8*t if start else -8*(1-t),alpha=max(0.05,alpha),glow=0.9,teleport=1.0,splash=0.25))
    return result


def specs_resurrect() -> List[FrameSpec]:
    result=[]
    for i in range(8):
        t=i/7
        if i<3: pose='corpse'
        elif i<6: pose='resurrect'
        else: pose='idle'
        result.append(FrameSpec(pose,t,alpha=0.45+0.55*t,dy=-3*math.sin(math.pi*t),glow=0.95*math.sin(math.pi*t),splash=0.55))
    return result


def build_battle_animation(form_data: dict, source: Dict[str, Image.Image]) -> Tuple[dict, Dict[int, List[Path]]]:
    slug=form_data['slug']; form=form_data['form']; accent=tuple(form_data['accent']); target=int(form_data['target_height'])
    out=SPRITES/slug/'battle'; out.mkdir(parents=True,exist_ok=True)
    groups: Dict[int,List[FrameSpec]] = {
        0: specs_move(), 1: specs_fidget(), 2: specs_idle(), 3: specs_hit(), 4: specs_defend(),
        5: specs_death(False), 6: specs_death(True), 7: specs_turn(False), 8: specs_turn(True),
        11: specs_attack('up','attack_up'), 12: specs_attack('horizontal','attack_h'), 13: specs_attack('down','attack_down'),
        14: specs_attack('up','cast',special=True), 15: specs_attack('horizontal','cast',special=True), 16: specs_attack('down','cast',special=True),
        17: specs_attack('up','special',special=True), 18: specs_attack('horizontal','special',special=True), 19: specs_attack('down','special',special=True),
        20: specs_move_edge(True), 21: specs_move_edge(False),
        22: [FrameSpec('corpse',1.0,scale=1.0,splash=0.0)], 23: [FrameSpec('corpse',1.0,scale=1.0,flip=True,splash=0.0)],
        24: specs_resurrect(),
        30: specs_cast('up'), 31: specs_cast('horizontal'), 32: specs_cast('down'),
        40: specs_attack('up','group',special=True,group=True), 41: specs_attack('horizontal','group',special=True,group=True), 42: specs_attack('down','group',special=True,group=True),
        50: specs_teleport(True), 51: specs_teleport(False),
    }
    sequences=[]; paths: Dict[int,List[Path]]={}
    for group,specs in groups.items():
        names=[]; paths[group]=[]
        for idx,spec in enumerate(specs):
            frame=render_frame(source,spec,target,accent,form,seed=group*100+idx)
            name=f'g{group:02d}_{idx:02d}.png'; path=out/name
            frame.save(path,optimize=True)
            names.append(name); paths[group].append(path)
        sequences.append({'group':group,'frames':names,'generateShadow':0,'generateOverlay':1})
    anim={'basepath':f'{RESOURCE_NS}/{slug}/battle','sequences':sequences}
    save_json(out/'animation.json',anim)
    return anim,paths


def make_map_frame(source: Dict[str,Image.Image], form_data: dict, i: int) -> Image.Image:
    accent=tuple(form_data['accent']); form=form_data['form']
    pose=recolor_for_form(source['idle' if i%3 else 'walk'],form)
    obj=add_outline(pose,1)
    scale=56/max(1,obj.height)
    obj=obj.resize((max(1,int(obj.width*scale)),56),Image.Resampling.LANCZOS)
    if i>=4:
        obj=ImageOps.mirror(obj)
    canvas=Image.new('RGBA',(72,72),(0,0,0,0))
    shadow=Image.new('RGBA',canvas.size,(0,0,0,0)); d=ImageDraw.Draw(shadow)
    d.ellipse((18,60,55,68),fill=(0,0,0,85)); shadow=shadow.filter(ImageFilter.GaussianBlur(1.4)); canvas.alpha_composite(shadow)
    y=68-obj.height-int(1.5*math.sin(i*math.pi/2))
    canvas.alpha_composite(obj,((72-obj.width)//2,y))
    draw_water_ring(canvas,(36,64),i/8,accent,0.45)
    return canvas


def build_map_animation(form_data:dict,source:Dict[str,Image.Image])->None:
    slug=form_data['slug']; out=SPRITES/slug/'map'; out.mkdir(parents=True,exist_ok=True); (DATA/slug).mkdir(parents=True,exist_ok=True)
    frames=[]
    for i in range(8):
        im=make_map_frame(source,form_data,i); name=f'map_{i:02d}.png'; im.save(out/name,optimize=True); frames.append(name)
    save_json(out/'animation.json',{'basepath':f'{RESOURCE_NS}/{slug}/map','sequences':[{'group':0,'frames':frames,'generateShadow':0,'generateOverlay':1}]})
    # Adventure-map attack images use actual generated attack pose.
    for side,flip in [('right',False),('left',True)]:
        spec=FrameSpec('attack_h',0.55,scale=0.68,dx=1,flip=flip,glow=0.25,splash=0.55,slash='horizontal')
        battle=render_frame(source,spec,int(form_data['target_height']*0.72),tuple(form_data['accent']),form_data['form'],770 if flip else 771,canvas=(72,72))
        battle.save(DATA/slug/f'map_attack_{side}.png',optimize=True)


def ocean_background(size:Tuple[int,int],accent:Tuple[int,int,int])->Image.Image:
    w,h=size; im=Image.new('RGBA',size,(8,24,42,255)); px=im.load()
    for y in range(h):
        for x in range(w):
            horizon=y/h
            glow=max(0,1-math.hypot((x-w*.52)/w,(y-h*.35)/h)*1.7)
            px[x,y]=(int(5+accent[0]*0.12*glow),int(18+accent[1]*0.15*glow+15*horizon),int(35+accent[2]*0.18*glow+28*horizon),255)
    d=ImageDraw.Draw(im)
    for yy in range(int(h*.70),h,7):
        d.arc((4,yy-4,w-4,yy+8),185,355,fill=(80,190,215,70),width=1)
    return im


def build_icons(form_data:dict,source:Dict[str,Image.Image])->None:
    slug=form_data['slug']; accent=tuple(form_data['accent']); form=form_data['form']; out=DATA/slug; out.mkdir(parents=True,exist_ok=True)
    card=ocean_background((232,256),accent)
    pose=recolor_for_form(source['idle'],form)
    pose=add_outline(pose,2)
    scale=205/max(1,pose.height)
    pose=pose.resize((max(1,int(pose.width*scale)),205),Image.Resampling.LANCZOS)
    card.alpha_composite(pose,((232-pose.width)//2,244-pose.height))
    d=ImageDraw.Draw(card)
    d.rounded_rectangle((2,2,229,253),radius=13,outline=(233,206,129,255),width=3)
    d.rounded_rectangle((6,6,225,249),radius=10,outline=(55,33,13,255),width=2)
    # Discreet form marker.
    marker='I' if form=='base' else 'II'
    d.ellipse((181,14,218,51),fill=(7,23,44,225),outline=(232,204,125,255),width=2)
    bb=d.textbbox((0,0),marker,font=fnt(FONT_SERIF_BOLD,18)); d.text((199-(bb[2]-bb[0])/2,20),marker,font=fnt(FONT_SERIF_BOLD,18),fill=(244,226,168,255))
    card.save(out/'portrait_232x256.png',optimize=True)
    card.resize((58,64),Image.Resampling.LANCZOS).save(out/'icon_large.png',optimize=True)
    card.resize((32,32),Image.Resampling.LANCZOS).save(out/'icon_small.png',optimize=True)


def build_ability_icons()->None:
    out=DATA/'shared'; out.mkdir(parents=True,exist_ok=True)
    for size in (32,64,128):
        # Luck: pearl-centered four-leaf sea clover.
        im=Image.new('RGBA',(size,size),(7,22,39,255)); d=ImageDraw.Draw(im)
        cx=cy=size//2; r=size*0.18
        for ang in (45,135,225,315):
            rad=math.radians(ang); x=cx+math.cos(rad)*size*.18; y=cy+math.sin(rad)*size*.18
            d.ellipse((x-r,y-r,x+r,y+r),fill=(48,205,161,255),outline=(151,247,218,255),width=max(1,size//24))
        d.ellipse((cx-size*.09,cy-size*.09,cx+size*.09,cy+size*.09),fill=(232,238,220,255))
        d.rounded_rectangle((1,1,size-2,size-2),radius=max(2,size//9),outline=(223,187,93,255),width=max(1,size//22))
        im.save(out/f'tidal_luck_{size}.png',optimize=True)
        # Summon Boat icon.
        boat=Image.new('RGBA',(size,size),(6,26,48,255)); bd=ImageDraw.Draw(boat)
        bd.polygon([(size*.18,size*.62),(size*.82,size*.62),(size*.70,size*.78),(size*.30,size*.78)],fill=(126,76,34,255),outline=(235,196,112,255))
        bd.line((size*.50,size*.18,size*.50,size*.64),fill=(224,210,167,255),width=max(1,size//18))
        bd.polygon([(size*.52,size*.21),(size*.78,size*.48),(size*.52,size*.48)],fill=(222,235,239,255),outline=(103,193,221,255))
        for y in (size*.82,size*.88): bd.arc((size*.08,y-size*.05,size*.92,y+size*.06),185,355,fill=(62,210,235,255),width=max(1,size//20))
        bd.rounded_rectangle((1,1,size-2,size-2),radius=max(2,size//9),outline=(223,187,93,255),width=max(1,size//22))
        boat.save(out/f'summon_boat_{size}.png',optimize=True)
        # Sacrifice icon.
        sac=Image.new('RGBA',(size,size),(36,8,25,255)); sd=ImageDraw.Draw(sac)
        sd.polygon([(size*.50,size*.10),(size*.76,size*.58),(size*.62,size*.87),(size*.38,size*.87),(size*.24,size*.58)],fill=(204,31,69,255),outline=(255,175,91,255))
        sd.line((size*.50,size*.22,size*.50,size*.74),fill=(255,225,148,255),width=max(1,size//16))
        sd.line((size*.34,size*.48,size*.66,size*.48),fill=(255,225,148,255),width=max(1,size//16))
        sd.rounded_rectangle((1,1,size-2,size-2),radius=max(2,size//9),outline=(223,187,93,255),width=max(1,size//22))
        sac.save(out/f'sacrifice_{size}.png',optimize=True)


def build_tide_effect()->None:
    out=SPRITES/'effects'/'tide_blessing'; out.mkdir(parents=True,exist_ok=True); names=[]
    for i in range(12):
        t=i/11; im=Image.new('RGBA',(128,128),(0,0,0,0)); d=ImageDraw.Draw(im)
        peak=math.sin(math.pi*t)
        for k in range(4):
            r=int(12+42*((t+k*.18)%1)); a=int(165*peak*(1-k*.13))
            d.ellipse((64-r*1.25,76-r*.28,64+r*1.25,76+r*.28),outline=(45,205,235,max(0,a)),width=2)
        for k in range(9):
            ang=(k/9)*math.tau+t*2.2; rr=20+28*peak
            x=64+math.cos(ang)*rr; y=61+math.sin(ang)*rr*.55
            d.ellipse((x-2,y-2,x+2,y+2),fill=(183,244,238,int(210*peak)))
        im=im.filter(ImageFilter.GaussianBlur(.45)); name=f'effect_{i:02d}.png'; im.save(out/name,optimize=True); names.append(name)
    save_json(out/'animation.json',{'basepath':f'{RESOURCE_NS}/effects/tide_blessing','sequences':[{'group':0,'frames':names,'generateShadow':0,'generateOverlay':0}]})


def normalize(x:np.ndarray,peak=.90)->np.ndarray:
    x=np.asarray(x,dtype=np.float64); m=float(np.max(np.abs(x))) if x.size else 1.0
    if m>0: x=x/m*peak
    return np.clip(x,-1,1)


def env(n:int,sr:int,a=.03,r=.15)->np.ndarray:
    e=np.ones(n); na=min(n,max(1,int(a*sr))); nr=min(n,max(1,int(r*sr)))
    e[:na]=np.linspace(0,1,na); e[-nr:]=np.linspace(1,0,nr); return e


def filtered_noise(n:int,sr:int,lo:float,hi:float,rng:np.random.Generator)->np.ndarray:
    x=rng.normal(0,1,n)
    sos=signal.butter(4,[max(10,lo),min(sr/2-100,hi)],btype='band',fs=sr,output='sos')
    return signal.sosfilt(sos,x)


def water_splash(duration:float,sr:int,seed:int,bright=.5)->np.ndarray:
    rng=np.random.default_rng(seed); n=int(duration*sr); t=np.arange(n)/sr
    high=filtered_noise(n,sr,450,7800,rng)*np.exp(-t*(5.5+bright*2))
    low=filtered_noise(n,sr,60,720,rng)*np.exp(-t*7.5)
    bubbles=np.zeros(n)
    for k in range(7):
        start=int(rng.uniform(0,duration*.7)*sr); dur=min(n-start,int(rng.uniform(.04,.12)*sr))
        if dur<=0: continue
        tt=np.arange(dur)/sr; f=rng.uniform(260,950)*(1+1.4*tt/max(tt[-1] if dur>1 else .01,.01))
        phase=2*np.pi*np.cumsum(f)/sr; bubbles[start:start+dur]+=np.sin(phase)*np.exp(-tt*24)*rng.uniform(.08,.23)
    return normalize((.52+bright*.2)*high+.40*low+bubbles,.78)


def siren_voice(duration:float,sr:int,base:float,seed:int,descend=False)->np.ndarray:
    rng=np.random.default_rng(seed); n=int(duration*sr); t=np.arange(n)/sr
    contour=(1.10-.40*t/duration) if descend else (1+.07*np.sin(np.pi*t/duration)+.025*np.sin(2*np.pi*1.3*t))
    vibrato=1+.012*np.sin(2*np.pi*5.2*t)
    f=base*contour*vibrato; phase=2*np.pi*np.cumsum(f)/sr
    x=np.sin(phase)+.34*np.sin(2*phase+.3)+.16*np.sin(3*phase+1.0)
    breath=filtered_noise(n,sr,500,5000,rng)
    x=(.82*x+.18*breath)*env(n,sr,.08,.24)
    # Gentle watery echo.
    echo=np.zeros_like(x); delay=int(.09*sr); echo[delay:]=x[:-delay]*.24
    return normalize(x+echo,.76)


def chime(duration:float,sr:int,seed:int,root:float)->np.ndarray:
    rng=np.random.default_rng(seed); n=int(duration*sr); t=np.arange(n)/sr; x=np.zeros(n)
    for mul,amp,dec in [(1,.55,2.8),(1.5,.28,3.8),(2.01,.22,4.6),(2.99,.12,5.5)]:
        phase=rng.uniform(0,math.tau); x+=amp*np.sin(2*np.pi*root*mul*t+phase)*np.exp(-t*dec)
    return normalize(x*env(n,sr,.005,.18),.68)


def mix_at(base:np.ndarray,clip:np.ndarray,start:int,gain=1.0)->None:
    end=min(len(base),start+len(clip))
    if end>start: base[start:end]+=clip[:end-start]*gain


def synth_sound(kind:str,form:str,sr=44100)->np.ndarray:
    up=form=='upgrade'; seed=9200+(200 if up else 0)+sum(map(ord,kind)); rng=np.random.default_rng(seed)
    base=260 if up else 235
    if kind=='attack':
        dur=.92; x=np.zeros(int(dur*sr)); mix_at(x,siren_voice(.58,sr,base*1.25,seed,False),0,.62); mix_at(x,water_splash(.58,sr,seed+1,.85),int(.20*sr),.95)
    elif kind=='defend':
        dur=.62; x=np.zeros(int(dur*sr)); mix_at(x,chime(.55,sr,seed,520 if up else 470),0,.55); mix_at(x,water_splash(.42,sr,seed+1,.35),int(.08*sr),.65)
    elif kind=='killed':
        dur=1.45; x=np.zeros(int(dur*sr)); mix_at(x,siren_voice(1.25,sr,base*1.15,seed,True),0,.85); mix_at(x,water_splash(.85,sr,seed+1,.55),int(.50*sr),.85)
    elif kind=='move':
        dur=.58; x=water_splash(dur,sr,seed,.35); x*=.62
    elif kind=='startMoving':
        dur=.36; x=water_splash(dur,sr,seed,.25)*.68
    elif kind=='endMoving':
        dur=.42; x=water_splash(dur,sr,seed,.45)*.75
    elif kind=='wince':
        dur=.48; x=siren_voice(dur,sr,base*1.75,seed,True)*.68
    elif kind=='cast':
        dur=1.05; x=np.zeros(int(dur*sr)); mix_at(x,chime(.95,sr,seed,610 if up else 560),0,.8); mix_at(x,siren_voice(.80,sr,base*1.4,seed+1,False),int(.10*sr),.42); mix_at(x,water_splash(.55,sr,seed+2,.65),int(.40*sr),.55)
    elif kind=='sirenSong':
        dur=2.25; x=siren_voice(dur,sr,base,seed,False)
    elif kind=='summonBoat':
        dur=1.35; x=np.zeros(int(dur*sr)); mix_at(x,chime(1.25,sr,seed,440),0,.72); mix_at(x,water_splash(.92,sr,seed+1,.75),int(.28*sr),.88)
    else: raise ValueError(kind)
    return normalize(x,.9)


def write_wav(path:Path,x:np.ndarray,sr=44100)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    pcm=(np.clip(x,-1,1)*32767).astype('<i2')
    with wave.open(str(path),'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr); wf.writeframes(pcm.tobytes())


def build_sounds(form_data:dict)->None:
    slug=form_data['slug']; out=SOUNDS/slug
    for kind in ['attack','defend','killed','startMoving','endMoving','move','wince','cast','sirenSong','summonBoat']:
        write_wav(out/f'{kind}.wav',synth_sound(kind,form_data['form']))


def ability_block(luck:int,include_sacrifice:bool)->dict:
    # The +2 upgrade is represented as two independently non-stacking +1 layers.
    # This guarantees exactly +2 when base and upgraded stacks coexist, without
    # depending on which same-stacking bonus the engine encounters first.
    abilities={
        'tidalFortuneCore': {
            'type':'LUCK', 'val':1, 'stacking':'NereidTidalFortuneCore', 'propagator':'ARMY',
            'description':'{Tidal Fortune}\nWhile this stack is in an army, allied creatures receive +1 Luck. Additional Nereid stacks do not repeat this layer.'
        },
        'summonBoatGift': {
            'type':'SPELL', 'subtype':'core:summonBoat', 'val':1, 'stacking':'NereidSummonBoat', 'propagator':'HERO',
            'description':'{Call of the Tides}\nA hero carrying at least one Nereid may cast Summon Boat at Basic mastery while carrying a spellbook. The spell is removed automatically when no Nereid remains in the hero army.'
        }
    }
    if luck >= 2:
        abilities['tidalFortuneCore']['hidden']=True
        abilities['tidalFortuneGreater']={
            'type':'LUCK', 'val':1, 'stacking':'NereidTidalFortuneGreater', 'propagator':'ARMY',
            'description':'{Greater Tidal Fortune}\nThe Nereid Siren supplies a second non-stacking +1 layer, for a total army bonus of +2 Luck. Any mixture or number of Nereid stacks is capped at +2 from this creature family.'
        }
    if include_sacrifice:
        abilities.update({
            'sacrificeCaster': {
                'type':'SPELLCASTER','subtype':'core:sacrifice','val':1,
                'description':'{Siren Sacrifice}\nThis stack can cast Sacrifice at Basic mastery as an alternative action on its turn.'
            },
            'sacrificeCharge': {'type':'CASTS','val':1},
            'sacrificePower': {
                'type':'CREATURE_SPELL_POWER','val':50,
                'description':'{Siren Spell Power}\nSacrifice uses 0.5 Spell Power per surviving Nereid Siren in the casting stack.'
            },
            'meleeByDefault': {'type':'NO_SPELLCAST_BY_DEFAULT'}
        })
    return abilities


def build_configs()->None:
    creatures={}
    for cid,f in FORMS.items():
        s=f['stats']; slug=f['slug']
        entry={
            'name':{'singular':f['name'],'plural':f['plural']},
            'description':f['description'],
            'faction':'neutral','level':s['level'],'cost':s['cost'],'speed':s['speed'],'hitPoints':s['hitPoints'],
            'attack':s['attack'],'defense':s['defense'],'damage':s['damage'],'fightValue':s['fightValue'],'aiValue':s['aiValue'],
            'growth':s['growth'],'horde':0,'advMapAmount':s['advMapAmount'],'doubleWide':False,'hasDoubleWeek':False,
            'excludeFromRandomization':False,'special':False,
            'abilities':ability_block(int(f['luck']),cid=='nereidSiren'),
            'graphics':{
                'animation':f'{RESOURCE_NS}/{slug}/battle/animation.json','map':f'{RESOURCE_NS}/{slug}/map/animation.json',
                'mapAttackFromLeft':f'{RESOURCE_NS}/{slug}/map_attack_left.png','mapAttackFromRight':f'{RESOURCE_NS}/{slug}/map_attack_right.png',
                'iconLarge':f'{RESOURCE_NS}/{slug}/icon_large.png','iconSmall':f'{RESOURCE_NS}/{slug}/icon_small.png',
                'animationTime':{'walk':0.86,'attack':0.86,'idle':1.20},'timeBetweenFidgets':3.7
            },
            'sound':{
                'attack':f'{RESOURCE_NS}/{slug}/attack.wav','defend':f'{RESOURCE_NS}/{slug}/defend.wav','killed':f'{RESOURCE_NS}/{slug}/killed.wav',
                'startMoving':f'{RESOURCE_NS}/{slug}/startMoving.wav','endMoving':f'{RESOURCE_NS}/{slug}/endMoving.wav',
                'move':f'{RESOURCE_NS}/{slug}/move.wav','wince':f'{RESOURCE_NS}/{slug}/wince.wav'
            }
        }
        if f['upgrade']:
            entry['upgrades']=[f['upgrade']]
        creatures[cid]=entry
    save_json(CONFIG/'creatures.json',creatures)
    manifest={
        'name':'Nereid Tideborn',
        'description':'Adds the neutral Tier 5 Nereid and Nereid Siren upgrade, with complete generated battle/map art, original sounds, non-stacking army luck auras, conditional Summon Boat for heroes, and one Sacrifice cast per upgraded stack.',
        'modType':'Creatures','version':'1.0.0','author':'OpenAI-assisted custom mod package','language':'english',
        'compatibility':{'min':'1.8.0'},'keepDisabled':False,
        'licenseName':'CC0-1.0 for original package assets and code, to the extent permitted',
        'creatures':['config/nereid/creatures.json'],
        'changelog':{'1.0.0':['Added Nereid and Nereid Siren.','Added +1/+2 non-stacking Tidal Fortune luck aura.','Added conditional Summon Boat spell propagation to a spellbook-bearing hero.','Added one-per-stack Sacrifice casting for Nereid Sirens.','Added full battle animation group coverage, map sprites, icons, effects and original procedural sounds.']}
    }
    save_json(MOD/'mod.json',manifest)


def make_gif(paths:Sequence[Path],out:Path,duration=95)->None:
    frames=[Image.open(p).convert('RGBA') for p in paths]
    # Put transparency on a neutral backdrop for common GIF viewers.
    rendered=[]
    for fr in frames:
        bg=Image.new('RGBA',fr.size,(13,31,45,255)); bg.alpha_composite(fr); rendered.append(bg.convert('P',palette=Image.Palette.ADAPTIVE))
    rendered[0].save(out,save_all=True,append_images=rendered[1:],duration=duration,loop=0,optimize=False)


def build_preview(group_paths:Dict[str,Dict[int,List[Path]]])->None:
    shutil.copy2(POSTER,PREVIEW/'Generated_Showcase_Poster.png')
    shutil.copy2(POSTER,PREVIEW_PATH)
    for cid,groups in group_paths.items():
        make_gif(groups[2],PREVIEW/f'{cid}_idle.gif',115)
        make_gif(groups[12],PREVIEW/f'{cid}_attack.gif',90)
        make_gif(groups[31],PREVIEW/f'{cid}_cast.gif',100)
    # Exact asset preview generated from the files that ship in the archive.
    W,H=1280,760; canvas=Image.new('RGB',(W,H),(7,22,36)); d=ImageDraw.Draw(canvas)
    d.text((40,25),'Nereid Tideborn — Actual Packaged Assets',font=fnt(FONT_SERIF_BOLD,38),fill=(236,210,139))
    d.text((42,76),'Neutral Tier 5 • non-flying • VCMI 1.8.0+',font=fnt(FONT_REG,20),fill=(180,224,235))
    xcols=[72,660]
    for col,(cid,f) in enumerate(FORMS.items()):
        x=xcols[col]; accent=tuple(f['accent']); slug=f['slug']
        card=Image.new('RGB',(540,590),(11,32,49)); cd=ImageDraw.Draw(card)
        cd.rounded_rectangle((2,2,537,587),radius=15,outline=(218,181,91),width=3)
        portrait=Image.open(DATA/slug/'portrait_232x256.png').convert('RGBA'); card.paste(portrait,(20,74),portrait)
        cd.text((20,18),f['name'],font=fnt(FONT_SERIF_BOLD,30),fill=(238,215,153))
        cd.text((280,74),f"Attack {f['stats']['attack']}   Defense {f['stats']['defense']}",font=fnt(FONT_BOLD,17),fill=(220,234,238))
        cd.text((280,106),f"Damage {f['stats']['damage']['min']}–{f['stats']['damage']['max']}   HP {f['stats']['hitPoints']}",font=fnt(FONT_BOLD,17),fill=(220,234,238))
        cd.text((280,138),f"Speed {f['stats']['speed']}   Growth {f['stats']['growth']}",font=fnt(FONT_BOLD,17),fill=(220,234,238))
        cd.text((280,170),f"Cost {f['stats']['cost']['gold']} gold",font=fnt(FONT_BOLD,17),fill=(245,201,109))
        cd.text((280,218),f"Tidal Fortune: +{f['luck']} Luck",font=fnt(FONT_BOLD,18),fill=(99,230,189))
        cd.text((280,254),'Summon Boat granted',font=fnt(FONT_BOLD,15),fill=(99,209,237))
        if cid=='nereidSiren': cd.text((280,288),'Sacrifice: 1 cast / battle',font=fnt(FONT_BOLD,15),fill=(231,119,175))
        samples=[(2,'Idle'),(0,'Move'),(12,'Attack'),(31,'Cast'),(4,'Defend'),(3,'Damage'),(5,'Death')]
        sx=18; sy=366
        for idx,(group,label) in enumerate(samples):
            fr=Image.open(group_paths[cid][group][len(group_paths[cid][group])//2]).convert('RGBA').resize((116,91),Image.Resampling.LANCZOS)
            bx=sx+(idx%4)*127; by=sy+(idx//4)*111
            card.paste(fr,(bx,by),fr); cd.text((bx+8,by+88),label,font=fnt(FONT_REG,13),fill=(200,222,228))
        canvas.paste(card,(x,132))
    d.text((41,724),'Included: 31 animation groups per form • 20 WAV files • map sprites • portraits • source crops • validation report',font=fnt(FONT_REG,17),fill=(185,211,219))
    canvas.save(PREVIEW/'Actual_Assets_Preview.png',quality=95)


def build_docs()->None:
    readme=r'''
NEREID TIDEBORN — VCMI CREATURE MOD 1.0.0
==========================================

WHAT THIS MOD ADDS
------------------
* Nereid — neutral Tier 5 base creature.
* Nereid Siren — upgraded neutral Tier 5 creature.
* Both are walking/surface-sliding units. They do NOT have the Flying ability.
* Nereid gives the allied army +1 Luck.
* Nereid Siren gives the allied army +2 Luck.
* The base +1 layer and the upgrade-only +1 layer are each independently non-stacking. Any mix of the two forms therefore gives +1 or +2, never +3 or more.
* Either form gives its current hero Summon Boat at Basic mastery while at least one creature remains in the hero army.
* Summon Boat requires that hero to own a spellbook; this is enforced by VCMI's normal spell-casting rules.
* Each Nereid Siren stack can cast Sacrifice once per battle as an alternative action.

REQUIRED VCMI VERSION
---------------------
VCMI 1.8.0 development build or newer is required for the corrected two-target creature casting used by Sacrifice.
VCMI 1.7.x can load ordinary custom creatures, but Sacrifice/Teleport used as creature SPELLCASTER actions were affected by a crash that was fixed for 1.8 development.

EXACT WINDOWS INSTALLATION
--------------------------
1. Close VCMI Launcher, VCMI Map Editor and the game.
2. Open Nereid_Tideborn_VCMI_1.0.0.zip.
3. Extract the single folder named:

       nereid-tideborn

   into:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\

4. Confirm this exact file exists:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\nereid-tideborn\mod.json

5. Do not leave an accidental double folder such as:

       ...\nereid-tideborn\nereid-tideborn\mod.json

6. Start VCMI Launcher.
7. Open Mods.
8. Enable "Nereid Tideborn".
9. Start VCMI Map Editor and make a small test map.

FIRST TEST MAP
--------------
1. Use a map with water so Summon Boat is relevant.
2. Place a hero and make sure the hero owns a spellbook.
3. Give the hero at least one Nereid or Nereid Siren.
4. On the adventure map, open the hero spellbook. Summon Boat should be available while the creature is carried.
5. Move every Nereid/Nereid Siren out of the hero army, then reopen the spellbook. The temporary grant should be gone.
6. Start a battle and inspect allied stacks: the base form supplies +1 Luck and the upgraded form supplies +2 Luck.
7. Give the hero both forms at once: the expected result is +2, not +3.
8. During a Nereid Siren stack's turn, use the alternative action / creature spellbook control and select Sacrifice.
9. The stack has one Sacrifice charge for that battle. A second cast by the same stack should not be available.

IMPORTANT SACRIFICE NOTES
-------------------------
* Sacrifice is the original Heroes III spell and follows its ordinary target restrictions.
* It requires a valid dead friendly living stack to restore and a valid friendly living stack to sacrifice.
* Each separate Nereid Siren stack receives one charge. Splitting the army into several stacks therefore creates several casters, just as it does for other creature spellcasters.
* The configured creature spell power is 0.5 Spell Power per surviving Siren in the casting stack.

EDITING
-------
Statistics and abilities:
    Content\config\nereid\creatures.json

Battle frames:
    Content\sprites\nereid\nereid\battle\
    Content\sprites\nereid\nereid_siren\battle\

Icons and map-attack images:
    Content\data\nereid\

Sounds:
    Content\sounds\nereid\

Rebuild source:
    tools\build_nereid_mod.py

The generated artwork and procedural sounds in this package were created specifically for this mod. No WoG, HotA, Warcraft or third-party Discord art/audio is redistributed.
'''.lstrip()
    (MOD/'README_FIRST.txt').write_text(readme,encoding='utf-8')
    ability='''# Ability implementation

## Tidal Fortune

Both creatures carry a normal `LUCK +1` bonus with the `ARMY` propagator and stacking key `NereidTidalFortuneCore`. The upgrade also carries a second `LUCK +1` layer using `NereidTidalFortuneGreater`. Each layer is independently non-stacking, so base-only armies receive +1, any army with an upgrade receives +2, and splitting or mixing stacks cannot raise this family bonus above +2.

## Conditional Summon Boat

Each creature carries a `SPELL` bonus for `core:summonBoat` with the `HERO` propagator. VCMI copies that bonus to the hero only while the creature belongs to a hero-led army. Removing the final Nereid removes the propagated bonus. VCMI's standard spell validation still requires a spellbook.

The grant uses Basic mastery. A hero's better Water Magic mastery can still improve the spell through normal VCMI spell-mastery resolution.

## Sacrifice

Nereid Sirens have:

```json
"type": "SPELLCASTER",
"subtype": "core:sacrifice",
"val": 1
```

They also have `CASTS: 1`, `CREATURE_SPELL_POWER: 50`, and `NO_SPELLCAST_BY_DEFAULT`. This makes melee/movement the default action while keeping Sacrifice in the creature's alternative-action spellbook.

VCMI 1.8.0+ is required because Sacrifice needs two selected targets when cast by a creature.
'''
    (MOD/'ABILITY_DETAILS.md').write_text(ability,encoding='utf-8')
    balance='''# Balance notes

| Creature | Tier | Attack | Defense | Damage | HP | Speed | Growth | Cost | AI value |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Nereid | 5 | 10 | 10 | 8–12 | 40 | 6 | 4 | 550 | 720 |
| Nereid Siren | 5 | 12 | 12 | 10–14 | 50 | 7 | 4 | 800 | 920 |

The base unit deliberately deals less raw damage than aggressive Tier 5 units because a reliable army-wide +1 Luck has value even when the Nereid does not attack. The upgrade gains moderate combat statistics, +2 Luck, and a strategic one-use spell instead of becoming a high-damage striker.

Tuning points:

* Luck values: `tidalFortune.val`.
* Sacrifice charges: `sacrificeCharge.val`.
* Sacrifice scaling: `sacrificePower.val` (100 = 1 Spell Power per creature; this mod uses 50).
* Costs and statistics are in the normal creature fields.
'''
    (MOD/'BALANCE_NOTES.md').write_text(balance,encoding='utf-8')
    troubleshooting=r'''# Troubleshooting

## The launcher says the mod is incompatible
Install a current VCMI 1.8 development build or a later release. The manifest intentionally requires 1.8.0.

## The mod is not listed
Confirm that `mod.json` is directly inside `Documents\\My Games\\vcmi\\Mods\\nereid-tideborn` and not one folder deeper.

## Summon Boat is not shown
Check all of the following:

1. The army is led by a hero, not stored only in a town garrison.
2. The hero owns a spellbook.
3. At least one Nereid or Nereid Siren remains in that hero's army.
4. Test on a map containing water; the original Summon Boat spell is marked as water-map-only.
5. Close and reopen the spellbook after changing the army.

## I cannot find Sacrifice on the Siren's turn
Use VCMI's alternative-action / creature-spellbook button. The unit is configured with `NO_SPELLCAST_BY_DEFAULT`, so ordinary movement and melee remain the default cursor mode.

## Sacrifice has no valid target
The spell needs both a legal dead friendly living stack and a legal friendly living stack to destroy. Undead, mechanical, siege-weapon and gargoyle targets are excluded by the original spell.

## Collect logs
After reproducing the problem, inspect:

* `%USERPROFILE%\\Documents\\My Games\\vcmi\\VCMI_Client_log.txt`
* `%USERPROFILE%\\Documents\\My Games\\vcmi\\VCMI_Server_log.txt`

Search for `nereid-tideborn`, `nereidSiren`, `summonBoat`, `sacrifice`, `animation`, or `resource`.
'''
    (MOD/'TROUBLESHOOTING.md').write_text(troubleshooting,encoding='utf-8')
    license_text='''Original generated artwork, procedural audio, documentation and package code are dedicated under CC0 1.0 to the extent permitted.\n\nHeroes of Might and Magic III, VCMI and their names/assets remain the property of their respective owners. This archive does not include original game data.\n'''
    (MOD/'LICENSE.txt').write_text(license_text,encoding='utf-8')


def validate(group_paths:Dict[str,Dict[int,List[Path]]])->List[str]:
    checks=[]; errors=[]
    # JSON parsing.
    json_files=list(MOD.rglob('*.json'))
    for p in json_files:
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'JSON parse failure: {p.relative_to(MOD)}: {e}')
    checks.append(f'Parsed {len(json_files)} JSON files')
    creatures=json.loads((CONFIG/'creatures.json').read_text(encoding='utf-8'))
    required_groups={0,1,2,3,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,30,31,32,40,41,42,50,51}
    for cid,f in FORMS.items():
        entry=creatures[cid]; slug=f['slug']
        if entry.get('doubleWide') is not False: errors.append(f'{cid}: expected single-hex creature')
        if any('FLY' in json.dumps(v).upper() for v in entry.get('abilities',{}).values()): errors.append(f'{cid}: unexpected flying ability')
        anim_path=SPRITES/slug/'battle'/'animation.json'; anim=json.loads(anim_path.read_text())
        got={int(s['group']) for s in anim['sequences']}
        if got!=required_groups: errors.append(f'{cid}: animation group mismatch; missing {sorted(required_groups-got)}, extra {sorted(got-required_groups)}')
        frame_count=0
        for seq in anim['sequences']:
            for name in seq['frames']:
                p=anim_path.parent/name; frame_count+=1
                if not p.exists(): errors.append(f'{cid}: missing frame {name}'); continue
                im=Image.open(p)
                if im.mode!='RGBA': errors.append(f'{cid}: frame not RGBA {name}')
                if im.size!=(180,140): errors.append(f'{cid}: unexpected frame size {name}: {im.size}')
                if not im.getbbox(): errors.append(f'{cid}: fully transparent frame {name}')
        checks.append(f'{cid}: {len(got)} groups, {frame_count} battle frames')
        for rel in [f'Content/data/nereid/{slug}/icon_large.png',f'Content/data/nereid/{slug}/icon_small.png',f'Content/data/nereid/{slug}/map_attack_left.png',f'Content/data/nereid/{slug}/map_attack_right.png']:
            if not (MOD/rel).exists(): errors.append(f'Missing resource {rel}')
        for snd in ['attack','defend','killed','startMoving','endMoving','move','wince','cast','sirenSong','summonBoat']:
            p=SOUNDS/slug/f'{snd}.wav'
            try:
                with wave.open(str(p),'rb') as wf:
                    if (wf.getnchannels(),wf.getsampwidth(),wf.getframerate())!=(1,2,44100): errors.append(f'Bad WAV format: {p.relative_to(MOD)}')
            except Exception as e: errors.append(f'WAV failure {p.relative_to(MOD)}: {e}')
    base=creatures['nereid']; up=creatures['nereidSiren']
    if base.get('upgrades')!=[f'{MOD_ID}:nereidSiren']: errors.append('Upgrade link is incorrect')
    if base['abilities'].get('tidalFortuneCore',{}).get('val')!=1 or up['abilities'].get('tidalFortuneCore',{}).get('val')!=1: errors.append('Shared Luck layer is incorrect')
    if base['abilities']['tidalFortuneCore']['stacking']!=up['abilities']['tidalFortuneCore']['stacking']: errors.append('Shared Luck stacking keys differ')
    if up['abilities'].get('tidalFortuneGreater',{}).get('val')!=1: errors.append('Upgrade-only Luck layer is incorrect')
    if up['abilities']['tidalFortuneGreater'].get('stacking')=='NereidTidalFortuneCore': errors.append('Upgrade Luck layer must use a separate stacking key')
    for cid in creatures:
        b=creatures[cid]['abilities']['summonBoatGift']
        if b.get('type')!='SPELL' or b.get('subtype')!='core:summonBoat' or b.get('propagator')!='HERO': errors.append(f'{cid}: Summon Boat propagation is incorrect')
    ua=up['abilities']
    if ua.get('sacrificeCaster',{}).get('subtype')!='core:sacrifice' or ua.get('sacrificeCharge',{}).get('val')!=1: errors.append('Sacrifice configuration is incorrect')
    checks.append('Verified upgrade link, deterministic non-stacking +1/+2 Luck layers, HERO-propagated Summon Boat and one Sacrifice charge')
    checks.append('Verified all 20 WAV files are mono PCM 16-bit 44.1 kHz')
    report=['NEREID TIDEBORN STATIC QA REPORT','================================',*['PASS: '+c for c in checks]]
    if errors:
        report.extend(['','FAILURES:',*['- '+e for e in errors]])
    else:
        report.extend(['','RESULT: PASSED static validation','NOTE: A live VCMI runtime test still requires a local Heroes III data installation and VCMI 1.8.0+.'])
    (MOD/'QA_REPORT.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    if errors: raise RuntimeError('\n'.join(errors))
    return checks


def write_manifest_and_zip()->str:
    # Manifest excludes itself to avoid a recursive hash.
    lines=[]
    for p in sorted(MOD.rglob('*')):
        if p.is_file() and p.name!='MANIFEST_SHA256.txt':
            lines.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(MOD).as_posix()}')
    (MOD/'MANIFEST_SHA256.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    with zipfile.ZipFile(ZIP_PATH,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(MOD.rglob('*')):
            if p.is_file(): z.write(p,Path(MOD.name)/p.relative_to(MOD))
    with zipfile.ZipFile(ZIP_PATH,'r') as z:
        bad=z.testzip()
        if bad: raise RuntimeError(f'ZIP integrity failure: {bad}')
        names=z.namelist()
        if not names or any(not n.startswith('nereid-tideborn/') for n in names): raise RuntimeError('Incorrect ZIP top-level folder')
    sha=hashlib.sha256(ZIP_PATH.read_bytes()).hexdigest(); SHA_PATH.write_text(f'{sha}  {ZIP_PATH.name}\n',encoding='utf-8')
    return sha


def main()->None:
    ensure_dirs(); sources=extract_sources(); group_paths={}
    for cid,f in FORMS.items():
        _,groups=build_battle_animation(f,sources[f['form']]); group_paths[cid]=groups
        build_map_animation(f,sources[f['form']]); build_icons(f,sources[f['form']]); build_sounds(f)
    build_ability_icons(); build_tide_effect(); build_configs(); build_docs(); build_preview(group_paths)
    shutil.copy2(Path(__file__),TOOLS/'build_nereid_mod.py')
    validate(group_paths); sha=write_manifest_and_zip()
    print(f'Built: {ZIP_PATH}')
    print(f'SHA256: {sha}')
    print(f'Files: {sum(1 for p in MOD.rglob("*") if p.is_file())}')
    print(f'ZIP size: {ZIP_PATH.stat().st_size/1024/1024:.2f} MiB')


if __name__=='__main__':
    main()
