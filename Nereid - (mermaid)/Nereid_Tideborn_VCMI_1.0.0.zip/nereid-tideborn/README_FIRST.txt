NEREID TIDEBORN — VCMI CREATURE MOD 1.0.0
==========================================

WHAT THIS MOD ADDS
------------------
* Nereid — neutral Tier 5 base creature.
* Nereid Siren — upgraded neutral Tier 5 creature.
* Both are walking/surface-sliding units. They do NOT have the Flying ability.
* Nereid gives the allied army +1 Luck.
* Nereid Siren gives the allied army +2 Luck.
* The base +1 layer and the upgrade-only +1 layer are each independently non-stacking. Any mix of the two forms therefore gives +1 or +2, never +3 or more.
* Either form gives its current hero Summon Boat at Basic mastery while at least one creature remains in the hero army.
* Summon Boat requires that hero to own a spellbook; this is enforced by VCMI's normal spell-casting rules.
* Each Nereid Siren stack can cast Sacrifice once per battle as an alternative action.

REQUIRED VCMI VERSION
---------------------
VCMI 1.8.0 development build or newer is required for the corrected two-target creature casting used by Sacrifice.
VCMI 1.7.x can load ordinary custom creatures, but Sacrifice/Teleport used as creature SPELLCASTER actions were affected by a crash that was fixed for 1.8 development.

EXACT WINDOWS INSTALLATION
--------------------------
1. Close VCMI Launcher, VCMI Map Editor and the game.
2. Open Nereid_Tideborn_VCMI_1.0.0.zip.
3. Extract the single folder named:

       nereid-tideborn

   into:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\

4. Confirm this exact file exists:

       %USERPROFILE%\Documents\My Games\vcmi\Mods\nereid-tideborn\mod.json

5. Do not leave an accidental double folder such as:

       ...\nereid-tideborn\nereid-tideborn\mod.json

6. Start VCMI Launcher.
7. Open Mods.
8. Enable "Nereid Tideborn".
9. Start VCMI Map Editor and make a small test map.

FIRST TEST MAP
--------------
1. Use a map with water so Summon Boat is relevant.
2. Place a hero and make sure the hero owns a spellbook.
3. Give the hero at least one Nereid or Nereid Siren.
4. On the adventure map, open the hero spellbook. Summon Boat should be available while the creature is carried.
5. Move every Nereid/Nereid Siren out of the hero army, then reopen the spellbook. The temporary grant should be gone.
6. Start a battle and inspect allied stacks: the base form supplies +1 Luck and the upgraded form supplies +2 Luck.
7. Give the hero both forms at once: the expected result is +2, not +3.
8. During a Nereid Siren stack's turn, use the alternative action / creature spellbook control and select Sacrifice.
9. The stack has one Sacrifice charge for that battle. A second cast by the same stack should not be available.

IMPORTANT SACRIFICE NOTES
-------------------------
* Sacrifice is the original Heroes III spell and follows its ordinary target restrictions.
* It requires a valid dead friendly living stack to restore and a valid friendly living stack to sacrifice.
* Each separate Nereid Siren stack receives one charge. Splitting the army into several stacks therefore creates several casters, just as it does for other creature spellcasters.
* The configured creature spell power is 0.5 Spell Power per surviving Siren in the casting stack.

EDITING
-------
Statistics and abilities:
    Content\config\nereid\creatures.json

Battle frames:
    Content\sprites\nereid\nereid\battle\
    Content\sprites\nereid\nereid_siren\battle\

Icons and map-attack images:
    Content\data\nereid\

Sounds:
    Content\sounds\nereid\

Rebuild source:
    tools\build_nereid_mod.py

The generated artwork and procedural sounds in this package were created specifically for this mod. No WoG, HotA, Warcraft or third-party Discord art/audio is redistributed.
