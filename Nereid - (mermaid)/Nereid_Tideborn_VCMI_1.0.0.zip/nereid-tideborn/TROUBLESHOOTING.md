# Troubleshooting

## The launcher says the mod is incompatible
Install a current VCMI 1.8 development build or a later release. The manifest intentionally requires 1.8.0.

## The mod is not listed
Confirm that `mod.json` is directly inside `Documents\\My Games\\vcmi\\Mods\\nereid-tideborn` and not one folder deeper.

## Summon Boat is not shown
Check all of the following:

1. The army is led by a hero, not stored only in a town garrison.
2. The hero owns a spellbook.
3. At least one Nereid or Nereid Siren remains in that hero's army.
4. Test on a map containing water; the original Summon Boat spell is marked as water-map-only.
5. Close and reopen the spellbook after changing the army.

## I cannot find Sacrifice on the Siren's turn
Use VCMI's alternative-action / creature-spellbook button. The unit is configured with `NO_SPELLCAST_BY_DEFAULT`, so ordinary movement and melee remain the default cursor mode.

## Sacrifice has no valid target
The spell needs both a legal dead friendly living stack and a legal friendly living stack to destroy. Undead, mechanical, siege-weapon and gargoyle targets are excluded by the original spell.

## Collect logs
After reproducing the problem, inspect:

* `%USERPROFILE%\\Documents\\My Games\\vcmi\\VCMI_Client_log.txt`
* `%USERPROFILE%\\Documents\\My Games\\vcmi\\VCMI_Server_log.txt`

Search for `nereid-tideborn`, `nereidSiren`, `summonBoat`, `sacrifice`, `animation`, or `resource`.
