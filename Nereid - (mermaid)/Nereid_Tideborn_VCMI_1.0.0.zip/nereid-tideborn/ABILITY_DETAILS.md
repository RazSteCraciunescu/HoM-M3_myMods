# Ability implementation

## Tidal Fortune

Both creatures carry a normal `LUCK +1` bonus with the `ARMY` propagator and stacking key `NereidTidalFortuneCore`. The upgrade also carries a second `LUCK +1` layer using `NereidTidalFortuneGreater`. Each layer is independently non-stacking, so base-only armies receive +1, any army with an upgrade receives +2, and splitting or mixing stacks cannot raise this family bonus above +2.

## Conditional Summon Boat

Each creature carries a `SPELL` bonus for `core:summonBoat` with the `HERO` propagator. VCMI copies that bonus to the hero only while the creature belongs to a hero-led army. Removing the final Nereid removes the propagated bonus. VCMI's standard spell validation still requires a spellbook.

The grant uses Basic mastery. A hero's better Water Magic mastery can still improve the spell through normal VCMI spell-mastery resolution.

## Sacrifice

Nereid Sirens have:

```json
"type": "SPELLCASTER",
"subtype": "core:sacrifice",
"val": 1
```

They also have `CASTS: 1`, `CREATURE_SPELL_POWER: 50`, and `NO_SPELLCAST_BY_DEFAULT`. This makes melee/movement the default action while keeping Sacrifice in the creature's alternative-action spellbook.

VCMI 1.8.0+ is required because Sacrifice needs two selected targets when cast by a creature.
