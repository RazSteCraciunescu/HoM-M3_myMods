# Undine & Nereid Siren 1.2.0

## Names

- Base form: Undine (internal ID remains `nereid` for map compatibility).
- Upgrade: Nereid Siren.

## Call of the Tides

- Undine grants Basic Summon Boat.
- Nereid Siren grants Expert Summon Boat.
- The actual hero spell bonus is hidden, so Call of the Tides is no longer listed under Hydras, Lizardmen, or other unrelated allied creatures.

## Sacrifice controls

Sacrifice only resurrects a **fully dead** friendly living stack. During the Siren's turn, activate its spell action, click the **living donor stack first**, then click the **dead stack/corpse second**. A partially damaged stack is not a valid resurrection target under the original spell rules.

## Dwellings

- Grotto of the Undines recruits Undines.
- Palace of the Nereids recruits Nereid Sirens directly.
