# Town-ready dwelling art

These images are deliberately not connected to a faction yet. They can be placed on a future town screen and referenced by that faction's building configuration. The external map dwellings are already active through `Content/config/nereid/dwellings.json`.
