# Undine & Nereid Siren 1.4.0

Delete the previous `nereid-tideborn` folder before installing. This release fixes battle positioning, turning, movement, attacks, casts, deaths and UI portrait backgrounds. Sacrifice mechanics are unchanged.
