@echo off
setlocal
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0tools\validate_visual_resources.py"
) else (
  python "%~dp0tools\validate_visual_resources.py"
)
pause
