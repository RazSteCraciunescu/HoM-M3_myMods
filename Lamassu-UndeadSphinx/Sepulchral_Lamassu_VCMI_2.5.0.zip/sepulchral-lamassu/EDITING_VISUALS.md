# Editing visuals and dwellings — version 2.3.0

## Creature files

- `sepulchralLamassu` battle: `Content\sprites\sepulchral\sepulchral_lamassu\battle\`
- `sepulchralLamassu` map: `Content\sprites\sepulchral\sepulchral_lamassu\map\`
- `abyssalLamassu` battle: `Content\sprites\sepulchral\abyssal_lamassu\battle\`
- `abyssalLamassu` map: `Content\sprites\sepulchral\abyssal_lamassu\map\`

Every battle frame is **128x112 RGBA**. Keep the visible creature close to the **bottom-right** of the transparent canvas; the right and bottom margins are the anchor used to align the model to its occupied battle hex.

Every adventure-map frame is **64x64 RGBA** and bottom-centered. The map manifest repeats frames to slow the idle loop; edit the frame list in each `map\animation.json` to change map animation speed.

Large creature icons are 58x64. Small army/exchange icons are 32x32. Map-attack images are 64x64.

## Animation timing

Edit `Content\config\sepulchral\creatures.json`:

- `graphics.animationTime.idle` controls the length of the idle/preview sequence.
- `graphics.animationTime.walk` controls movement playback.
- `graphics.animationTime.attack` affects shooting/casting timing where supported.
- `graphics.timeBetweenFidgets` controls how often the hover/fidget sequence is played.

Do not restore `basepath` inside animation manifests. Each frame is intentionally referenced through a complete VCMI resource path.

## Ability artwork

Replace `Content\data\sepulchral\shared\funerary_reprise_32.png`. Ability artwork must stay on a 32x32 transparent canvas, with the visible symbol filling roughly 27–29 pixels so it is neither clipped nor tiny.

Funerary Reprisal VFX: `Content\sprites\sepulchral\effects\funerary_reprise\`. Effect frames are **128x128 RGBA**.

## External dwellings

The two active map dwellings are under:

`Content\sprites\sepulchral\dwellings\`

Each dwelling uses eight 112x112 RGBA frames. Names, recruited creatures, masks and animation references are configured in:

`Content\config\sepulchral\dwellings.json`

Town-ready facade art that is not yet attached to a faction is under:

`future-town\dwellings\`

Each folder contains a 240x180 town facade and a 58x64 building icon.

## Validate

Double-click `VALIDATE_VISUALS.cmd`, or run:

```text
py -3 tools\validate_visual_resources.py
```
