Run validate_visual_resources.py after editing icons, battle frames, map frames, or animation JSON files.
The legacy 2.1 builder was disabled because it contained build-machine absolute paths and generated ambiguous basepaths.
