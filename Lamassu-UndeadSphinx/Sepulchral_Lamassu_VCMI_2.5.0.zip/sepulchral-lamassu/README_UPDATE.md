# Sepulchral Lamassu 2.5.0

Delete the previous `sepulchral-lamassu` folder before installing. This release changes only visual assets, animation timing and UI portrait backgrounds. Petrification/Stone Gaze freezes the creature in its current facing direction; that is normal VCMI battle-state behaviour, not an animation-resource error.
