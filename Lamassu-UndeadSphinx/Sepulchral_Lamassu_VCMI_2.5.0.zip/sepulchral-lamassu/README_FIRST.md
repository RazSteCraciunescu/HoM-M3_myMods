# Sepulchral Lamassu 2.2.0 — Visual Resource Fix

This release keeps the working creatures, sounds and Funerary Reprisal mechanic from 2.1.0 and replaces the broken visual resource wiring.

## Replace the old version

1. Close VCMI, VCMI Launcher and VCMI Map Editor.
2. Delete the old folder:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\sepulchral-lamassu`

3. Extract the new `sepulchral-lamassu` folder into:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\`

4. Confirm this file exists:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\sepulchral-lamassu\mod.json`

5. Open VCMI Launcher and enable **Sepulchral Lamassu**.
6. Fully close and reopen Map Editor before checking old maps.

Do not merge 2.2.0 over an incomplete or double-nested old folder. Delete the old folder first.

## What was repaired

- Battle animation manifests now name every PNG with its complete VCMI sprite-resource path.
- Adventure-map animation manifests now name every map PNG with its complete path.
- Clean 58x64 and 32x32 creature icons replace the concept-board crops that contained text.
- Funerary Reprisal now uses a padded 32x32 icon.
- A standard map mask was added to both creatures.
- Creature IDs, stats, sounds and Lua mechanics are unchanged.

## Editing the visuals

See `EDITING_VISUALS.md`. Run `VALIDATE_VISUALS.cmd` after changing any image or animation manifest.
