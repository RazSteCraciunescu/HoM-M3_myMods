from __future__ import annotations
import json, struct, sys, wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTENT = ROOT / "Content"
ERRORS=[]
CHECKED=0
EXPECTED_VERSION='2.3.0'
NAMESPACE='sepulchral'
BATTLE_SIZE=(128,112)
MAP_SIZE=(64,64)
EFFECT_SIZE=(128,128)
REQUIRED_GROUPS=set([0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 30, 31, 32, 40, 41, 42, 50, 51])
CREATURE_SPECS=[('sepulchral_lamassu', 'sepulchralLamassu'), ('abyssal_lamassu', 'abyssalLamassu')]
EFFECT_RESOURCE='sepulchral/effects/funerary_reprise/animation.json'

def fail(msg): ERRORS.append(msg)
def read_json(p):
    global CHECKED
    try:
        data=json.loads(p.read_text(encoding="utf-8")); CHECKED+=1; return data
    except Exception as e: fail(f"Invalid JSON {p.relative_to(ROOT)}: {e}"); return {}
def png_info(p):
    global CHECKED
    if not p.is_file(): fail(f"Missing PNG {p.relative_to(ROOT)}"); return None
    try:
        raw=p.read_bytes()
        if raw[:8] != b"\x89PNG\r\n\x1a\n" or raw[12:16] != b"IHDR": raise ValueError("invalid PNG header")
        w,h,depth,ctype=struct.unpack(">IIBB",raw[16:26]); CHECKED+=1
        if ctype not in (4,6): fail(f"PNG lacks alpha {p.relative_to(ROOT)} colour type={ctype}")
        return (w,h)
    except Exception as e: fail(f"Unreadable PNG {p.relative_to(ROOT)}: {e}"); return None
def check_png(p,size):
    got=png_info(p)
    if got and got != size: fail(f"Wrong PNG size {p.relative_to(ROOT)}={got}, expected={size}")
def check_anim(resource,size,required=None):
    p=CONTENT/'sprites'/resource
    data=read_json(p)
    if 'basepath' in data: fail(f"Ambiguous basepath in {resource}")
    groups={s.get('group') for s in data.get('sequences',[])}
    if required and not required.issubset(groups): fail(f"Missing groups in {resource}: {sorted(required-groups)}")
    for seq in data.get('sequences',[]):
        for fr in seq.get('frames',[]):
            if not isinstance(fr,str) or '/' not in fr: fail(f"Non-explicit frame in {resource}: {fr!r}")
            else: check_png(CONTENT/'sprites'/fr,size)

mod=read_json(ROOT/'mod.json')
if mod.get('version') != EXPECTED_VERSION: fail(f"mod.json version {mod.get('version')} != {EXPECTED_VERSION}")
creatures=read_json(CONTENT/'config'/NAMESPACE/'creatures.json')
for slug,key in CREATURE_SPECS:
    c=creatures.get(key,{}); g=c.get('graphics',{})
    check_anim(g.get('animation',''),BATTLE_SIZE,REQUIRED_GROUPS)
    check_anim(g.get('map',''),MAP_SIZE,{0})
    check_png(CONTENT/'data'/g.get('iconLarge',''),(58,64))
    check_png(CONTENT/'data'/g.get('iconSmall',''),(32,32))
    check_png(CONTENT/'data'/g.get('mapAttackFromLeft',''),MAP_SIZE)
    check_png(CONTENT/'data'/g.get('mapAttackFromRight',''),MAP_SIZE)
    for ability in c.get('abilities',{}).values():
        icon=ability.get('icon') if isinstance(ability,dict) else None
        if icon: check_png(CONTENT/'data'/icon,(32,32))
    for snd in c.get('sound',{}).values():
        p=CONTENT/'sounds'/snd
        if not p.is_file(): fail(f"Missing sound {p.relative_to(ROOT)}")
        else:
            try:
                with wave.open(str(p),'rb') as w: w.getparams()
                CHECKED+=1
            except Exception as e: fail(f"Invalid WAV {p.relative_to(ROOT)}: {e}")
check_anim(EFFECT_RESOURCE,EFFECT_SIZE,{0})
dwellings=read_json(CONTENT/'config'/NAMESPACE/'dwellings.json').get('core:creatureGeneratorCommon',{}).get('types',{})
if len(dwellings)!=2: fail(f"Expected 2 dwellings, got {len(dwellings)}")
for oid,obj in dwellings.items():
    anim=obj.get('templates',{}).get('default',{}).get('animation','')
    check_anim(anim,(112,112),{0})
    ov=obj.get('kingdomOverviewImage','')
    check_anim(ov,(64,64),{0})

if ERRORS:
    print('VISUAL VALIDATION FAILED')
    for e in ERRORS: print(' -',e)
    sys.exit(1)
print(f'VISUAL VALIDATION PASSED ({CHECKED} resources checked)')
