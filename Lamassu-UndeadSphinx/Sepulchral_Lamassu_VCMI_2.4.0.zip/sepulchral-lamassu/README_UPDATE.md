# Sepulchral Lamassu 2.3.0

## Visual corrections

- Battle and recruitment-preview art is now rendered on a compact 128x112 canvas, bottom-right anchored to the occupied double-wide hexes.
- Adventure-map sprites are 64x64 with a creature height of about 40 pixels and a four-times slower idle loop.
- Creature-info/recruitment idle timing is 10 seconds per sequence, with fidgets spaced farther apart.
- Funerary Reprisal uses a 32x32 icon whose visible artwork fills the slot without clipping.

## Death Ripple and elementals/mechanicals

This is not changed. The original Death Ripple damages all non-undead units, including many non-living and elemental units unless a unit has specific spell immunity.

## Dwellings

- Tomb of the Lamassu recruits Sepulchral Lamassu directly.
- Abyssal Sepulcher recruits Abyssal Lamassu directly.

Both appear under creature dwellings in VCMI Map Editor. Town-ready facade art is under `future-town/dwellings`.
