# Sepulchral Lamassu - VCMI Creature Mod 1.0.0

This ready-to-install package adds two neutral Tier 7 creatures:

- Sepulchral Lamassu
- Abyssal Lamassu, its upgrade

Both are double-wide undead ground creatures. Their ceremonial wings are broken, stone-heavy and non-functional; neither form flies.

## Installation

1. Close VCMI, VCMI Launcher and VCMI Map Editor.
2. Extract the folder `sepulchral-lamassu` from the ZIP into:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\`

3. Confirm this exact file exists:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\sepulchral-lamassu\mod.json`

4. Do not leave a double folder such as:

   `...\Mods\sepulchral-lamassu\sepulchral-lamassu\mod.json`

5. Start VCMI Launcher and enable **Sepulchral Lamassu**.

## Required engine

Use a current VCMI 1.8 development/daily build or newer. The ability is implemented with the developing combat-event Lua API (`COMBAT_EVENT_TRIGGER`, `onAfterAttacked`, round-start events and `BattleServer:castSpell`).

## Funerary Reprisal

- The creatures never perform a normal retaliation.
- Once per round **per army**, the first Sepulchral or Abyssal Lamassu stack that survives an enemy active melee hit casts Death Ripple.
- The cooldown is shared by all base and upgraded Lamassu stacks on that side. Splitting them into seven stacks does not create seven waves.
- Ranged attacks and spell damage do not trigger it.
- A counterattack received after the Lamassu initiates an attack does not trigger it.
- A lethal hit does not trigger it because a dead defender could not retaliate.
- The core Death Ripple spell filters targets and supplies the normal spell presentation.
- All living stacks on both sides are selected. Friendly living creatures can therefore be harmed.
- Undead and other units VCMI classifies as non-living are not selected.

### Damage

Sepulchral Lamassu:

`20 + 5 x surviving creatures in the reacting stack`, maximum 90 damage to each eligible stack.

Abyssal Lamassu:

`30 + 6 x surviving creatures in the reacting stack`, maximum 120 damage to each eligible stack.

This makes the wave dangerous to armies spread across many low-health living stacks, while a compact army of a few elite stacks absorbs far less total damage.

## First test

Create a small VCMI map with two heroes.

1. Give hero A one Sepulchral Lamassu.
2. Give hero B several living stacks, including one melee stack and one shooter.
3. Make the melee stack attack the Lamassu. Expected: Death Ripple plays after the hit; the Lamassu does not retaliate normally.
4. Hit it in melee again during the same round. Expected: no second wave.
5. Start the next round and hit it again. Expected: the wave is available again.
6. Shoot it. Expected: no wave.
7. Cast a damage spell on it. Expected: no wave.
8. Let the Lamassu attack and receive enemy retaliation. Expected: no wave.
9. Add a second split Lamassu stack. Expected: only the first qualifying Lamassu hit on that side triggers during the round.
10. Add friendly living creatures beside the Lamassu. Expected: they are also affected by Death Ripple.

## Editable files

- Creature stats: `Content/config/sepulchral/creatures.json`
- Script registration and tooltip: `Content/config/sepulchral/scripts.json`
- Complete mechanic: `Content/scripts/sepulchral/funeraryReprisal.lua`
- Complete asset/build source: `tools/build_sepulchral_lamassu_mod.py`

## Art and audio

All packaged sprites, icons, effects and WAV files were created for this package. The supplied web references and the Heroes VII creature were used only as broad thematic references for an undead sphinx/lamassu concept. No Pinterest, Heroes VII, WoG, HotA or third-party creature asset is redistributed.

The VCMI live runtime was not available in the build environment. The package therefore passed static validation but still needs its first real client/server launch on your laptop. If VCMI rejects a development-build API field, inspect `VCMI_Client_log.txt` and `VCMI_Server_log.txt` in the VCMI user-data folder.
