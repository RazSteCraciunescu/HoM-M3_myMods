local Base = require("combat/combatScript")

local Script = setmetatable({}, {__index = Base})
Script.__index = Script

local COOLDOWN_STACKING = "sepulchral-lamassu:funeraryReprisalUsed"
local COOLDOWN_SOURCE = "sepulchral-lamassu:funeraryReprisal"

function Script:cooldownBonuses(unit)
    return unit:getBonuses(function(bonus)
        return bonus:getStacking() == COOLDOWN_STACKING
    end)
end

function Script:isSpent(unit)
    return self:cooldownBonuses(unit):size() > 0
end

function Script:clearCooldown(server, battle, unit)
    local bonuses = self:cooldownBonuses(unit)
    if bonuses:size() > 0 then
        server:removeUnitBonuses(battle, unit, bonuses)
    end
end

function Script:isFamilyUnit(unit)
    if not unit then return false end
    local key = unit:getCreature():getJsonKey()
    for _, familyKey in ipairs(self.family or {}) do
        if key == familyKey then return true end
    end
    return false
end

function Script:markArmyFamilySpent(server, battle, unit)
    local side = unit:unitSide()
    local familyUnits = battle:getUnitsIf(function(candidate)
        return candidate:isAlive() and candidate:unitSide() == side and self:isFamilyUnit(candidate)
    end)

    for _, candidate in ipairs(familyUnits) do
        server:addUnitBonus(battle, candidate, {
            type = "NONE",
            val = 0,
            duration = ENUM.BonusDuration.oneBattle,
            sourceType = ENUM.BonusSource.other,
            sourceID = COOLDOWN_SOURCE,
            stacking = COOLDOWN_STACKING,
            hidden = true
        }, false)
    end
end

function Script:onBattleStart(server, battle, unit)
    -- Defensive cleanup for battle recreation / save loading. The first round begins ready.
    self:clearCooldown(server, battle, unit)
end

function Script:onRoundStart(server, battle, unit)
    -- Every living Lamassu receives this event, so all family markers are cleared for the new round.
    self:clearCooldown(server, battle, unit)
end

function Script:onAfterAttacked(server, battle, unit, other, payload)
    -- Like an ordinary retaliation, the reprisal is lost if the defender was killed by the blow.
    if not unit:isAlive() then return end
    if not other then return end

    -- Only direct melee attacks trigger it. Shots and spell damage never do.
    if payload and payload.ranged then return end

    -- Do not let the Lamassu deliberately trigger the wave by attacking and receiving retaliation.
    if self.activeAttacksOnly ~= false and payload and payload.isCounter then return end

    -- Shared cooldown prevents seven split Lamassu stacks from producing seven waves per round.
    if self:isSpent(unit) then return end

    local spell = LIBRARY:getSpellByName(self.spell or "core:deathRipple")
    if not spell then return end

    local targets = battle:getUnitsIf(function(candidate)
        return candidate:isAlive() and candidate:isLiving()
    end)

    if #targets == 0 then return end

    local damage = (self.val or 0) + unit:getCount() * (self.perCreature or 0)
    damage = math.max(1, math.min(damage, self.maxDamage or damage))

    self:markArmyFamilySpent(server, battle, unit)

    -- castSpell preserves the core Death Ripple animation, sound, immunities and damage pipeline.
    -- Combat-event scripts cannot re-enter themselves, so this cast does not recursively trigger the ability.
    server:castSpell(battle, unit, spell, targets, damage)
end

return Script
