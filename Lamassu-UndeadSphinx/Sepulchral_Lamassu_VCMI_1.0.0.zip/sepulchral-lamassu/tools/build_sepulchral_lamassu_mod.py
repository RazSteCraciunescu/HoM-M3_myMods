from __future__ import annotations

import hashlib
import json
import math
import random
import shutil
import textwrap
import wave
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps
from scipy import signal

VERSION = "1.0.0"
MOD_ID = "sepulchral-lamassu"
RESOURCE_NS = "sepulchral"
WORK = Path("/mnt/data/lamassu_work")
PACKAGE_ROOT = WORK / f"Sepulchral_Lamassu_VCMI_{VERSION}"
MOD = PACKAGE_ROOT / MOD_ID
CONTENT = MOD / "Content"
CONFIG = CONTENT / "config" / RESOURCE_NS
SCRIPTS = CONTENT / "scripts" / RESOURCE_NS
SPRITES = CONTENT / "sprites" / RESOURCE_NS
DATA = CONTENT / "data" / RESOURCE_NS
SOUNDS = CONTENT / "sounds" / RESOURCE_NS
PREVIEW = MOD / "preview"
SOURCE = MOD / "source"
TOOLS = MOD / "tools"
ZIP_PATH = Path(f"/mnt/data/Sepulchral_Lamassu_VCMI_{VERSION}.zip")
SHA_PATH = Path(f"/mnt/data/Sepulchral_Lamassu_VCMI_{VERSION}_SHA256.txt")
ASSETS_PREVIEW_PATH = Path("/mnt/data/Sepulchral_Lamassu_actual_assets.png")
SHOWCASE_PATH = Path("/mnt/data/Sepulchral_Lamassu_preview.png")
QA_PATH = Path("/mnt/data/Sepulchral_Lamassu_QA_REPORT.txt")
CONCEPT_POSTER = Path("/mnt/data/a_detailed_infographic_game_mod_promotional_sheet.png")

FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_SERIF = "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"
FONT_SERIF_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"

FORMS = {
    "sepulchralLamassu": {
        "slug": "sepulchral_lamassu",
        "name": "Sepulchral Lamassu",
        "plural": "Sepulchral Lamassu",
        "form": "base",
        "accent": (134, 76, 184),
        "eye": (188, 112, 255),
        "stats": {
            "level": 7,
            "attack": 19,
            "defense": 23,
            "damage": {"min": 32, "max": 46},
            "hitPoints": 220,
            "speed": 6,
            "growth": 1,
            "cost": {"gold": 4600, "sulfur": 1},
            "fightValue": 5200,
            "aiValue": 6100,
            "advMapAmount": {"min": 1, "max": 3},
        },
        "ripple": {"base": 20, "perCreature": 5, "maxDamage": 90},
        "description": (
            "Sepulchral Lamassu are colossal funerary guardians whose stone flesh still remembers the commands "
            "of dead kings. Their ruined wings cannot carry their weight. When an enemy closes into melee, the "
            "guardian answers with a wave of Death Ripple instead of a normal retaliation."
        ),
        "upgrade": f"{MOD_ID}:abyssalLamassu",
    },
    "abyssalLamassu": {
        "slug": "abyssal_lamassu",
        "name": "Abyssal Lamassu",
        "plural": "Abyssal Lamassu",
        "form": "upgrade",
        "accent": (191, 56, 111),
        "eye": (255, 78, 126),
        "stats": {
            "level": 7,
            "attack": 22,
            "defense": 26,
            "damage": {"min": 40, "max": 58},
            "hitPoints": 275,
            "speed": 7,
            "growth": 1,
            "cost": {"gold": 6200, "sulfur": 2},
            "fightValue": 7000,
            "aiValue": 8300,
            "advMapAmount": {"min": 1, "max": 2},
        },
        "ripple": {"base": 30, "perCreature": 6, "maxDamage": 120},
        "description": (
            "Abyssal Lamassu have awakened the curse sealed inside their burial armor. Cracks of violet-red "
            "necromantic fire cross their bodies, and the Death Ripple released by a melee blow is stronger. "
            "They remain slow, double-wide ground creatures and never retaliate normally."
        ),
        "upgrade": None,
    },
}

REQUIRED_GROUPS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 30, 31, 32, 40, 41, 42, 50, 51]


def font(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def save_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def ensure_dirs() -> None:
    if PACKAGE_ROOT.exists():
        shutil.rmtree(PACKAGE_ROOT)
    for directory in [CONFIG, SCRIPTS, SPRITES, DATA, SOUNDS, PREVIEW, SOURCE, TOOLS]:
        directory.mkdir(parents=True, exist_ok=True)
    for path in [ZIP_PATH, SHA_PATH, ASSETS_PREVIEW_PATH, SHOWCASE_PATH, QA_PATH]:
        if path.exists():
            path.unlink()


def scale_points(points: Sequence[Tuple[float, float]], s: int) -> List[Tuple[int, int]]:
    return [(int(x * s), int(y * s)) for x, y in points]


def ellipse(draw: ImageDraw.ImageDraw, box: Tuple[float, float, float, float], fill, outline=None, width: int = 1, s: int = 1) -> None:
    draw.ellipse(tuple(int(v * s) for v in box), fill=fill, outline=outline, width=max(1, int(width * s)))


def polygon(draw: ImageDraw.ImageDraw, points: Sequence[Tuple[float, float]], fill, outline=None, s: int = 1) -> None:
    draw.polygon(scale_points(points, s), fill=fill, outline=outline)


def line(draw: ImageDraw.ImageDraw, points: Sequence[Tuple[float, float]], fill, width: float, s: int = 1, joint: str = "curve") -> None:
    draw.line(scale_points(points, s), fill=fill, width=max(1, int(width * s)), joint=joint)


def bezier_points(p0, p1, p2, p3, n=24):
    out = []
    for i in range(n):
        t = i / max(1, n - 1)
        u = 1 - t
        x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
        y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
        out.append((x, y))
    return out


def add_outline(image: Image.Image, radius: int = 1) -> Image.Image:
    image = image.convert("RGBA")
    alpha = image.getchannel("A")
    dilated = alpha.filter(ImageFilter.MaxFilter(radius * 2 + 1))
    ring = ImageChops.subtract(dilated, alpha)
    outline = Image.new("RGBA", image.size, (7, 6, 10, 0))
    outline.putalpha(ring.point(lambda value: int(value * 0.95)))
    result = Image.new("RGBA", image.size, (0, 0, 0, 0))
    result.alpha_composite(outline)
    result.alpha_composite(image)
    return result


def quantize_rgba(image: Image.Image, colors: int = 112) -> Image.Image:
    image = image.convert("RGBA")
    alpha = image.getchannel("A")
    rgb = image.convert("RGB").quantize(colors=colors, method=Image.Quantize.MEDIANCUT).convert("RGB")
    rgb = rgb.filter(ImageFilter.UnsharpMask(radius=0.55, percent=110, threshold=2))
    return Image.merge("RGBA", (*rgb.split(), alpha))


def draw_wing(draw: ImageDraw.ImageDraw, shoulder: Tuple[float, float], spread: float, form: str, front: bool, s: int) -> None:
    sx, sy = shoulder
    if front:
        direction = 1
        base_shift = 8
    else:
        direction = -1
        base_shift = 0
    span = 45 + spread * 25
    rise = 25 + spread * 28
    root = (sx + base_shift, sy)
    tip = (sx + direction * span, sy - rise)
    low = (sx + direction * (span * 0.80), sy + 12 - spread * 4)
    fill = (32, 28, 42, 245) if form == "base" else (48, 22, 36, 248)
    edge = (90, 48, 126, 255) if form == "base" else (156, 35, 82, 255)
    inner = (59, 42, 76, 255) if form == "base" else (92, 28, 64, 255)
    polygon(draw, [root, (sx + direction * span * 0.28, sy - rise * 0.72), tip, low, (sx + direction * 10, sy + 13)], fill, edge, s=s)
    # Layered funeral feathers.
    for index in range(8):
        t = index / 7
        px = sx + direction * (12 + t * span * 0.78)
        top_y = sy - (rise * (0.22 + 0.67 * t))
        length = 16 + 18 * t + spread * 7
        side = direction * (4 + 2 * t)
        feather = [
            (px, top_y),
            (px + side, top_y + length * 0.38),
            (px + direction * (3 + t * 5), top_y + length),
            (px - direction * 3, top_y + length * 0.52),
        ]
        polygon(draw, feather, inner if index % 2 else fill, edge, s=s)
        line(draw, [(px, top_y + 2), (px + direction * (2 + t * 3), top_y + length * 0.82)], edge, 0.7, s=s)


def draw_leg(draw: ImageDraw.ImageDraw, hip: Tuple[float, float], phase: float, front: bool, form: str, s: int, armor: bool = True) -> None:
    hx, hy = hip
    swing = math.sin(phase * math.tau) * (5.5 if front else 4.5)
    knee = (hx + swing * 0.45, hy + 15)
    ankle = (hx + swing, hy + 31)
    paw = (hx + swing + (4 if front else -1), hy + 35)
    limb = (42, 40, 47, 255) if form == "base" else (50, 31, 39, 255)
    shadow = (19, 18, 23, 255)
    gold = (143, 109, 47, 255) if form == "base" else (145, 74, 49, 255)
    line(draw, [hip, knee, ankle], shadow, 9, s=s)
    line(draw, [hip, knee, ankle], limb, 6, s=s)
    ellipse(draw, (paw[0] - 7, paw[1] - 3, paw[0] + 8, paw[1] + 4), limb, shadow, 1, s=s)
    for claw in (-4, 0, 4):
        line(draw, [(paw[0] + claw, paw[1]), (paw[0] + claw + 3, paw[1] + 2)], (132, 123, 105, 255), 1.2, s=s)
    if armor:
        polygon(draw, [(hx - 5, hy + 8), (hx + 5, hy + 7), (hx + 5, hy + 15), (hx - 4, hy + 16)], gold, shadow, s=s)
        line(draw, [(hx - 4, hy + 11), (hx + 5, hy + 10)], (218, 177, 82, 255), 0.8, s=s)


def draw_cracks(draw: ImageDraw.ImageDraw, form: str, body_box: Tuple[float, float, float, float], s: int, seed: int) -> None:
    rng = random.Random(seed)
    glow = (116, 62, 164, 230) if form == "base" else (223, 47, 92, 245)
    x0, y0, x1, y1 = body_box
    for _ in range(7 if form == "base" else 10):
        x = rng.uniform(x0 + 7, x1 - 7)
        y = rng.uniform(y0 + 5, y1 - 5)
        pts = [(x, y)]
        for step in range(rng.randint(2, 4)):
            x += rng.uniform(-5, 7)
            y += rng.uniform(2, 6)
            pts.append((x, y))
        line(draw, pts, glow, 0.8 if form == "base" else 1.0, s=s)


def draw_magic_aura(image: Image.Image, center: Tuple[int, int], accent: Tuple[int, int, int], intensity: float, seed: int) -> None:
    if intensity <= 0:
        return
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(glow)
    cx, cy = center
    radius = int(18 + 34 * intensity)
    for ring in range(5):
        r = radius - ring * 4
        alpha = int((80 - ring * 10) * intensity)
        d.ellipse((cx - r, cy - int(r * 0.42), cx + r, cy + int(r * 0.42)), outline=(*accent, alpha), width=max(1, 4 - ring // 2))
    rng = random.Random(seed)
    for _ in range(int(18 * intensity)):
        x = rng.randint(max(0, cx - radius), min(image.width - 1, cx + radius))
        y = rng.randint(max(0, cy - radius // 2), min(image.height - 1, cy + radius // 2))
        rr = rng.choice([1, 1, 2])
        d.ellipse((x - rr, y - rr, x + rr, y + rr), fill=(*accent, rng.randint(90, 210)))
    glow = glow.filter(ImageFilter.GaussianBlur(1.6))
    image.alpha_composite(glow)


def draw_slash(image: Image.Image, direction: str, strength: float, accent: Tuple[int, int, int]) -> None:
    if strength <= 0:
        return
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    alpha = int(220 * min(1, strength))
    if direction == "up":
        boxes = [(103, 21, 177, 103), (109, 27, 181, 106), (114, 33, 185, 109)]
        starts, ends = [198, 201, 204], [300, 304, 308]
    elif direction == "down":
        boxes = [(102, 40, 177, 121), (108, 36, 181, 116), (114, 32, 185, 111)]
        starts, ends = [44, 42, 40], [144, 140, 137]
    else:
        boxes = [(102, 27, 179, 108), (108, 30, 183, 111), (114, 34, 187, 113)]
        starts, ends = [217, 220, 223], [320, 323, 326]
    for idx, box in enumerate(boxes):
        color = (235, 222, 255, max(20, alpha - idx * 48)) if idx < 2 else (*accent, max(20, alpha - 80))
        d.arc(box, starts[idx], ends[idx], fill=color, width=max(1, 4 - idx))
    layer = layer.filter(ImageFilter.GaussianBlur(0.7))
    image.alpha_composite(layer)


def draw_dust(image: Image.Image, seed: int, strength: float) -> None:
    if strength <= 0:
        return
    rng = random.Random(seed)
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for _ in range(int(14 * strength)):
        x = rng.randint(42, 132)
        y = rng.randint(112, 124)
        r = rng.randint(1, 3)
        d.ellipse((x-r, y-r//2, x+r, y+r//2+1), fill=(111, 91, 72, rng.randint(35, 105)))
    layer = layer.filter(ImageFilter.GaussianBlur(0.9))
    image.alpha_composite(layer)


def render_lamassu(form: str, action: str, phase: float, direction: str = "front", canvas_size=(180, 130), seed: int = 1) -> Image.Image:
    """Render one original transparent lamassu frame. No game or third-party sprite is reused."""
    s = 4
    w, h = canvas_size
    hi = Image.new("RGBA", (w*s, h*s), (0, 0, 0, 0))
    draw = ImageDraw.Draw(hi)
    accent = FORMS["sepulchralLamassu" if form == "base" else "abyssalLamassu"]["accent"]
    eye = FORMS["sepulchralLamassu" if form == "base" else "abyssalLamassu"]["eye"]

    # Pose controls.
    breathe = math.sin(phase * math.tau)
    body_x = 0.0
    body_y = -0.8 * breathe
    wing_spread = 0.12 + 0.05 * math.sin(phase * math.tau)
    head_tilt = 0.0
    crouch = 0.0
    lunge = 0.0
    aura = 0.0
    slash = 0.0
    leg_phase = phase

    if action == "walk":
        body_y = -1.6 * abs(math.sin(phase * math.tau))
        wing_spread = 0.18 + 0.10 * abs(math.sin(phase * math.tau))
    elif action == "fidget":
        head_tilt = 2.5 * math.sin(phase * math.tau)
        wing_spread = 0.16 + 0.28 * max(0, math.sin(phase * math.pi))
    elif action == "attack":
        lunge = math.sin(math.pi * phase)
        body_x = 10 * lunge
        body_y = -2 * lunge
        wing_spread = 0.22 + 0.48 * lunge
        head_tilt = {"up": -7, "down": 8}.get(direction, 0) * lunge
        slash = max(0, (phase - 0.36) / 0.34)
    elif action == "special":
        lunge = 0.55 * math.sin(math.pi * phase)
        body_x = 4 * lunge
        wing_spread = 0.40 + 0.55 * math.sin(math.pi * phase)
        aura = math.sin(math.pi * phase)
        head_tilt = {"up": -5, "down": 5}.get(direction, 0)
        slash = max(0, (phase - 0.42) / 0.30) * 0.75
    elif action == "cast":
        wing_spread = 0.55 + 0.45 * math.sin(math.pi * phase)
        body_y = -2.5 * math.sin(math.pi * phase)
        head_tilt = -5 * math.sin(math.pi * phase)
        aura = min(1.0, math.sin(math.pi * phase) * 1.15)
    elif action == "defend":
        crouch = 5.0 * math.sin(math.pi * phase)
        body_y = crouch
        body_x = -2 * math.sin(math.pi * phase)
        wing_spread = 0.30 + 0.28 * math.sin(math.pi * phase)
    elif action == "hit":
        recoil = math.sin(math.pi * phase)
        body_x = -8 * recoil
        body_y = -2 * recoil
        head_tilt = -9 * recoil
        wing_spread = 0.35 + 0.25 * recoil
    elif action == "teleport":
        wing_spread = 0.55
        aura = 0.8

    # Base coordinates.
    body_box = (45 + body_x, 57 + body_y, 123 + body_x, 94 + body_y)
    shoulder = (88 + body_x, 59 + body_y)

    # Rear wing, tail, rear legs.
    draw_wing(draw, shoulder, wing_spread, form, front=False, s=s)
    tail_start = (49 + body_x, 72 + body_y)
    tail_points = bezier_points(tail_start, (24 + body_x, 63 + body_y), (23 + body_x, 91 + body_y), (12 + body_x, 88 + body_y), 22)
    line(draw, tail_points, (15, 14, 19, 255), 7, s=s)
    line(draw, tail_points, (45, 39, 50, 255) if form == "base" else (63, 29, 41, 255), 4.2, s=s)
    ellipse(draw, (8 + body_x, 82 + body_y, 20 + body_x, 94 + body_y), (34, 28, 42, 255) if form == "base" else (73, 24, 41, 255), (9, 8, 12, 255), 1, s=s)

    rear_phase = leg_phase + 0.5
    draw_leg(draw, (58 + body_x, 82 + body_y), rear_phase, False, form, s, armor=False)
    draw_leg(draw, (76 + body_x, 82 + body_y), leg_phase, False, form, s, armor=True)

    # Body stone mass.
    body_fill = (35, 34, 40, 255) if form == "base" else (43, 26, 34, 255)
    body_outline = (11, 10, 14, 255)
    ellipse(draw, body_box, body_fill, body_outline, 2, s=s)
    # Ribs / muscles.
    for offset in (0, 10, 20, 30, 40):
        x = body_box[0] + 12 + offset
        line(draw, [(x, body_box[1] + 8), (x - 2, body_box[3] - 7)], (64, 57, 67, 175) if form == "base" else (78, 39, 50, 180), 0.8, s=s)
    draw_cracks(draw, form, body_box, s, seed + 110)

    # Burial saddle and armor plates.
    gold = (137, 105, 48, 255) if form == "base" else (147, 71, 47, 255)
    bright_gold = (211, 172, 78, 255) if form == "base" else (222, 105, 70, 255)
    polygon(draw, [(62+body_x, 56+body_y), (99+body_x, 54+body_y), (112+body_x, 69+body_y), (88+body_x, 75+body_y), (60+body_x, 68+body_y)], (31, 28, 37, 255), gold, s=s)
    for x in (67, 76, 85, 94, 103):
        polygon(draw, [(x+body_x, 57+body_y), (x+7+body_x, 56+body_y), (x+10+body_x, 67+body_y), (x+2+body_x, 70+body_y)], gold, (31, 24, 18, 255), s=s)
        line(draw, [(x+2+body_x, 59+body_y), (x+7+body_x, 66+body_y)], bright_gold, 0.7, s=s)

    # Front wing (closer to camera).
    draw_wing(draw, (94 + body_x, 61 + body_y), wing_spread * 0.92, form, front=True, s=s)

    # Chest and front legs.
    ellipse(draw, (103 + body_x, 58 + body_y, 137 + body_x, 96 + body_y), body_fill, body_outline, 2, s=s)
    draw_leg(draw, (111 + body_x, 83 + body_y), leg_phase + 0.5, True, form, s, armor=True)
    # Attacking front leg reaches forward.
    if action in ("attack", "special"):
        reach = 16 * math.sin(math.pi * phase)
        hip = (125 + body_x, 79 + body_y)
        knee = (131 + body_x + reach * 0.35, 89 + body_y - 3 * lunge)
        paw = (139 + body_x + reach, 104 + body_y + ({"up": -8, "down": 7}.get(direction, 0) * lunge))
        line(draw, [hip, knee, paw], (13, 12, 16, 255), 10, s=s)
        line(draw, [hip, knee, paw], body_fill, 6.5, s=s)
        ellipse(draw, (paw[0]-7, paw[1]-4, paw[0]+10, paw[1]+4), body_fill, body_outline, 1, s=s)
        for claw in (-3, 1, 5):
            line(draw, [(paw[0]+claw, paw[1]), (paw[0]+claw+5, paw[1]+2)], (180, 165, 137, 255), 1.2, s=s)
    else:
        draw_leg(draw, (126 + body_x, 82 + body_y), leg_phase, True, form, s, armor=True)

    # Chest funerary plate.
    polygon(draw, [(108+body_x, 58+body_y), (129+body_x, 54+body_y), (139+body_x, 68+body_y), (130+body_x, 85+body_y), (111+body_x, 82+body_y)], (35, 29, 41, 255) if form == "base" else (55, 25, 38, 255), gold, s=s)
    ellipse(draw, (120+body_x, 64+body_y, 129+body_x, 74+body_y), (*accent, 255), bright_gold, 1, s=s)

    # Neck and bearded skull-face.
    neck_x = 127 + body_x
    neck_y = 49 + body_y + head_tilt * 0.18
    polygon(draw, [(116+body_x, 62+body_y), (122+body_x, 42+body_y), (137+body_x, 39+body_y), (143+body_x, 65+body_y)], body_fill, body_outline, s=s)
    face_fill = (126, 113, 96, 255) if form == "base" else (112, 86, 83, 255)
    ellipse(draw, (121+body_x, 27+body_y+head_tilt, 143+body_x, 52+body_y+head_tilt), face_fill, body_outline, 1.5, s=s)
    # Cheek hollows and jaw.
    ellipse(draw, (124+body_x, 36+body_y+head_tilt, 131+body_x, 43+body_y+head_tilt), (47, 37, 40, 255), None, s=s)
    ellipse(draw, (134+body_x, 36+body_y+head_tilt, 141+body_x, 43+body_y+head_tilt), (47, 37, 40, 255), None, s=s)
    polygon(draw, [(126+body_x, 48+body_y+head_tilt), (140+body_x, 48+body_y+head_tilt), (143+body_x, 64+body_y), (132+body_x, 69+body_y), (121+body_x, 60+body_y)], (54, 48, 50, 255), body_outline, s=s)
    for yy in range(52, 64, 3):
        line(draw, [(125+body_x, yy+body_y), (140+body_x, yy+body_y)], (100, 86, 77, 220), 0.8, s=s)

    # Headdress and crown.
    polygon(draw, [(118+body_x, 31+body_y+head_tilt), (120+body_x, 15+body_y+head_tilt), (132+body_x, 8+body_y+head_tilt), (145+body_x, 18+body_y+head_tilt), (147+body_x, 35+body_y+head_tilt)], (27, 24, 34, 255), gold, s=s)
    for x in (122, 128, 134, 140):
        polygon(draw, [(x+body_x, 16+body_y+head_tilt), (x+4+body_x, 12+body_y+head_tilt), (x+5+body_x, 30+body_y+head_tilt), (x+body_x, 32+body_y+head_tilt)], gold, (40, 28, 20, 255), s=s)
    ellipse(draw, (130+body_x, 18+body_y+head_tilt, 137+body_x, 27+body_y+head_tilt), (*accent, 255), bright_gold, 1, s=s)

    # Eyes and mouth glow.
    for ex in (128, 138):
        ellipse(draw, (ex+body_x-1.6, 36+body_y+head_tilt, ex+body_x+1.6, 39+body_y+head_tilt), (*eye, 255), (245, 230, 255, 255), 0.5, s=s)
    line(draw, [(128+body_x, 47+body_y+head_tilt), (139+body_x, 47+body_y+head_tilt)], (18, 13, 16, 255), 1.1, s=s)

    # Form-specific glow cracks and upgrade crown horns.
    if form == "upgrade":
        for px, py in [(55, 72), (84, 66), (108, 75), (128, 57)]:
            ellipse(draw, (px+body_x-1.3, py+body_y-1.3, px+body_x+1.3, py+body_y+1.3), (255, 70, 116, 230), None, s=s)
        polygon(draw, [(122+body_x, 15+body_y+head_tilt), (118+body_x, 5+body_y+head_tilt), (127+body_x, 12+body_y+head_tilt)], gold, body_outline, s=s)
        polygon(draw, [(142+body_x, 16+body_y+head_tilt), (148+body_x, 5+body_y+head_tilt), (146+body_x, 21+body_y+head_tilt)], gold, body_outline, s=s)

    # Downsample, outline, and add effects.
    result = hi.resize(canvas_size, Image.Resampling.LANCZOS)
    result = add_outline(result, 1)
    draw_magic_aura(result, (102 + int(body_x), 82 + int(body_y)), accent, aura, seed)
    draw_slash(result, direction, slash, accent)
    if action == "walk":
        draw_dust(result, seed, 0.65)
    if action == "hit" and 0.28 < phase < 0.80:
        flash = Image.new("RGBA", result.size, (178, 32, 52, int(65 * math.sin(math.pi * phase))))
        flash.putalpha(ImageChops.multiply(result.getchannel("A"), flash.getchannel("A")))
        result.alpha_composite(flash)
    return quantize_rgba(result, 104 if form == "base" else 112)


@dataclass
class FrameSpec:
    action: str
    phase: float
    direction: str = "front"
    flip: bool = False
    width_scale: float = 1.0
    scale: float = 1.0
    dx: int = 0
    dy: int = 0
    opacity: float = 1.0
    angle: float = 0.0


def phases(count: int) -> List[float]:
    if count <= 1:
        return [0.0]
    return [i / (count - 1) for i in range(count)]


def idle_specs() -> List[FrameSpec]:
    return [FrameSpec("idle", i / 8) for i in range(8)]


def move_specs() -> List[FrameSpec]:
    return [FrameSpec("walk", i / 8) for i in range(8)]


def fidget_specs() -> List[FrameSpec]:
    return [FrameSpec("fidget", p) for p in phases(8)]


def hit_specs() -> List[FrameSpec]:
    return [FrameSpec("hit", p) for p in phases(5)]


def defend_specs() -> List[FrameSpec]:
    return [FrameSpec("defend", p) for p in phases(6)]


def attack_specs(direction: str, special: bool = False) -> List[FrameSpec]:
    return [FrameSpec("special" if special else "attack", p, direction=direction) for p in phases(8)]


def cast_specs(direction: str) -> List[FrameSpec]:
    return [FrameSpec("cast", p, direction=direction) for p in phases(8)]


def turn_specs(to_right: bool) -> List[FrameSpec]:
    widths = [1.0, 0.78, 0.52, 0.26, 0.52, 0.78, 1.0]
    out = []
    for i, width in enumerate(widths):
        flip = (i >= 3) if to_right else (i >= 4)
        out.append(FrameSpec("idle", (i % 4) / 4, flip=flip, width_scale=width))
    return out


def movement_edge_specs(start: bool) -> List[FrameSpec]:
    if start:
        return [FrameSpec("idle", 0.0), FrameSpec("walk", 0.12), FrameSpec("walk", 0.25)]
    return [FrameSpec("walk", 0.75), FrameSpec("walk", 0.88), FrameSpec("idle", 0.0)]


def teleport_specs(start: bool) -> List[FrameSpec]:
    values = []
    seq = range(8) if start else reversed(range(8))
    for i in seq:
        f = i / 7
        values.append(FrameSpec("teleport", f, scale=1.0 - 0.32*f, dy=-int(12*f), opacity=1.0 - 0.92*f))
    return values


def death_frame(form: str, progress: float, ranged: bool, canvas_size=(180, 130), seed: int = 1) -> Image.Image:
    base = render_lamassu(form, "hit" if progress < 0.38 else "idle", min(1, progress * 1.8), canvas_size=canvas_size, seed=seed)
    angle = (84 if ranged else -84) * max(0, (progress - 0.08) / 0.92)
    width_scale = 1.0 - 0.18 * progress
    height_scale = 1.0 - 0.32 * progress
    obj = base.resize((max(1, int(base.width * width_scale)), max(1, int(base.height * height_scale))), Image.Resampling.BICUBIC)
    obj = obj.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
    if progress > 0.70:
        alpha = obj.getchannel("A").point(lambda v: int(v * (0.92 + 0.08 * (1-progress))))
        obj.putalpha(alpha)
    out = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
    x = (out.width - obj.width)//2 - (6 if ranged else 1)
    y = out.height - obj.height - 3
    out.alpha_composite(obj, (x, y))
    if progress > 0.42:
        draw_dust(out, seed + 9, 0.9 * progress)
    return quantize_rgba(out, 100)


def transform_frame(frame: Image.Image, spec: FrameSpec) -> Image.Image:
    obj = frame.convert("RGBA")
    if spec.flip:
        obj = ImageOps.mirror(obj)
    if abs(spec.width_scale - 1.0) > 1e-6 or abs(spec.scale - 1.0) > 1e-6:
        obj = obj.resize((max(1, int(obj.width * spec.width_scale * spec.scale)), max(1, int(obj.height * spec.scale))), Image.Resampling.BICUBIC)
    if spec.angle:
        obj = obj.rotate(spec.angle, resample=Image.Resampling.BICUBIC, expand=True)
    if spec.opacity < 1:
        obj.putalpha(obj.getchannel("A").point(lambda v: int(v * spec.opacity)))
    out = Image.new("RGBA", frame.size, (0, 0, 0, 0))
    out.alpha_composite(obj, ((out.width-obj.width)//2 + spec.dx, (out.height-obj.height)//2 + spec.dy))
    return out


def render_spec(form: str, spec: FrameSpec, group: int, index: int) -> Image.Image:
    if spec.action == "death":
        frame = death_frame(form, spec.phase, ranged=False, seed=group*100+index)
    elif spec.action == "deathRanged":
        frame = death_frame(form, spec.phase, ranged=True, seed=group*100+index)
    elif spec.action == "corpse":
        frame = death_frame(form, 1.0, ranged=False, seed=group*100+index)
    else:
        frame = render_lamassu(form, spec.action, spec.phase, spec.direction, seed=group*100+index)
    return transform_frame(frame, spec)


def build_battle_animation(form_data: dict) -> Tuple[dict, Dict[int, List[Path]]]:
    slug = form_data["slug"]
    form = form_data["form"]
    out_dir = SPRITES / slug / "battle"
    out_dir.mkdir(parents=True, exist_ok=True)

    death = [FrameSpec("death", p) for p in phases(8)]
    death_ranged = [FrameSpec("deathRanged", p) for p in phases(8)]
    groups: Dict[int, List[FrameSpec]] = {
        0: move_specs(),
        1: fidget_specs(),
        2: idle_specs(),
        3: hit_specs(),
        4: defend_specs(),
        5: death,
        6: death_ranged,
        7: turn_specs(False),
        8: turn_specs(True),
        11: attack_specs("up"),
        12: attack_specs("front"),
        13: attack_specs("down"),
        14: attack_specs("up"),
        15: attack_specs("front"),
        16: attack_specs("down"),
        17: attack_specs("up", special=True),
        18: attack_specs("front", special=True),
        19: attack_specs("down", special=True),
        20: movement_edge_specs(True),
        21: movement_edge_specs(False),
        22: [FrameSpec("corpse", 1.0)],
        23: [FrameSpec("corpse", 1.0)],
        24: [FrameSpec("death", p) for p in reversed(phases(8))],
        30: cast_specs("up"),
        31: cast_specs("front"),
        32: cast_specs("down"),
        40: attack_specs("up", special=True),
        41: attack_specs("front", special=True),
        42: attack_specs("down", special=True),
        50: teleport_specs(True),
        51: teleport_specs(False),
    }
    sequences = []
    paths_by_group: Dict[int, List[Path]] = {}
    for group, specs in groups.items():
        files = []
        paths = []
        for index, spec in enumerate(specs):
            filename = f"g{group:02d}_{index:02d}.png"
            frame = render_spec(form, spec, group, index)
            frame.save(out_dir / filename, optimize=True)
            files.append(filename)
            paths.append(out_dir / filename)
        sequences.append({"group": group, "frames": files, "generateShadow": 1, "generateOverlay": 1})
        paths_by_group[group] = paths
    animation = {"basepath": f"{RESOURCE_NS}/{slug}/battle", "sequences": sequences}
    save_json(out_dir / "animation.json", animation)
    return animation, paths_by_group


def fit_transparent(frame: Image.Image, size=(72, 72), max_height=61, baseline=67) -> Image.Image:
    out = Image.new("RGBA", size, (0, 0, 0, 0))
    bbox = frame.getbbox()
    if not bbox:
        return out
    obj = frame.crop(bbox)
    if obj.height > max_height:
        ratio = max_height / obj.height
        obj = obj.resize((max(1, int(obj.width * ratio)), max_height), Image.Resampling.LANCZOS)
    if obj.width > size[0]-2:
        ratio = (size[0]-2) / obj.width
        obj = obj.resize((size[0]-2, max(1, int(obj.height*ratio))), Image.Resampling.LANCZOS)
    out.alpha_composite(obj, ((size[0]-obj.width)//2, baseline-obj.height))
    return out


def build_map_animation(form_data: dict) -> dict:
    slug = form_data["slug"]
    form = form_data["form"]
    out_dir = SPRITES / slug / "map"
    data_dir = DATA / slug
    out_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for i in range(8):
        battle = render_lamassu(form, "walk", i/8, canvas_size=(180, 130), seed=1200+i)
        frame = fit_transparent(battle)
        filename = f"map_{i:02d}.png"
        frame.save(out_dir / filename, optimize=True)
        files.append(filename)
    anim = {"basepath": f"{RESOURCE_NS}/{slug}/map", "sequences": [{"group": 0, "frames": files, "generateShadow": 2, "generateOverlay": 1}]}
    save_json(out_dir / "animation.json", anim)
    for side, flip in [("right", False), ("left", True)]:
        frame = render_lamassu(form, "attack", 0.65, canvas_size=(180,130), seed=1300)
        if flip:
            frame = ImageOps.mirror(frame)
        fit_transparent(frame).save(data_dir / f"map_attack_{side}.png", optimize=True)
    return anim


def radial_background(size: Tuple[int, int], accent: Tuple[int, int, int]) -> Image.Image:
    w, h = size
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    yy, xx = np.mgrid[0:h, 0:w]
    dist = np.sqrt(((xx-w*0.58)/(w*0.75))**2 + ((yy-h*0.38)/(h*0.78))**2)
    glow = np.clip(1-dist, 0, 1)
    arr[..., 0] = np.clip(9 + glow*accent[0]*0.20, 0, 255)
    arr[..., 1] = np.clip(10 + glow*accent[1]*0.16, 0, 255)
    arr[..., 2] = np.clip(15 + glow*accent[2]*0.27, 0, 255)
    arr[..., 3] = 255
    return Image.fromarray(arr, "RGBA")


def build_icons(form_data: dict) -> None:
    slug = form_data["slug"]
    form = form_data["form"]
    accent = tuple(form_data["accent"])
    out = DATA / slug
    out.mkdir(parents=True, exist_ok=True)
    card = radial_background((232, 256), accent)
    sprite = render_lamassu(form, "fidget", 0.45, canvas_size=(180,130), seed=2001)
    bbox = sprite.getbbox()
    if bbox:
        sprite = sprite.crop(bbox)
    target_w = 220
    target_h = 190
    ratio = min(target_w/sprite.width, target_h/sprite.height)
    sprite = sprite.resize((max(1,int(sprite.width*ratio)), max(1,int(sprite.height*ratio))), Image.Resampling.LANCZOS)
    card.alpha_composite(sprite, ((232-sprite.width)//2, 238-sprite.height))
    d = ImageDraw.Draw(card)
    d.rounded_rectangle((2,2,229,253), radius=13, outline=(220,180,80,255), width=3)
    d.rounded_rectangle((7,7,224,248), radius=10, outline=(69,45,24,255), width=2)
    d.text((10, 10), "VII", font=font(FONT_SERIF_BOLD, 25), fill=(225,207,148,255))
    card.save(out / "portrait_232x256.png", optimize=True)
    card.resize((58,64), Image.Resampling.LANCZOS).save(out / "icon_large.png", optimize=True)
    card.resize((32,32), Image.Resampling.LANCZOS).save(out / "icon_small.png", optimize=True)


def build_ability_icons() -> None:
    out = DATA / "shared"
    out.mkdir(parents=True, exist_ok=True)
    for size in (32, 64, 128):
        im = radial_background((size,size), (120,50,190))
        d = ImageDraw.Draw(im)
        cx = size/2
        cy = size/2
        for idx, rr in enumerate((0.41,0.31,0.22)):
            r = size*rr
            d.ellipse((cx-r,cy-r,cx+r,cy+r), outline=(177,92,232,220-idx*40), width=max(1,size//22))
        # Skull.
        d.ellipse((size*0.31,size*0.22,size*0.69,size*0.61), fill=(213,206,191,255), outline=(48,38,57,255), width=max(1,size//32))
        d.rectangle((size*0.39,size*0.52,size*0.61,size*0.75), fill=(188,178,164,255), outline=(48,38,57,255), width=max(1,size//32))
        d.ellipse((size*0.38,size*0.35,size*0.46,size*0.43), fill=(78,24,106,255))
        d.ellipse((size*0.54,size*0.35,size*0.62,size*0.43), fill=(78,24,106,255))
        for x in (0.42,0.50,0.58):
            d.line((size*x,size*0.60,size*x,size*0.72), fill=(73,59,70,255), width=max(1,size//42))
        d.rounded_rectangle((1,1,size-2,size-2), radius=max(2,size//10), outline=(221,180,78,255), width=max(1,size//24))
        im.save(out / f"funerary_reprise_{size}.png", optimize=True)


def build_effect_animation() -> None:
    out = SPRITES / "effects" / "funerary_reprise"
    out.mkdir(parents=True, exist_ok=True)
    files = []
    for i in range(16):
        p = i/15
        pulse = math.sin(math.pi*p)
        im = Image.new("RGBA", (160,120), (0,0,0,0))
        d = ImageDraw.Draw(im)
        radius = int(12 + 62*pulse)
        for rindex in range(4):
            rr = max(2, radius-rindex*6)
            alpha = int((180-rindex*35)*pulse)
            d.ellipse((80-rr,60-int(rr*0.46),80+rr,60+int(rr*0.46)), outline=(159,73,218,alpha), width=max(1,4-rindex))
        rng = random.Random(9000+i)
        for _ in range(int(28*pulse)):
            a = rng.random()*math.tau
            rr = rng.random()*radius
            x = int(80+math.cos(a)*rr)
            y = int(60+math.sin(a)*rr*0.48)
            sz = rng.choice([1,1,2])
            d.ellipse((x-sz,y-sz,x+sz,y+sz), fill=(210,126,255,rng.randint(70,210)))
        im = im.filter(ImageFilter.GaussianBlur(0.7))
        fn = f"effect_{i:02d}.png"
        im.save(out/fn, optimize=True)
        files.append(fn)
    save_json(out/"animation.json", {"basepath": f"{RESOURCE_NS}/effects/funerary_reprise", "sequences": [{"group":0,"frames":files,"generateShadow":0,"generateOverlay":0}]})


def normalize_audio(x: np.ndarray, peak: float = 0.92) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    maximum = np.max(np.abs(x)) if x.size else 1
    if maximum > 0:
        x = x / maximum * peak
    return np.clip(x, -1, 1)


def envelope(n: int, attack: float, release: float, sr: int) -> np.ndarray:
    env = np.ones(n)
    a = max(1, int(attack*sr))
    r = max(1, int(release*sr))
    env[:min(a,n)] = np.linspace(0,1,min(a,n))
    env[max(0,n-r):] = np.linspace(1,0,min(r,n))
    return env


def lowpass_noise(n: int, sr: int, cutoff: float, rng: np.random.Generator) -> np.ndarray:
    noise = rng.normal(0,1,n)
    sos = signal.butter(4, cutoff, btype="low", fs=sr, output="sos")
    return signal.sosfilt(sos, noise)


def bandpass_noise(n: int, sr: int, low: float, high: float, rng: np.random.Generator) -> np.ndarray:
    noise = rng.normal(0,1,n)
    sos = signal.butter(4, [low,high], btype="band", fs=sr, output="sos")
    return signal.sosfilt(sos, noise)


def add_at(base: np.ndarray, clip: np.ndarray, start: int, gain: float = 1.0) -> None:
    end = min(len(base), start+len(clip))
    if end > start:
        base[start:end] += clip[:end-start]*gain


def stone_thump(sr: int, seed: int, duration: float = 0.24, pitch: float = 43) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = int(duration*sr)
    t = np.arange(n)/sr
    freq = pitch*(1-0.55*t/max(duration,0.01))
    phase = 2*np.pi*np.cumsum(freq)/sr
    x = np.sin(phase)*np.exp(-t*18)
    x += lowpass_noise(n,sr,280,rng)*np.exp(-t*23)*0.72
    return normalize_audio(x,0.72)


def spectral_roar(sr: int, seed: int, duration: float, base: float) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = int(duration*sr)
    t = np.arange(n)/sr
    wobble = 1+0.11*np.sin(2*np.pi*4.2*t)+0.04*np.sin(2*np.pi*9.3*t)
    phase = 2*np.pi*np.cumsum(base*wobble*(1-0.08*t/duration))/sr
    voiced = np.sin(phase)+0.45*np.sin(2.01*phase+0.2)+0.24*np.sin(3.04*phase+0.8)
    noise = bandpass_noise(n,sr,100,1900,rng)
    x = (0.55*voiced+0.45*noise)*envelope(n,0.04,0.18,sr)
    x *= 0.72+0.28*np.maximum(0,np.sin(2*np.pi*6.2*t))
    return normalize_audio(x,0.80)


def synth_sound(kind: str, form: str, sr: int = 44100) -> np.ndarray:
    upgrade = form == "upgrade"
    base = 49 if upgrade else 57
    seed = 18200 + (300 if upgrade else 0) + sum(ord(c) for c in kind)
    rng = np.random.default_rng(seed)
    if kind == "attack":
        dur=0.92; x=np.zeros(int(dur*sr))
        add_at(x,spectral_roar(sr,seed+1,0.78,base),0,0.78)
        whoosh=bandpass_noise(int(0.36*sr),sr,480,5800,rng)*envelope(int(0.36*sr),0.02,0.12,sr)
        add_at(x,normalize_audio(whoosh,0.62),int(0.24*sr),0.7)
        add_at(x,stone_thump(sr,seed+2,0.22,38),int(0.53*sr),0.9)
    elif kind == "defend":
        dur=0.62; x=np.zeros(int(dur*sr))
        add_at(x,stone_thump(sr,seed+3,0.28,34),int(0.04*sr),0.92)
        scrape=bandpass_noise(len(x),sr,250,2400,rng)*envelope(len(x),0.02,0.20,sr)
        x += scrape*0.15
    elif kind == "killed":
        dur=1.70; n=int(dur*sr); t=np.arange(n)/sr
        x=spectral_roar(sr,seed+4,dur,base*0.92)*0.74
        crumble=lowpass_noise(n,sr,900,rng)*np.exp(-t*2.1)
        x += crumble*0.38
        for idx,when in enumerate((0.48,0.72,1.02)):
            add_at(x,stone_thump(sr,seed+20+idx,0.32,30+idx*4),int(when*sr),0.62)
    elif kind == "move":
        dur=0.70; x=np.zeros(int(dur*sr))
        add_at(x,stone_thump(sr,seed+5,0.22,40),int(0.05*sr),0.82)
        add_at(x,stone_thump(sr,seed+6,0.22,44),int(0.39*sr),0.80)
        rustle=bandpass_noise(len(x),sr,500,3200,rng)*envelope(len(x),0.03,0.20,sr)
        x += rustle*0.10
    elif kind == "startMoving":
        dur=0.38; x=np.zeros(int(dur*sr)); add_at(x,stone_thump(sr,seed+7,0.28,38),int(0.06*sr),0.90)
    elif kind == "endMoving":
        dur=0.43; x=np.zeros(int(dur*sr)); add_at(x,stone_thump(sr,seed+8,0.30,32),int(0.05*sr),0.96)
    elif kind == "wince":
        dur=0.58; n=int(dur*sr); t=np.arange(n)/sr
        phase=2*np.pi*np.cumsum((240 if upgrade else 275)*(1-0.55*t/dur))/sr
        x=(np.sin(phase)+0.25*np.sin(2.2*phase))*envelope(n,0.015,0.22,sr)
        x += bandpass_noise(n,sr,350,3500,rng)*envelope(n,0.01,0.19,sr)*0.30
    elif kind == "roar":
        x=spectral_roar(sr,seed+9,1.65,base)
    elif kind == "ripple":
        dur=1.30; n=int(dur*sr); t=np.arange(n)/sr
        sweep=np.sin(2*np.pi*(58+220*t)*t)+0.42*np.sin(2*np.pi*(117+430*t)*t)
        sweep*=envelope(n,0.03,0.35,sr)
        air=bandpass_noise(n,sr,180,4700,rng)*envelope(n,0.02,0.42,sr)
        x=0.55*sweep+0.38*air
        add_at(x,spectral_roar(sr,seed+10,0.78,base*0.68),int(0.18*sr),0.22)
    else:
        raise ValueError(kind)
    return normalize_audio(x,0.90)


def write_wav(path: Path, samples: np.ndarray, sr: int = 44100) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = (normalize_audio(samples)*32767).astype("<i2")
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sr)
        wav.writeframes(pcm.tobytes())


def build_sounds(form_data: dict) -> None:
    out = SOUNDS / form_data["slug"]
    out.mkdir(parents=True, exist_ok=True)
    for kind in ["attack","defend","killed","startMoving","endMoving","move","wince","roar","ripple"]:
        write_wav(out/f"{kind}.wav", synth_sound(kind, form_data["form"]))


def build_configs() -> None:
    family = [f"{MOD_ID}:sepulchralLamassu", f"{MOD_ID}:abyssalLamassu"]
    creatures = {}
    for creature_id, data in FORMS.items():
        stats = data["stats"]
        ripple = data["ripple"]
        abilities = {
            "undeadNature": {"type": "UNDEAD"},
            "noNormalRetaliation": {"type": "NO_RETALIATION"},
            "funeraryReprisal": {
                "type": "COMBAT_EVENT_TRIGGER",
                "subtype": f"{MOD_ID}:funeraryReprisal",
                "val": ripple["base"],
                "addInfo": {
                    "spell": "core:deathRipple",
                    "perCreature": ripple["perCreature"],
                    "maxDamage": ripple["maxDamage"],
                    "family": family,
                    "activeAttacksOnly": True,
                },
            },
        }
        creature = {
            "name": {"singular": data["name"], "plural": data["plural"]},
            "description": data["description"],
            "faction": "neutral",
            "level": stats["level"],
            "cost": stats["cost"],
            "speed": stats["speed"],
            "hitPoints": stats["hitPoints"],
            "attack": stats["attack"],
            "defense": stats["defense"],
            "damage": stats["damage"],
            "fightValue": stats["fightValue"],
            "aiValue": stats["aiValue"],
            "growth": stats["growth"],
            "horde": 0,
            "advMapAmount": stats["advMapAmount"],
            "doubleWide": True,
            "hasDoubleWeek": False,
            "excludeFromRandomization": False,
            "special": False,
            "abilities": abilities,
            "graphics": {
                "animation": f"{RESOURCE_NS}/{data['slug']}/battle/animation.json",
                "map": f"{RESOURCE_NS}/{data['slug']}/map/animation.json",
                "mapAttackFromLeft": f"{RESOURCE_NS}/{data['slug']}/map_attack_left.png",
                "mapAttackFromRight": f"{RESOURCE_NS}/{data['slug']}/map_attack_right.png",
                "iconLarge": f"{RESOURCE_NS}/{data['slug']}/icon_large.png",
                "iconSmall": f"{RESOURCE_NS}/{data['slug']}/icon_small.png",
                "animationTime": {"walk": 0.95, "attack": 0.95, "idle": 1.35},
                "timeBetweenFidgets": 3.8,
            },
            "sound": {
                "attack": f"{RESOURCE_NS}/{data['slug']}/attack.wav",
                "defend": f"{RESOURCE_NS}/{data['slug']}/defend.wav",
                "killed": f"{RESOURCE_NS}/{data['slug']}/killed.wav",
                "startMoving": f"{RESOURCE_NS}/{data['slug']}/startMoving.wav",
                "endMoving": f"{RESOURCE_NS}/{data['slug']}/endMoving.wav",
                "move": f"{RESOURCE_NS}/{data['slug']}/move.wav",
                "wince": f"{RESOURCE_NS}/{data['slug']}/wince.wav",
            },
        }
        if data["upgrade"]:
            creature["upgrades"] = [data["upgrade"]]
        creatures[creature_id] = creature
    save_json(CONFIG/"creatures.json", creatures)

    script_config = {
        "funeraryReprisal": {
            "implements": "combatEvent",
            "script": f"{RESOURCE_NS}/funeraryReprisal",
            "patches": [],
            "priority": 60,
            "schema": {
                "type": "object",
                "properties": {
                    "spell": {"type": "string"},
                    "perCreature": {"type": "integer", "minimum": 0},
                    "maxDamage": {"type": "integer", "minimum": 1},
                    "family": {"type": "array", "items": {"type": "string"}, "minItems": 1},
                    "activeAttacksOnly": {"type": "boolean"},
                },
                "required": ["spell", "perCreature", "maxDamage", "family"],
                "additionalProperties": False,
            },
            "description": (
                "{Funerary Reprisal}\nOnce per round per army, after this stack survives an enemy active melee hit, "
                "it casts Death Ripple instead of retaliating. Damage to every living stack is ${val} plus "
                "${perCreature} per surviving Lamassu in the reacting stack, capped at ${maxDamage}. The ripple "
                "affects living creatures on both sides. Ranged attacks, spells and enemy retaliation against the "
                "Lamassu's own attack do not trigger it."
            ),
        }
    }
    save_json(CONFIG/"scripts.json", script_config)

    mod_json = {
        "name": "Sepulchral Lamassu",
        "description": (
            "Adds the neutral Tier 7 Sepulchral Lamassu and its Abyssal Lamassu upgrade. Both are bulky, "
            "double-wide undead ground creatures with complete original battle/map art, generated sounds, and "
            "Funerary Reprisal: a once-per-round army-shared Death Ripple response to active melee attacks."
        ),
        "modType": "Creatures",
        "version": VERSION,
        "author": "OpenAI-assisted original custom mod package",
        "language": "english",
        "compatibility": {"min": "1.8.0"},
        "keepDisabled": False,
        "licenseName": "CC0-1.0 for original package assets and code, to the extent permitted",
        "creatures": [f"config/{RESOURCE_NS}/creatures.json"],
        "scripts": [f"config/{RESOURCE_NS}/scripts.json"],
        "changelog": {
            VERSION: [
                "Added Sepulchral Lamassu and Abyssal Lamassu.",
                "Added army-shared once-per-round Funerary Reprisal using core Death Ripple.",
                "Added 31 standard animation groups for both forms, map animations, portraits, effects and sounds.",
            ]
        },
    }
    save_json(MOD/"mod.json", mod_json)


def build_lua() -> None:
    lua = r'''local Base = require("combat/combatScript")

local Script = setmetatable({}, {__index = Base})
Script.__index = Script

local COOLDOWN_STACKING = "sepulchral-lamassu:funeraryReprisalUsed"
local COOLDOWN_SOURCE = "sepulchral-lamassu:funeraryReprisal"

function Script:cooldownBonuses(unit)
    return unit:getBonuses(function(bonus)
        return bonus:getStacking() == COOLDOWN_STACKING
    end)
end

function Script:isSpent(unit)
    return self:cooldownBonuses(unit):size() > 0
end

function Script:clearCooldown(server, battle, unit)
    local bonuses = self:cooldownBonuses(unit)
    if bonuses:size() > 0 then
        server:removeUnitBonuses(battle, unit, bonuses)
    end
end

function Script:isFamilyUnit(unit)
    if not unit then return false end
    local key = unit:getCreature():getJsonKey()
    for _, familyKey in ipairs(self.family or {}) do
        if key == familyKey then return true end
    end
    return false
end

function Script:markArmyFamilySpent(server, battle, unit)
    local side = unit:unitSide()
    local familyUnits = battle:getUnitsIf(function(candidate)
        return candidate:isAlive() and candidate:unitSide() == side and self:isFamilyUnit(candidate)
    end)

    for _, candidate in ipairs(familyUnits) do
        server:addUnitBonus(battle, candidate, {
            type = "NONE",
            val = 0,
            duration = ENUM.BonusDuration.oneBattle,
            sourceType = ENUM.BonusSource.other,
            sourceID = COOLDOWN_SOURCE,
            stacking = COOLDOWN_STACKING,
            hidden = true
        }, false)
    end
end

function Script:onBattleStart(server, battle, unit)
    -- Defensive cleanup for battle recreation / save loading. The first round begins ready.
    self:clearCooldown(server, battle, unit)
end

function Script:onRoundStart(server, battle, unit)
    -- Every living Lamassu receives this event, so all family markers are cleared for the new round.
    self:clearCooldown(server, battle, unit)
end

function Script:onAfterAttacked(server, battle, unit, other, payload)
    -- Like an ordinary retaliation, the reprisal is lost if the defender was killed by the blow.
    if not unit:isAlive() then return end
    if not other then return end

    -- Only direct melee attacks trigger it. Shots and spell damage never do.
    if payload and payload.ranged then return end

    -- Do not let the Lamassu deliberately trigger the wave by attacking and receiving retaliation.
    if self.activeAttacksOnly ~= false and payload and payload.isCounter then return end

    -- Shared cooldown prevents seven split Lamassu stacks from producing seven waves per round.
    if self:isSpent(unit) then return end

    local spell = LIBRARY:getSpellByName(self.spell or "core:deathRipple")
    if not spell then return end

    local targets = battle:getUnitsIf(function(candidate)
        return candidate:isAlive() and candidate:isLiving()
    end)

    if #targets == 0 then return end

    local damage = (self.val or 0) + unit:getCount() * (self.perCreature or 0)
    damage = math.max(1, math.min(damage, self.maxDamage or damage))

    self:markArmyFamilySpent(server, battle, unit)

    -- castSpell preserves the core Death Ripple animation, sound, immunities and damage pipeline.
    -- Combat-event scripts cannot re-enter themselves, so this cast does not recursively trigger the ability.
    server:castSpell(battle, unit, spell, targets, damage)
end

return Script
'''
    (SCRIPTS/"funeraryReprisal.lua").write_text(lua, encoding="utf-8")


def wrap_text(draw: ImageDraw.ImageDraw, text: str, font_obj, max_width: int) -> List[str]:
    words = text.split()
    lines = []
    current = ""
    for word in words:
        trial = word if not current else current + " " + word
        if draw.textbbox((0,0), trial, font=font_obj)[2] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def panel(draw: ImageDraw.ImageDraw, box, title: str | None = None) -> None:
    draw.rounded_rectangle(box, radius=12, fill=(8,13,22,238), outline=(181,132,48,255), width=2)
    if title:
        draw.text((box[0]+14, box[1]+8), title, font=font(FONT_SERIF_BOLD, 24), fill=(232,202,123,255))
        draw.line((box[0]+10, box[1]+40, box[2]-10, box[1]+40), fill=(113,77,34,255), width=1)


def load_frame(path: Path) -> Image.Image:
    return Image.open(path).convert("RGBA")


def animation_strip(paths: List[Path], count: int, cell=(150,120)) -> Image.Image:
    chosen = [paths[round(i*(len(paths)-1)/max(1,count-1))] for i in range(count)]
    out = Image.new("RGBA", (cell[0]*count, cell[1]), (0,0,0,0))
    for idx, path in enumerate(chosen):
        frame = load_frame(path)
        frame = frame.resize(cell, Image.Resampling.LANCZOS)
        out.alpha_composite(frame, (idx*cell[0],0))
    return out


def build_actual_assets_preview(frames_by_form: Dict[str, Dict[int, List[Path]]]) -> None:
    w,h = 1800,1160
    bg = radial_background((w,h),(93,49,133))
    draw = ImageDraw.Draw(bg)
    draw.text((45,28), "SEPULCHRAL LAMASSU", font=font(FONT_SERIF_BOLD, 54), fill=(237,207,126,255))
    draw.text((48,91), "Actual packaged sprites, icons, effects and balance configuration", font=font(FONT_REG, 22), fill=(194,202,218,255))

    panel(draw,(35,140,865,515),"Base Form - Sepulchral Lamassu")
    panel(draw,(935,140,1765,515),"Upgrade - Abyssal Lamassu")
    for idx,(cid,data) in enumerate(FORMS.items()):
        x0 = 55 if idx==0 else 955
        portrait = Image.open(DATA/data["slug"]/"portrait_232x256.png").convert("RGBA")
        bg.alpha_composite(portrait,(x0,200))
        stats=data["stats"]
        rows=[
            ("Tier",str(stats["level"])),("Attack",str(stats["attack"])),("Defense",str(stats["defense"])),
            ("Damage",f"{stats['damage']['min']}-{stats['damage']['max']}"),("Health",str(stats["hitPoints"])),
            ("Speed",str(stats["speed"])),("Growth",str(stats["growth"])),
            ("Cost",f"{stats['cost']['gold']}g + {stats['cost']['sulfur']} sulfur"),
        ]
        tx=x0+260; ty=198
        for name,val in rows:
            draw.text((tx,ty),name,font=font(FONT_BOLD,18),fill=(202,178,119,255))
            draw.text((tx+112,ty),val,font=font(FONT_REG,18),fill=(232,236,242,255))
            ty+=27
        ripple=data["ripple"]
        draw.text((tx,420),f"Ripple: {ripple['base']} + {ripple['perCreature']} per unit (cap {ripple['maxDamage']})",font=font(FONT_BOLD,15),fill=(*data["accent"],255))
        map_dir=SPRITES/data["slug"]/"map"
        draw.text((tx,447),"Adventure map:",font=font(FONT_REG,14),fill=(194,202,218,255))
        for j in range(6):
            map_frame=Image.open(map_dir/f"map_{j:02d}.png").convert("RGBA").resize((48,48),Image.Resampling.NEAREST)
            bg.alpha_composite(map_frame,(x0+365+j*54,447))

    panel(draw,(35,545,1765,835),"Battle Animation Samples - actual transparent PNG frames")
    actions=[("Idle",2),("Walk",0),("Attack",12),("Hit",3),("Defend",4),("Cast",31),("Death",5)]
    for form_idx,(cid,data) in enumerate(FORMS.items()):
        y=610+form_idx*105
        draw.text((55,y+32),data["name"],font=font(FONT_BOLD,20),fill=(226,205,151,255))
        x=270
        for label,group in actions:
            path=frames_by_form[cid][group][len(frames_by_form[cid][group])//2]
            frame=Image.open(path).convert("RGBA").resize((130,94),Image.Resampling.LANCZOS)
            bg.alpha_composite(frame,(x,y))
            draw.text((x+6,y+76),label,font=font(FONT_REG,15),fill=(230,234,239,255))
            x+=205

    panel(draw,(35,865,610,1125),"Funerary Reprisal")
    icon=Image.open(DATA/"shared"/"funerary_reprise_128.png").convert("RGBA")
    bg.alpha_composite(icon,(60,925))
    description=("Once per round per army, the first surviving Lamassu hit by an enemy active melee attack casts "
                 "Death Ripple instead of retaliating. All living stacks on both sides are valid targets. The "
                 "cooldown is shared across split base and upgraded stacks.")
    y=920
    for line_text in wrap_text(draw,description,font(FONT_REG,18),370):
        draw.text((210,y),line_text,font=font(FONT_REG,18),fill=(220,225,234,255)); y+=28

    panel(draw,(640,865,1765,1125),"Counterplay and implementation")
    bullets=[
        "Ranged attacks and spells do not trigger the wave.",
        "A retaliation received after the Lamassu attacks does not trigger it.",
        "The Lamassu must survive the melee hit.",
        "Death Ripple harms friendly living units too; undead and other non-living units are unaffected.",
        "The creature never performs a normal retaliation, even after its wave is spent for the round.",
        "Core Death Ripple supplies the in-game spell animation, sound, immunities and damage pipeline.",
    ]
    y=920
    for item in bullets:
        draw.ellipse((675,y+7,683,y+15),fill=(178,91,224,255))
        for li,line_text in enumerate(wrap_text(draw,item,font(FONT_REG,18),1010)):
            draw.text((695,y),line_text,font=font(FONT_REG,18),fill=(224,228,236,255)); y+=25
        y+=5

    bg.convert("RGB").save(ASSETS_PREVIEW_PATH,quality=95)
    shutil.copy2(ASSETS_PREVIEW_PATH,PREVIEW/"Actual_Assets_Preview.png")


def build_showcase(frames_by_form: Dict[str, Dict[int, List[Path]]]) -> None:
    w,h=1920,1080
    bg=radial_background((w,h),(72,38,105))
    draw=ImageDraw.Draw(bg)
    # Ruin silhouettes.
    for x,width,height in [(0,210,610),(170,140,420),(1500,200,530),(1710,210,680)]:
        draw.rectangle((x,h-height,x+width,h),fill=(5,8,13,215))
        for yy in range(h-height+60,h,75):
            draw.rectangle((x+18,yy,x+width-18,yy+18),fill=(15,16,22,180))
    draw.text((55,34),"SEPULCHRAL LAMASSU",font=font(FONT_SERIF_BOLD,62),fill=(238,201,111,255))
    draw.text((61,108),"Neutral Tier 7 undead guardians for VCMI",font=font(FONT_SERIF,27),fill=(211,216,229,255))

    # Large forms.
    for idx,(cid,data) in enumerate(FORMS.items()):
        x=55+idx*960
        panel(draw,(x,165,x+890,615),data["name"])
        portrait=Image.open(DATA/data["slug"]/"portrait_232x256.png").convert("RGBA").resize((325,360),Image.Resampling.LANCZOS)
        bg.alpha_composite(portrait,(x+30,220))
        st=data["stats"]
        entries=[("Attack",st["attack"]),("Defense",st["defense"]),("Damage",f"{st['damage']['min']}-{st['damage']['max']}"),("Health",st["hitPoints"]),("Speed",st["speed"]),("Growth",st["growth"]),("AI Value",st["aiValue"])]
        y=224
        for name,val in entries:
            draw.text((x+385,y),name,font=font(FONT_BOLD,22),fill=(206,178,108,255))
            draw.text((x+555,y),str(val),font=font(FONT_REG,22),fill=(236,238,244,255)); y+=38
        rp=data["ripple"]
        draw.text((x+385,y+8),"Funerary Reprisal",font=font(FONT_SERIF_BOLD,24),fill=(*data["accent"],255)); y+=44
        text=f"Death Ripple damage: {rp['base']} + {rp['perCreature']} per surviving unit, maximum {rp['maxDamage']}."
        for tline in wrap_text(draw,text,font(FONT_REG,18),305):
            draw.text((x+385,y),tline,font=font(FONT_REG,18),fill=(222,226,235,255)); y+=27

    panel(draw,(55,645,1215,1025),"Actual battle animation and adventure-map assets")
    y=705
    for cid,data in FORMS.items():
        draw.text((78,y+30),data["name"],font=font(FONT_BOLD,19),fill=(230,208,148,255))
        x=285
        for group in [2,0,12,4,31,5]:
            paths=frames_by_form[cid][group]
            frame=Image.open(paths[len(paths)//2]).convert("RGBA").resize((135,98),Image.Resampling.LANCZOS)
            bg.alpha_composite(frame,(x,y))
            x+=148
        y+=126

    panel(draw,(1245,645,1865,1025),"Ability rules")
    icon=Image.open(DATA/"shared"/"funerary_reprise_128.png").convert("RGBA")
    bg.alpha_composite(icon,(1280,710))
    rules=[
        "First enemy active melee hit each round; one shared trigger across all Lamassu stacks in that army.",
        "Casts core Death Ripple against every living stack on both sides.",
        "No ordinary retaliation; ranged attacks, spells and lethal blows are safe counters.",
        "Double-wide ground unit; its ruined ritual wings do not grant flight.",
    ]
    y=710
    for item in rules:
        for text_line in wrap_text(draw,item,font(FONT_REG,17),390):
            draw.text((1435,y),text_line,font=font(FONT_REG,17),fill=(226,230,237,255)); y+=24
        y+=10
    draw.text((1285,980),"VCMI 1.8 development build or newer",font=font(FONT_BOLD,17),fill=(192,127,232,255))

    bg.convert("RGB").save(SHOWCASE_PATH,quality=95)
    shutil.copy2(SHOWCASE_PATH,PREVIEW/"Showcase.png")


def write_docs() -> None:
    readme = f"""# Sepulchral Lamassu - VCMI Creature Mod {VERSION}

This ready-to-install package adds two neutral Tier 7 creatures:

- Sepulchral Lamassu
- Abyssal Lamassu, its upgrade

Both are double-wide undead ground creatures. Their ceremonial wings are broken, stone-heavy and non-functional; neither form flies.

## Installation

1. Close VCMI, VCMI Launcher and VCMI Map Editor.
2. Extract the folder `sepulchral-lamassu` from the ZIP into:

   `%USERPROFILE%\\Documents\\My Games\\vcmi\\Mods\\`

3. Confirm this exact file exists:

   `%USERPROFILE%\\Documents\\My Games\\vcmi\\Mods\\sepulchral-lamassu\\mod.json`

4. Do not leave a double folder such as:

   `...\\Mods\\sepulchral-lamassu\\sepulchral-lamassu\\mod.json`

5. Start VCMI Launcher and enable **Sepulchral Lamassu**.

## Required engine

Use a current VCMI 1.8 development/daily build or newer. The ability is implemented with the developing combat-event Lua API (`COMBAT_EVENT_TRIGGER`, `onAfterAttacked`, round-start events and `BattleServer:castSpell`).

## Funerary Reprisal

- The creatures never perform a normal retaliation.
- Once per round **per army**, the first Sepulchral or Abyssal Lamassu stack that survives an enemy active melee hit casts Death Ripple.
- The cooldown is shared by all base and upgraded Lamassu stacks on that side. Splitting them into seven stacks does not create seven waves.
- Ranged attacks and spell damage do not trigger it.
- A counterattack received after the Lamassu initiates an attack does not trigger it.
- A lethal hit does not trigger it because a dead defender could not retaliate.
- The core Death Ripple spell filters targets and supplies the normal spell presentation.
- All living stacks on both sides are selected. Friendly living creatures can therefore be harmed.
- Undead and other units VCMI classifies as non-living are not selected.

### Damage

Sepulchral Lamassu:

`20 + 5 x surviving creatures in the reacting stack`, maximum 90 damage to each eligible stack.

Abyssal Lamassu:

`30 + 6 x surviving creatures in the reacting stack`, maximum 120 damage to each eligible stack.

This makes the wave dangerous to armies spread across many low-health living stacks, while a compact army of a few elite stacks absorbs far less total damage.

## First test

Create a small VCMI map with two heroes.

1. Give hero A one Sepulchral Lamassu.
2. Give hero B several living stacks, including one melee stack and one shooter.
3. Make the melee stack attack the Lamassu. Expected: Death Ripple plays after the hit; the Lamassu does not retaliate normally.
4. Hit it in melee again during the same round. Expected: no second wave.
5. Start the next round and hit it again. Expected: the wave is available again.
6. Shoot it. Expected: no wave.
7. Cast a damage spell on it. Expected: no wave.
8. Let the Lamassu attack and receive enemy retaliation. Expected: no wave.
9. Add a second split Lamassu stack. Expected: only the first qualifying Lamassu hit on that side triggers during the round.
10. Add friendly living creatures beside the Lamassu. Expected: they are also affected by Death Ripple.

## Editable files

- Creature stats: `Content/config/sepulchral/creatures.json`
- Script registration and tooltip: `Content/config/sepulchral/scripts.json`
- Complete mechanic: `Content/scripts/sepulchral/funeraryReprisal.lua`
- Complete asset/build source: `tools/build_sepulchral_lamassu_mod.py`

## Art and audio

All packaged sprites, icons, effects and WAV files were created for this package. The supplied web references and the Heroes VII creature were used only as broad thematic references for an undead sphinx/lamassu concept. No Pinterest, Heroes VII, WoG, HotA or third-party creature asset is redistributed.

The VCMI live runtime was not available in the build environment. The package therefore passed static validation but still needs its first real client/server launch on your laptop. If VCMI rejects a development-build API field, inspect `VCMI_Client_log.txt` and `VCMI_Server_log.txt` in the VCMI user-data folder.
"""
    (MOD/"README_FIRST.md").write_text(readme,encoding="utf-8")

    balance = """# Balance Notes

## Why Tier 7

The Lamassu is physically enormous, double-wide, expensive, slow and designed around a battlefield-wide reaction. Tier 7 gives enough health to survive a melee hit and actually use the mechanic without giving it high initiative or flying movement.

## Self-balancing constraints

1. It has no normal retaliation.
2. It must survive the triggering blow.
3. It triggers only once per round per army, not once per split stack.
4. It does not trigger against shooters or spells.
5. It does not trigger from retaliation after attacking.
6. Death Ripple also harms the Lamassu owner's living allies.
7. Damage is capped.
8. Speed remains low for a Tier 7 unit.

## Intended counters

- Shoot it before entering melee.
- Use direct-damage or control spells.
- Field a small number of durable elite stacks rather than many disposable living stacks.
- Use undead, constructs, elementals or other non-living troops where appropriate.
- Kill the reacting stack in the triggering blow.

## Shared cooldown

The user's wording was "once per round". This implementation treats that as once per round for the entire Lamassu family on one army side. It intentionally prevents stack splitting from multiplying the global wave.
"""
    (MOD/"BALANCE_NOTES.md").write_text(balance,encoding="utf-8")

    technical = """# Technical Notes

The ability is attached through `COMBAT_EVENT_TRIGGER` and reacts in `onAfterAttacked`.

State persistence uses a hidden `NONE` bonus whose stacking key is:

`sepulchral-lamassu:funeraryReprisalUsed`

When one family stack triggers, the script adds that marker to every living Sepulchral/Abyssal Lamassu stack on the same battle side. Every living family unit removes its own marker in `onRoundStart`. `onBattleStart` performs defensive cleanup for the first round and battle restoration.

The script passes every alive unit for which `Unit:isLiving()` is true to `BattleServer:castSpell`, using `core:deathRipple`. VCMI then performs the spell's own filtering, animation, sound and synchronized damage application.

`NO_RETALIATION` is permanent because the intended replacement is not "one spell plus later ordinary retaliations"; the creature's retaliation model is entirely replaced by the once-per-round wave.
"""
    (MOD/"TECHNICAL_NOTES.md").write_text(technical,encoding="utf-8")

    license_text = """Original package assets and code are dedicated under CC0 1.0 to the extent the authoring system is legally able to do so.

Heroes of Might and Magic, VCMI and all related trademarks belong to their respective owners. This package contains no original game data and requires a legal Heroes III Complete / Shadow of Death data installation for use with VCMI.
"""
    (MOD/"LICENSE.txt").write_text(license_text,encoding="utf-8")

    if CONCEPT_POSTER.exists():
        shutil.copy2(CONCEPT_POSTER,SOURCE/"generated_preproduction_concept.png")
        (SOURCE/"README.txt").write_text(
            "The included poster is the generated pre-production concept used to choose the creature silhouette and palette. "
            "Its printed placeholder stats and compatibility text are not authoritative. Use the JSON configs and README_FIRST.md.\n",
            encoding="utf-8",
        )

    shutil.copy2(Path(__file__),TOOLS/"build_sepulchral_lamassu_mod.py")


def file_sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()


def validate_package(frames_by_form: Dict[str, Dict[int, List[Path]]]) -> List[str]:
    checks=[]
    # JSON.
    json_files=list(MOD.rglob("*.json"))
    for path in json_files:
        json.loads(path.read_text(encoding="utf-8"))
    checks.append(f"PASS: {len(json_files)} JSON files parsed strictly")

    creatures=json.loads((CONFIG/"creatures.json").read_text(encoding="utf-8"))
    assert set(creatures)==set(FORMS)
    for cid,data in FORMS.items():
        config=creatures[cid]
        assert config["level"]==7 and config["doubleWide"] is True
        ability=config["abilities"]["funeraryReprisal"]
        assert ability["type"]=="COMBAT_EVENT_TRIGGER"
        assert config["abilities"]["noNormalRetaliation"]["type"]=="NO_RETALIATION"
        assert config["abilities"]["undeadNature"]["type"]=="UNDEAD"
        for key in ["animation","map","mapAttackFromLeft","mapAttackFromRight","iconLarge","iconSmall"]:
            value=config["graphics"][key]
            candidates=[CONTENT/"sprites"/value,CONTENT/"data"/value]
            assert any(p.exists() for p in candidates), f"Missing {value}"
        for value in config["sound"].values():
            assert (SOUNDS/value.removeprefix(f"{RESOURCE_NS}/")).exists(), value
    checks.append("PASS: creature definitions, nature, no-retaliation and scripted ability fields")

    frame_count=0
    for cid,data in FORMS.items():
        anim=json.loads((SPRITES/data["slug"]/"battle"/"animation.json").read_text(encoding="utf-8"))
        group_map={seq["group"]:seq for seq in anim["sequences"]}
        assert sorted(group_map)==REQUIRED_GROUPS
        for seq in anim["sequences"]:
            assert seq["frames"]
            for filename in seq["frames"]:
                path=SPRITES/data["slug"]/"battle"/filename
                assert path.exists()
                with Image.open(path) as im:
                    assert im.mode=="RGBA"
                    assert im.size==(180,130)
                    assert im.getchannel("A").getbbox() is not None
                frame_count+=1
    checks.append(f"PASS: {frame_count} non-empty RGBA battle frames across all 31 groups per form")

    map_count=0
    for data in FORMS.values():
        map_anim=json.loads((SPRITES/data["slug"]/"map"/"animation.json").read_text(encoding="utf-8"))
        assert len(map_anim["sequences"][0]["frames"])==8
        for fn in map_anim["sequences"][0]["frames"]:
            with Image.open(SPRITES/data["slug"]/"map"/fn) as im:
                assert im.mode=="RGBA" and im.size==(72,72) and im.getchannel("A").getbbox()
            map_count+=1
    checks.append(f"PASS: {map_count} adventure-map animation frames")

    wav_files=list(SOUNDS.rglob("*.wav"))
    for path in wav_files:
        with wave.open(str(path),"rb") as wav:
            assert wav.getnchannels()==1
            assert wav.getsampwidth()==2
            assert wav.getframerate()==44100
            assert wav.getnframes()>1000
    checks.append(f"PASS: {len(wav_files)} mono PCM16 44.1 kHz WAV files")

    lua=(SCRIPTS/"funeraryReprisal.lua").read_text(encoding="utf-8")
    required_tokens=["onAfterAttacked","onRoundStart","onBattleStart","payload.ranged","payload.isCounter","isLiving()","castSpell","core:deathRipple","COOLDOWN_STACKING","NO_RETALIATION"]
    # NO_RETALIATION lives in config, not Lua; combine texts for check.
    combined=lua+(CONFIG/"creatures.json").read_text(encoding="utf-8")
    for token in required_tokens:
        assert token in combined, token
    checks.append("PASS: Lua mechanic contains melee filters, shared cooldown, round reset and Death Ripple cast")

    assert ASSETS_PREVIEW_PATH.exists() and SHOWCASE_PATH.exists()
    checks.append("PASS: actual-assets preview and showcase generated")
    return checks


def write_manifest() -> None:
    lines=[]
    for path in sorted(p for p in MOD.rglob("*") if p.is_file()):
        rel=path.relative_to(MOD).as_posix()
        lines.append(f"{file_sha256(path)}  {rel}")
    (MOD/"MANIFEST_SHA256.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")


def create_zip() -> None:
    with zipfile.ZipFile(ZIP_PATH,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(p for p in MOD.rglob("*") if p.is_file()):
            archive.write(path,arcname=(Path(MOD_ID)/path.relative_to(MOD)).as_posix())
    with zipfile.ZipFile(ZIP_PATH,"r") as archive:
        bad=archive.testzip()
        assert bad is None, bad
        roots={name.split("/")[0] for name in archive.namelist() if name}
        assert roots=={MOD_ID},roots
        assert f"{MOD_ID}/mod.json" in archive.namelist()


def main() -> None:
    ensure_dirs()
    frames_by_form={}
    for cid,data in FORMS.items():
        _,frames=build_battle_animation(data)
        frames_by_form[cid]=frames
        build_map_animation(data)
        build_icons(data)
        build_sounds(data)
    build_ability_icons()
    build_effect_animation()
    build_configs()
    build_lua()
    write_docs()
    build_actual_assets_preview(frames_by_form)
    build_showcase(frames_by_form)
    checks=validate_package(frames_by_form)
    qa="SEPULCHRAL LAMASSU STATIC QA REPORT\n"+"="*42+"\n"+"\n".join(checks)+"\n"
    qa += "PASS: live VCMI runtime test intentionally pending on the user's installed engine\n"
    (MOD/"QA_REPORT.txt").write_text(qa,encoding="utf-8")
    QA_PATH.write_text(qa,encoding="utf-8")
    write_manifest()
    create_zip()
    digest=file_sha256(ZIP_PATH)
    SHA_PATH.write_text(f"{digest}  {ZIP_PATH.name}\n",encoding="utf-8")
    print(qa,end="")
    print(f"ZIP: {ZIP_PATH}")
    print(f"SHA256: {digest}")
    print(f"FILES: {sum(1 for p in MOD.rglob('*') if p.is_file())}")


if __name__ == "__main__":
    main()
