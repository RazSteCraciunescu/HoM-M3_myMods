# Editing the Sepulchral Lamassu Visuals

## Creature icons

Replace these files without changing their names:

- `Content\data\sepulchral\sepulchral_lamassu\icon_large.png` — 58x64 RGBA
- `Content\data\sepulchral\sepulchral_lamassu\icon_small.png` — 32x32 RGBA
- `Content\data\sepulchral\abyssal_lamassu\icon_large.png` — 58x64 RGBA
- `Content\data\sepulchral\abyssal_lamassu\icon_small.png` — 32x32 RGBA

Do not include labels, names, borders from a presentation sheet, or other documentation text inside these images.

## Battle frames

The battle frames are under:

- `Content\sprites\sepulchral\sepulchral_lamassu\battle\`
- `Content\sprites\sepulchral\abyssal_lamassu\battle\`

Keep each frame as 280x260 RGBA and keep the existing names such as `g02_00.png` and `g12_04.png`.

The frame prefix is the animation group:

- `g00` movement
- `g01` hover/fidget
- `g02` idle
- `g03` hit
- `g04` defend
- `g05` death
- `g11`, `g12`, `g13` melee attack up/front/down
- `g30`, `g31`, `g32` cast up/front/down
- `g22` corpse
- `g24` resurrection

Do not shorten the full resource paths inside `animation.json`. Version 2.2.0 deliberately uses explicit paths to prevent missing-texture placeholders.

## Adventure-map frames

Replace `map_00.png` through `map_07.png` under each creature's `map` folder. Keep them 96x96 RGBA.

## Ability icon

Replace:

`Content\data\sepulchral\shared\funerary_reprise_32.png`

Keep it 32x32. Leave a small safe margin around the artwork so it stays inside the ability box.

## Validate

From the mod folder, double-click:

`VALIDATE_VISUALS.cmd`

or run:

`py -3 tools\validate_visual_resources.py`
