from __future__ import annotations

import json
import sys
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
CONTENT = ROOT / "Content"
ERRORS: list[str] = []
CHECKED = 0


def fail(message: str) -> None:
    ERRORS.append(message)


def require_file(path: Path) -> None:
    global CHECKED
    CHECKED += 1
    if not path.is_file():
        fail(f"Missing file: {path.relative_to(ROOT)}")


def check_png(path: Path, expected_size=None) -> None:
    require_file(path)
    if not path.is_file():
        return
    try:
        with Image.open(path) as image:
            if image.mode != "RGBA":
                fail(f"PNG is not RGBA: {path.relative_to(ROOT)} ({image.mode})")
            if expected_size and image.size != expected_size:
                fail(f"Wrong PNG size: {path.relative_to(ROOT)} {image.size}, expected {expected_size}")
            if image.getchannel("A").getbbox() is None:
                fail(f"PNG is fully transparent: {path.relative_to(ROOT)}")
    except Exception as exc:
        fail(f"Unreadable PNG: {path.relative_to(ROOT)}: {exc}")


def check_animation(resource: str, expected_groups: set[int], expected_size) -> None:
    path = CONTENT / "sprites" / resource
    require_file(path)
    if not path.is_file():
        return
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"Invalid animation JSON {resource}: {exc}")
        return
    if "basepath" in data:
        fail(f"Ambiguous basepath still present in {resource}; 2.2.0 must use explicit frame paths")
    groups = {entry.get("group") for entry in data.get("sequences", [])}
    missing_groups = expected_groups - groups
    if missing_groups:
        fail(f"Missing animation groups in {resource}: {sorted(missing_groups)}")
    for entry in data.get("sequences", []):
        for frame in entry.get("frames", []):
            if not isinstance(frame, str) or "/" not in frame:
                fail(f"Frame path is not explicit in {resource}: {frame!r}")
                continue
            check_png(CONTENT / "sprites" / frame, expected_size)


def main() -> int:
    creatures_path = CONTENT / "config" / "sepulchral" / "creatures.json"
    require_file(creatures_path)
    try:
        creatures = json.loads(creatures_path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"Invalid creatures.json: {exc}")
        creatures = {}

    required_battle_groups = {0,1,2,3,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,30,31,32,40,41,42,50,51}

    for creature_id, creature in creatures.items():
        graphics = creature.get("graphics", {})
        check_animation(graphics.get("animation", ""), required_battle_groups, (280, 260))
        check_animation(graphics.get("map", ""), {0}, (96, 96))
        check_png(CONTENT / "data" / graphics.get("iconLarge", ""), (58, 64))
        check_png(CONTENT / "data" / graphics.get("iconSmall", ""), (32, 32))
        check_png(CONTENT / "data" / graphics.get("mapAttackFromLeft", ""), (96, 96))
        check_png(CONTENT / "data" / graphics.get("mapAttackFromRight", ""), (96, 96))
        if graphics.get("mapMask") != ["VVV", "VAV"]:
            fail(f"Unexpected mapMask for {creature_id}: {graphics.get('mapMask')}")
        ability = creature.get("abilities", {}).get("funeraryReprisal", {})
        icon_path = ability.get("icon", "")
        check_png(CONTENT / "data" / icon_path, (32, 32))
        for sound_path in creature.get("sound", {}).values():
            require_file(CONTENT / "sounds" / sound_path)

    check_animation("sepulchral/effects/funerary_reprise/animation.json", {0}, (256, 256))

    if ERRORS:
        print("VISUAL VALIDATION FAILED")
        for error in ERRORS:
            print(f"- {error}")
        return 1
    print(f"VISUAL VALIDATION PASSED: {CHECKED} referenced files checked")
    return 0


if __name__ == "__main__":
    sys.exit(main())
