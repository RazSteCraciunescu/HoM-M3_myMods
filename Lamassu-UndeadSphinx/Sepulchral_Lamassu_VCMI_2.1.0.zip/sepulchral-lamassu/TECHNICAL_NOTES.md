# Technical Notes

The ability is attached through `COMBAT_EVENT_TRIGGER` and reacts in `onAfterAttacked`.

State persistence uses a hidden `NONE` bonus whose stacking key is:

`sepulchral-lamassu:funeraryReprisalUsed`

When one family stack triggers, the script adds that marker to every living Sepulchral/Abyssal Lamassu stack on the same battle side. Every living family unit removes its own marker in `onRoundStart`. `onBattleStart` performs defensive cleanup for the first round and battle restoration.

The script passes every alive unit for which `Unit:isLiving()` is true to `BattleServer:castSpell`, using `core:deathRipple`. VCMI then performs the spell's own filtering, animation, sound and synchronized damage application.

`NO_RETALIATION` is permanent because the intended replacement is not "one spell plus later ordinary retaliations"; the creature's retaliation model is entirely replaced by the once-per-round wave.


## Version 2 art pipeline

The v2 animation frames are generated from eight painted key poses per creature form: idle, walk, horizontal attack, vertical attack, defend, hit, cast and death. The animation JSON retains all supported VCMI creature groups. Motion frames apply restrained translation, scale, rotation, brightness and alpha changes to those painted poses; no geometric creature renderer is used.
