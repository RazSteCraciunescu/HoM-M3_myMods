# Balance Notes

## Why Tier 7

The Lamassu is physically enormous, double-wide, expensive, slow and designed around a battlefield-wide reaction. Tier 7 gives enough health to survive a melee hit and actually use the mechanic without giving it high initiative or flying movement.

## Self-balancing constraints

1. It has no normal retaliation.
2. It must survive the triggering blow.
3. It triggers only once per round per army, not once per split stack.
4. It does not trigger against shooters or spells.
5. It does not trigger from retaliation after attacking.
6. Death Ripple also harms the Lamassu owner's living allies.
7. Damage is capped.
8. Speed remains low for a Tier 7 unit.

## Intended counters

- Shoot it before entering melee.
- Use direct-damage or control spells.
- Field a small number of durable elite stacks rather than many disposable living stacks.
- Use undead, constructs, elementals or other non-living troops where appropriate.
- Kill the reacting stack in the triggering blow.

## Shared cooldown

The user's wording was "once per round". This implementation treats that as once per round for the entire Lamassu family on one army side. It intentionally prevents stack splitting from multiplying the global wave.
