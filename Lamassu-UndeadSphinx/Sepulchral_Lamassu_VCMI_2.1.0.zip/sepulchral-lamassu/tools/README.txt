Version 2.0 ships finished assets. The rejected 1.0 geometric asset generator was removed.
Gameplay JSON and Lua remain directly editable with a text editor.
