from __future__ import annotations

import hashlib
import json
import math
import os
import random
import shutil
import textwrap
import zipfile
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

ROOT = Path('/mnt/data/Sepulchral_Lamassu_VCMI_2.1.0_work/sepulchral-lamassu')
KEY_ROOT = Path('/mnt/data/lamassu_dark_keys_v4')
NEW_BOARD = Path('/mnt/data/a_wide_detailed_promotional_sprite_sheet_mod_pr.png')
OLD_CONCEPT = ROOT / 'source' / 'generated_preproduction_concept.png'
OUT_ZIP = Path('/mnt/data/Sepulchral_Lamassu_VCMI_2.1.0.zip')
OUT_PREVIEW = Path('/mnt/data/Sepulchral_Lamassu_VCMI_2.1.0_ACTUAL_SPRITES.png')
OUT_CHECKSUM = Path('/mnt/data/Sepulchral_Lamassu_VCMI_2.1.0_SHA256.txt')
OUT_QA = Path('/mnt/data/Sepulchral_Lamassu_VCMI_2.1.0_QA_REPORT.txt')

CANVAS = (280, 260)
BASELINE = 249
BATTLE_BOX = (242, 230)
MAP_CANVAS = (96, 96)
MAP_BOX = (84, 82)

FORMS = {
    'base': {
        'slug': 'sepulchral_lamassu',
        'title': 'Sepulchral Lamassu',
        'keys': [KEY_ROOT / f'base_{i:02d}.png' for i in range(11)],
        'accent': (122, 70, 188),
        'glow': (148, 74, 255),
        'portrait_box': (18, 0, 475, 380),
    },
    'upgrade': {
        'slug': 'abyssal_lamassu',
        'title': 'Abyssal Lamassu',
        'keys': [KEY_ROOT / f'upgrade_{i:02d}.png' for i in range(11)],
        'accent': (184, 53, 143),
        'glow': (209, 59, 255),
        'portrait_box': (837, 0, 1312, 380),
    },
}

GROUP_COUNTS = {
    0: 8, 1: 8, 2: 8, 3: 5, 4: 6, 5: 8, 6: 8, 7: 7, 8: 7,
    11: 8, 12: 8, 13: 8, 14: 8, 15: 8, 16: 8, 17: 8, 18: 8, 19: 8,
    20: 3, 21: 3, 22: 1, 23: 1, 24: 8,
    30: 8, 31: 8, 32: 8, 40: 8, 41: 8, 42: 8, 50: 8, 51: 8,
}

# High-detail source-pose plan. Each group uses rendered key poses; transforms add motion without redrawing the creature.
POSE_PLANS = {
    0:  [0, 4, 6, 5, 0, 4, 6, 5],
    1:  [0, 0, 3, 9, 3, 0, 0, 0],
    2:  [0, 0, 0, 0, 0, 0, 0, 0],
    3:  [0, 7, 7, 7, 0],
    4:  [0, 2, 4, 2, 4, 0],
    5:  [0, 7, 9, 10, 10, 10, 10, 10],
    6:  [0, 7, 9, 10, 10, 10, 10, 10],
    7:  [0, 1, 2, 3, 2, 1, 0],
    8:  [0, 9, 3, 2, 3, 9, 0],
    11: [0, 4, 3, 5, 5, 4, 0, 0],
    12: [0, 4, 6, 5, 5, 6, 4, 0],
    13: [0, 4, 2, 5, 5, 2, 4, 0],
    14: [0, 9, 8, 8, 8, 9, 0, 0],
    15: [0, 9, 8, 8, 8, 9, 0, 0],
    16: [0, 9, 8, 8, 8, 9, 0, 0],
    17: [0, 9, 8, 8, 8, 9, 0, 0],
    18: [0, 9, 8, 8, 8, 9, 0, 0],
    19: [0, 9, 8, 8, 8, 9, 0, 0],
    20: [0, 4, 6],
    21: [6, 4, 0],
    22: [10],
    23: [10],
    24: [10, 10, 9, 7, 3, 1, 0, 0],
    30: [0, 9, 8, 8, 8, 9, 0, 0],
    31: [0, 9, 8, 8, 8, 9, 0, 0],
    32: [0, 9, 8, 8, 8, 9, 0, 0],
    40: [0, 9, 8, 8, 8, 9, 0, 0],
    41: [0, 9, 8, 8, 8, 9, 0, 0],
    42: [0, 9, 8, 8, 8, 9, 0, 0],
    50: [0, 0, 0, 0, 0, 0, 0, 0],
    51: [0, 0, 0, 0, 0, 0, 0, 0],
}


def font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSerif-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf',
    ]
    for p in candidates:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def alpha_bbox(img: Image.Image) -> Tuple[int, int, int, int]:
    a = img.getchannel('A')
    box = a.getbbox()
    return box if box else (0, 0, 1, 1)


def clean_key(img: Image.Image) -> Image.Image:
    img = img.convert('RGBA')
    box = alpha_bbox(img)
    img = img.crop(box)
    # Remove barely-visible extraction haze while preserving antialiased edges.
    r, g, b, a = img.split()
    a = a.point(lambda v: 0 if v < 10 else v)
    rgb = Image.merge('RGB', (r, g, b))
    rgb = ImageEnhance.Contrast(rgb).enhance(1.08)
    rgb = ImageEnhance.Color(rgb).enhance(1.08)
    rgb = rgb.filter(ImageFilter.UnsharpMask(radius=1.1, percent=125, threshold=3))
    return Image.merge('RGBA', (*rgb.split(), a))


def fit(img: Image.Image, max_size: Tuple[int, int], multiplier: float = 1.0) -> Image.Image:
    w, h = img.size
    mw, mh = max_size
    scale = min(mw / max(w, 1), mh / max(h, 1)) * multiplier
    nw = max(1, round(w * scale))
    nh = max(1, round(h * scale))
    return img.resize((nw, nh), Image.Resampling.LANCZOS)


def apply_opacity(img: Image.Image, opacity: float) -> Image.Image:
    if opacity >= 0.999:
        return img
    out = img.copy()
    a = out.getchannel('A').point(lambda v: int(v * max(0.0, min(1.0, opacity))))
    out.putalpha(a)
    return out


def tint_flash(img: Image.Image, color: Tuple[int, int, int], strength: float) -> Image.Image:
    if strength <= 0:
        return img
    overlay = Image.new('RGBA', img.size, (*color, 0))
    alpha = img.getchannel('A').point(lambda v: int(v * min(1.0, strength)))
    overlay.putalpha(alpha)
    return Image.alpha_composite(img, overlay)


def glow_layer(mask: Image.Image, color: Tuple[int, int, int], radius: int = 8, opacity: float = 0.65) -> Image.Image:
    blur = mask.filter(ImageFilter.GaussianBlur(radius))
    blur = blur.point(lambda v: int(v * opacity))
    layer = Image.new('RGBA', mask.size, (*color, 0))
    layer.putalpha(blur)
    return layer


def radial_ripple(size: Tuple[int, int], center: Tuple[int, int], progress: float,
                  color: Tuple[int, int, int], strength: float = 1.0,
                  front: bool = False, seed: int = 0) -> Image.Image:
    w, h = size
    layer = Image.new('RGBA', size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    cx, cy = center
    rng = random.Random(seed)
    max_r = 110
    r = 14 + progress * max_r
    alpha = int(220 * max(0.0, 1.0 - progress * 0.72) * strength)
    width = max(2, int(7 - progress * 3))
    for offset, factor in [(0, 1.0), (-12, 0.45), (14, 0.28)]:
        rr = max(3, r + offset)
        box = (cx - rr, cy - rr * 0.48, cx + rr, cy + rr * 0.48)
        draw.ellipse(box, outline=(*color, int(alpha * factor)), width=max(1, width - (1 if offset else 0)))
    # Necromantic runes/particles.
    for i in range(18):
        ang = rng.random() * math.tau
        pr = r * (0.55 + rng.random() * 0.55)
        px = cx + math.cos(ang) * pr
        py = cy + math.sin(ang) * pr * 0.46
        sz = 1 + int(rng.random() * 3)
        pa = int(alpha * (0.25 + rng.random() * 0.5))
        draw.ellipse((px - sz, py - sz, px + sz, py + sz), fill=(*color, pa))
    if not front:
        layer = layer.filter(ImageFilter.GaussianBlur(2.6))
    else:
        layer = layer.filter(ImageFilter.GaussianBlur(0.7))
    return layer


def projectile_layer(size: Tuple[int, int], progress: float, direction: str,
                     color: Tuple[int, int, int]) -> Image.Image:
    w, h = size
    layer = Image.new('RGBA', size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    y0 = {'up': 86, 'front': 138, 'down': 190}[direction]
    x0 = 168
    x1 = 270
    x = x0 + (x1 - x0) * progress
    y = y0 - (18 * math.sin(progress * math.pi) if direction == 'up' else 0)
    if direction == 'down':
        y += 15 * progress
    trail = []
    for k in range(8):
        tx = x - k * 6
        ty = y + math.sin(k * 0.7) * 2
        trail.append((tx, ty))
    for k, (tx, ty) in enumerate(reversed(trail)):
        a = int(35 + k * 19)
        rr = 2 + k * 0.45
        draw.ellipse((tx - rr, ty - rr, tx + rr, ty + rr), fill=(*color, a))
    draw.ellipse((x - 7, y - 7, x + 7, y + 7), fill=(245, 220, 255, 230), outline=(*color, 255), width=2)
    return layer.filter(ImageFilter.GaussianBlur(1.3))


def slash_layer(size: Tuple[int, int], frame_index: int, direction: str,
                color: Tuple[int, int, int], upgraded: bool) -> Image.Image:
    layer = Image.new('RGBA', size, (0, 0, 0, 0))
    if frame_index not in (3, 4):
        return layer
    draw = ImageDraw.Draw(layer)
    if direction == 'up':
        pts = [(182, 142), (240, 68), (225, 151)]
    elif direction == 'down':
        pts = [(182, 154), (246, 220), (225, 147)]
    else:
        pts = [(176, 154), (268, 126), (224, 170)]
    alpha = 220 if upgraded else 140
    draw.line(pts, fill=(*color, alpha), width=7 if upgraded else 4, joint='curve')
    draw.line(pts, fill=(255, 235, 255, alpha), width=2)
    return layer.filter(ImageFilter.GaussianBlur(1.5))


def transform_pose(img: Image.Image, scale_x: float = 1.0, scale_y: float = 1.0,
                   angle: float = 0.0) -> Image.Image:
    nw = max(1, round(img.width * scale_x))
    nh = max(1, round(img.height * scale_y))
    out = img.resize((nw, nh), Image.Resampling.LANCZOS)
    if abs(angle) > 0.01:
        out = out.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
    return out.filter(ImageFilter.UnsharpMask(radius=0.8, percent=80, threshold=2))


def group_motion(group: int, i: int, count: int) -> Dict[str, float]:
    t = 0 if count <= 1 else i / (count - 1)
    phase = math.sin(t * math.tau)
    params = dict(dx=0.0, dy=0.0, sx=1.0, sy=1.0, angle=0.0, opacity=1.0, flash=0.0)
    if group == 0:
        params.update(dx=phase * 2.2, dy=-abs(math.sin(t * math.tau * 2)) * 4, sy=1.0 - abs(phase) * 0.018)
    elif group == 1:
        params.update(dy=-abs(phase) * 2, sx=1.0 + phase * 0.008, angle=phase * 0.8)
    elif group == 2:
        params.update(dy=-math.sin(t * math.tau) * 1.5, sy=1.0 + math.sin(t * math.tau) * 0.012, sx=1.0 - math.sin(t * math.tau) * 0.006)
    elif group == 3:
        params.update(dx=[0, -7, -10, -4, 0][i], dy=[0, 1, 3, 1, 0][i], angle=[0, -2, -3, -1, 0][i], flash=[0, .42, .25, .10, 0][i])
    elif group == 4:
        params.update(dx=[0, -2, -3, -2, -1, 0][i], dy=[0, 1, 2, 1, 0, 0][i], sx=[1, 1.01, 1.02, 1.02, 1.01, 1][i])
    elif group in (5, 6):
        params.update(dx=[0, -4, -8, -6, -6, -6, -6, -6][i], dy=[0, 2, 5, 0, 0, 0, 0, 0][i], flash=[0, .28, .15, 0, 0, 0, 0, 0][i])
    elif group in (7, 8):
        params.update(dy=-abs(phase) * 1.5, sx=1.0 - abs(phase) * 0.018)
    elif group in (11, 12, 13):
        attack_dx = [0, 3, 8, 17, 20, 9, 2, 0][i]
        attack_dy = {'11': -8, '12': 0, '13': 9}[str(group)] if i in (2, 3, 4) else 0
        params.update(dx=attack_dx, dy=attack_dy, sx=1.0 + (0.03 if i in (3,4) else 0), sy=0.98 if i in (3,4) else 1.0)
    elif group in (14, 15, 16, 17, 18, 19, 30, 31, 32, 40, 41, 42):
        params.update(dy=-abs(math.sin(t * math.pi)) * 2.5, sx=1.0 + math.sin(t * math.pi) * 0.015, sy=1.0 + math.sin(t * math.pi) * 0.02)
    elif group == 20:
        params.update(dx=[0, 2, 5][i], dy=[0, -1, -3][i])
    elif group == 21:
        params.update(dx=[5, 2, 0][i], dy=[-3, -1, 0][i])
    elif group == 24:
        params.update(opacity=[0.35, 0.45, 0.55, 0.67, 0.80, 0.90, 1.0, 1.0][i], dy=[8, 7, 6, 5, 4, 2, 0, 0][i])
    elif group == 50:
        params.update(opacity=max(0.03, 1.0 - t), sx=1.0 - t * 0.13, sy=1.0 + t * 0.08, dy=-t * 6)
    elif group == 51:
        params.update(opacity=max(0.03, t), sx=0.87 + t * 0.13, sy=1.08 - t * 0.08, dy=-(1.0 - t) * 6)
    return params


def make_frame(form: str, group: int, i: int, key_imgs: List[Image.Image]) -> Image.Image:
    cfg = FORMS[form]
    count = GROUP_COUNTS[group]
    pose_idx = POSE_PLANS[group][i]
    src = key_imgs[pose_idx]
    motion = group_motion(group, i, count)
    upgraded = form == 'upgrade'
    accent = cfg['accent']
    glow = cfg['glow']

    # Keep body size consistent across key poses. Cast/death sources contain extra effects or a wider corpse.
    mult = 1.0
    if pose_idx == 8:
        mult = 0.97
    if pose_idx == 10:
        mult = 0.98
    fitted = fit(src, BATTLE_BOX, mult)
    fitted = transform_pose(fitted, motion['sx'], motion['sy'], motion['angle'])
    fitted = tint_flash(fitted, (170, 25, 45), motion['flash'])
    fitted = apply_opacity(fitted, motion['opacity'])

    canvas = Image.new('RGBA', CANVAS, (0, 0, 0, 0))
    # Cast/teleport glow behind the creature.
    cast_groups = (14, 15, 16, 17, 18, 19, 30, 31, 32, 40, 41, 42, 50, 51, 24)
    if group in cast_groups:
        p = i / max(1, count - 1)
        if group in (50, 51):
            rp = p if group == 50 else (1.0 - p)
        elif group == 24:
            rp = 1.0 - p
        else:
            rp = max(0.0, min(1.0, (i - 1) / max(1, count - 3)))
        behind = radial_ripple(CANVAS, (145, 190), rp, glow, 1.2 if upgraded else 0.9, front=False, seed=group * 100 + i)
        canvas = Image.alpha_composite(canvas, behind)

    x = (CANVAS[0] - fitted.width) // 2 + round(motion['dx'])
    y = BASELINE - fitted.height + round(motion['dy'])
    canvas.alpha_composite(fitted, (x, y))

    # Attack slash / projectile and foreground ripple.
    if group in (11, 12, 13):
        direction = {11: 'up', 12: 'front', 13: 'down'}[group]
        canvas = Image.alpha_composite(canvas, slash_layer(CANVAS, i, direction, glow, upgraded))
    if group in (14, 15, 16) and i in (3, 4, 5):
        direction = {14: 'up', 15: 'front', 16: 'down'}[group]
        prog = (i - 3) / 2
        canvas = Image.alpha_composite(canvas, projectile_layer(CANVAS, prog, direction, glow))
    if group in (17, 18, 19, 30, 31, 32, 40, 41, 42):
        p = max(0.0, min(1.0, (i - 1) / max(1, count - 3)))
        strength = 1.35 if group in (40,41,42) else 1.0
        front = radial_ripple(CANVAS, (150, 192), p, glow, strength, front=True, seed=group * 1000 + i)
        canvas = Image.alpha_composite(canvas, front)
    if group in (5, 6) and i in (1, 2, 3):
        # Soul fragments leaving the corpse.
        soul = Image.new('RGBA', CANVAS, (0,0,0,0))
        d = ImageDraw.Draw(soul)
        rng = random.Random(900 + i + (100 if upgraded else 0))
        for k in range(14):
            px = 115 + rng.randint(-35, 45)
            py = 130 - i * 7 + rng.randint(-20, 20)
            rr = rng.randint(1,3)
            d.ellipse((px-rr,py-rr,px+rr,py+rr), fill=(*glow, 80+rng.randint(0,130)))
        soul = soul.filter(ImageFilter.GaussianBlur(1.2))
        canvas = Image.alpha_composite(canvas, soul)
    return canvas


def save_animation_json(path: Path, basepath: str) -> None:
    sequences = []
    for group, count in GROUP_COUNTS.items():
        sequences.append({
            'group': group,
            'frames': [f'g{group:02d}_{i:02d}.png' for i in range(count)],
            'generateShadow': 1,
            'generateOverlay': 1,
        })
    path.write_text(json.dumps({'basepath': basepath, 'sequences': sequences}, indent=2) + '\n', encoding='utf-8')


def make_map_frames(form: str, battle_dir: Path, map_dir: Path) -> None:
    map_dir.mkdir(parents=True, exist_ok=True)
    for i in range(8):
        src = Image.open(battle_dir / f'g00_{i:02d}.png').convert('RGBA')
        box = alpha_bbox(src)
        src = src.crop(box)
        src = fit(src, MAP_BOX)
        canvas = Image.new('RGBA', MAP_CANVAS, (0,0,0,0))
        x = (MAP_CANVAS[0]-src.width)//2
        y = MAP_CANVAS[1]-src.height-5-int(abs(math.sin(i/8*math.tau))*2)
        canvas.alpha_composite(src, (x,y))
        canvas.save(map_dir / f'map_{i:02d}.png', optimize=True)
    anim = {
        'basepath': f"sepulchral/{FORMS[form]['slug']}/map",
        'sequences': [{'group': 0, 'frames': [f'map_{i:02d}.png' for i in range(8)], 'generateShadow': 2, 'generateOverlay': 1}]
    }
    (map_dir / 'animation.json').write_text(json.dumps(anim, indent=2) + '\n', encoding='utf-8')


def crop_art(board: Image.Image, box: Tuple[int,int,int,int], size: Tuple[int,int]) -> Image.Image:
    crop = board.crop(box).convert('RGB')
    # Center-crop to output aspect ratio.
    target_aspect = size[0] / size[1]
    w, h = crop.size
    aspect = w / h
    if aspect > target_aspect:
        nw = int(h * target_aspect)
        left = max(0, (w - nw) // 2)
        crop = crop.crop((left, 0, left + nw, h))
    else:
        nh = int(w / target_aspect)
        top = max(0, (h - nh) // 2)
        crop = crop.crop((0, top, w, top + nh))
    crop = crop.resize(size, Image.Resampling.LANCZOS)
    crop = ImageEnhance.Contrast(crop).enhance(1.06)
    crop = ImageEnhance.Color(crop).enhance(1.06)
    crop = crop.filter(ImageFilter.UnsharpMask(radius=1.2, percent=115, threshold=3))
    return crop.convert('RGBA')


def add_gold_frame(img: Image.Image, width: int = 3) -> Image.Image:
    out = img.copy()
    d = ImageDraw.Draw(out)
    for i in range(width):
        col = (218 - i*22, 166 - i*12, 69 - i*5, 255)
        d.rectangle((i, i, out.width-1-i, out.height-1-i), outline=col)
    return out


def create_portraits_and_icons(board: Image.Image, form: str, data_dir: Path, battle_dir: Path) -> None:
    cfg = FORMS[form]
    data_dir.mkdir(parents=True, exist_ok=True)
    portrait = add_gold_frame(crop_art(board, cfg['portrait_box'], (232,256)), 3)
    portrait.save(data_dir / 'portrait_232x256.png', optimize=True)
    large = add_gold_frame(crop_art(board, cfg['portrait_box'], (58,64)), 2)
    large.save(data_dir / 'icon_large.png', optimize=True)
    small = crop_art(board, cfg['portrait_box'], (32,32))
    small = add_gold_frame(small, 1)
    small.save(data_dir / 'icon_small.png', optimize=True)

    # Map attack images use the actual horizontal attack frame, not concept thumbnails.
    attack = Image.open(battle_dir / 'g12_04.png').convert('RGBA')
    attack_crop = attack.crop(alpha_bbox(attack))
    right = fit(attack_crop, (94,90))
    c = Image.new('RGBA', (96,96), (0,0,0,0))
    c.alpha_composite(right, ((96-right.width)//2, 96-right.height-2))
    c.save(data_dir / 'map_attack_right.png', optimize=True)
    left = ImageOps.mirror(c)
    left.save(data_dir / 'map_attack_left.png', optimize=True)


def create_ability_icon() -> None:
    shared = ROOT / 'Content/data/sepulchral/shared'
    shared.mkdir(parents=True, exist_ok=True)
    source = Image.open(OLD_CONCEPT).convert('RGB')
    # Original concept's Death Ripple icon panel.
    crop = source.crop((1020, 50, 1138, 166))
    crop = ImageOps.fit(crop, (128,128), method=Image.Resampling.LANCZOS)
    crop = ImageEnhance.Contrast(crop).enhance(1.08)
    crop = ImageEnhance.Color(crop).enhance(1.10)
    base = add_gold_frame(crop.convert('RGBA'), 3)
    for size in (128,64,32):
        icon = base.resize((size,size), Image.Resampling.LANCZOS)
        icon.save(shared / f'funerary_reprise_{size}.png', optimize=True)


def create_effect_frames() -> None:
    effect_dir = ROOT / 'Content/sprites/sepulchral/effects/funerary_reprise'
    if effect_dir.exists():
        for p in effect_dir.glob('effect_*.png'):
            p.unlink()
    effect_dir.mkdir(parents=True, exist_ok=True)
    for i in range(16):
        p = i / 15
        canvas = Image.new('RGBA', (256,256), (0,0,0,0))
        back = radial_ripple((256,256),(128,132),p,(177,66,255),1.55,False,seed=4000+i)
        front = radial_ripple((256,256),(128,132),p,(225,145,255),1.25,True,seed=5000+i)
        canvas = Image.alpha_composite(canvas, back)
        # Central skull-like light using concentric shapes.
        d = ImageDraw.Draw(canvas)
        a = int(220 * max(0, 1-p*0.65))
        head_r = max(3, int(21 - p*10))
        d.ellipse((128-head_r,105-head_r,128+head_r,105+head_r), fill=(230,190,255,a), outline=(126,45,200,a), width=2)
        d.ellipse((120,101,124,106), fill=(35,0,50,a))
        d.ellipse((132,101,136,106), fill=(35,0,50,a))
        d.polygon([(124,111),(128,116),(132,111)], fill=(35,0,50,a))
        canvas = Image.alpha_composite(canvas, front)
        canvas.save(effect_dir / f'effect_{i:02d}.png', optimize=True)
    anim = {
        'basepath': 'sepulchral/effects/funerary_reprise',
        'sequences': [{'group':0,'frames':[f'effect_{i:02d}.png' for i in range(16)]}]
    }
    (effect_dir / 'animation.json').write_text(json.dumps(anim, indent=2) + '\n', encoding='utf-8')


def make_gif(frames: List[Image.Image], path: Path, duration: int = 110) -> None:
    # GIF needs a matte for compatibility; checkerboard previews remain separate.
    matte_frames = []
    for fr in frames:
        bg = Image.new('RGBA', fr.size, (16,14,25,255))
        bg.alpha_composite(fr)
        matte_frames.append(bg.convert('P', palette=Image.Palette.ADAPTIVE, colors=255))
    matte_frames[0].save(path, save_all=True, append_images=matte_frames[1:], loop=0, duration=duration, disposal=2, optimize=False)


def checkerboard(size: Tuple[int,int], cell: int = 12) -> Image.Image:
    w,h=size
    bg=Image.new('RGBA',size,(0,0,0,255))
    d=ImageDraw.Draw(bg)
    for y in range(0,h,cell):
        for x in range(0,w,cell):
            c=(64,64,72,255) if ((x//cell+y//cell)%2==0) else (92,92,102,255)
            d.rectangle((x,y,x+cell-1,y+cell-1),fill=c)
    return bg


def create_preview() -> None:
    W,H=1800,1320
    img=Image.new('RGB',(W,H),(11,11,18))
    d=ImageDraw.Draw(img)
    gold=(223,175,78)
    pale=(235,225,206)
    purple=(184,92,255)
    d.text((45,24),'SEPULCHRAL LAMASSU v2.1',font=font(54,True),fill=gold)
    d.text((48,88),'Actual files contained in the VCMI ZIP — no placeholder geometry',font=font(24),fill=pale)

    # Portraits.
    for col, form in enumerate(('base','upgrade')):
        x=45+col*880
        data_dir=ROOT/'Content/data/sepulchral'/FORMS[form]['slug']
        portrait=Image.open(data_dir/'portrait_232x256.png').convert('RGB').resize((348,384),Image.Resampling.LANCZOS)
        img.paste(portrait,(x,145))
        d.text((x+380,150),FORMS[form]['title'],font=font(34,True),fill=gold)
        d.text((x+380,205),'Neutral • Undead • Tier 7',font=font(22),fill=pale)
        desc='Base funerary guardian\nblack stone, gold burial armour\nruined wings, violet soul-light' if form=='base' else 'Upgraded cursed guardian\ncrimson-violet fractures\nstronger necromantic discharge'
        d.multiline_text((x+380,250),desc,font=font(20),fill=(210,205,220),spacing=10)
        icon=Image.open(data_dir/'icon_large.png').convert('RGBA').resize((116,128),Image.Resampling.NEAREST)
        img.paste(icon,(x+380,390),icon)
        mapf=Image.open(ROOT/'Content/sprites/sepulchral'/FORMS[form]['slug']/'map/map_03.png').convert('RGBA').resize((144,144),Image.Resampling.NEAREST)
        img.paste(mapf,(x+520,378),mapf)

    # Keyframes actual PNGs.
    names=[('Idle',2,0),('Walk',0,2),('Attack',12,4),('Defend',4,2),('Hit',3,1),('Cast',31,3),('Death',5,6)]
    y0=585
    for row,form in enumerate(('base','upgrade')):
        battle=ROOT/'Content/sprites/sepulchral'/FORMS[form]['slug']/'battle'
        d.text((45,y0+row*285),FORMS[form]['title']+' — actual battle frames',font=font(28,True),fill=gold)
        for j,(label,g,idx) in enumerate(names):
            frame=Image.open(battle/f'g{g:02d}_{idx:02d}.png').convert('RGBA')
            # native frame on checker, plus enlarged nearest-neighbour beside it.
            box=frame.crop(alpha_bbox(frame))
            box=fit(box,(178,170))
            cell=checkerboard((210,205),14)
            cell.alpha_composite(box,((210-box.width)//2,198-box.height))
            x=45+j*246
            img.paste(cell.convert('RGB'),(x,y0+42+row*285))
            d.text((x+6,y0+250+row*285),label,font=font(19,True),fill=pale)

    # Ability/effect row.
    icon=Image.open(ROOT/'Content/data/sepulchral/shared/funerary_reprise_128.png').convert('RGBA').resize((160,160),Image.Resampling.NEAREST)
    img.paste(icon,(45,1160),icon)
    d.text((230,1164),'Funerary Reprisal',font=font(30,True),fill=gold)
    d.text((230,1210),'Once per round, a surviving melee hit casts Death Ripple instead of a normal retaliation.',font=font(20),fill=pale)
    eff=Image.open(ROOT/'Content/sprites/sepulchral/effects/funerary_reprise/effect_10.png').convert('RGBA').resize((160,160),Image.Resampling.LANCZOS)
    img.paste(eff,(1560,1150),eff)
    img.save(OUT_PREVIEW,quality=95)
    shutil.copy2(OUT_PREVIEW, ROOT/'preview/Actual_Assets_Preview_v2.png')


def update_lua() -> None:
    script = r'''local Base = require("combat/combatScript")

local Script = setmetatable({}, {__index = Base})
Script.__index = Script

local COOLDOWN_STACKING = "sepulchral-lamassu:funeraryReprisalUsed"
local COOLDOWN_SOURCE = "sepulchral-lamassu:funeraryReprisal"

function Script:cooldownBonuses(unit)
    return unit:getBonuses({}):filter(function(bonus)
        return bonus:getStacking() == COOLDOWN_STACKING
    end)
end

function Script:isSpent(unit)
    return self:cooldownBonuses(unit):size() > 0
end

function Script:clearCooldown(server, battle, unit)
    local bonuses = self:cooldownBonuses(unit)
    if bonuses:size() > 0 then
        server:removeUnitBonuses(battle, unit, bonuses)
    end
end

function Script:isFamilyUnit(unit)
    if not unit then return false end
    local key = unit:getCreature():getJsonKey()
    for _, familyKey in ipairs(self.family or {}) do
        if key == familyKey then return true end
    end
    return false
end

function Script:markArmyFamilySpent(server, battle, unit)
    local side = unit:getSide()
    local familyUnits = battle:getUnitsIf(function(candidate)
        return candidate:isAlive()
            and candidate:getSide() == side
            and self:isFamilyUnit(candidate)
    end)

    for _, candidate in ipairs(familyUnits) do
        server:addUnitBonus(battle, candidate, {
            type = "NONE",
            val = 0,
            duration = ENUM.BonusDuration.oneBattle,
            sourceType = ENUM.BonusSource.other,
            sourceID = COOLDOWN_SOURCE,
            stacking = COOLDOWN_STACKING,
            hidden = true
        }, false)
    end
end

function Script:onBattleStart(server, battle, unit)
    self:clearCooldown(server, battle, unit)
end

function Script:onRoundStart(server, battle, unit)
    self:clearCooldown(server, battle, unit)
end

function Script:onAfterAttacked(server, battle, unit, other, payload)
    -- The guardian must survive the blow, just as an ordinary retaliation requires a survivor.
    if not unit:isAlive() then return end
    if not other then return end

    -- Direct melee attacks only. Shots never trigger it.
    if payload.ranged then return end

    -- Do not trigger when the Lamassu attacked first and is receiving a retaliation / first strike.
    if self.activeAttacksOnly ~= false and payload.isCounter then return end

    if self:isSpent(unit) then return end

    local spell = LIBRARY:getSpellByName(self.spell or "core:deathRipple")
    if not spell then return end

    -- Hand every living battlefield unit to the spell. castSpell applies Death Ripple's own
    -- immunity rules, so undead, golems and other non-living units are filtered by the engine.
    local targets = battle:getUnitsIf(function(candidate)
        return candidate:isAlive()
    end)

    if #targets == 0 then return end

    local damage = (self.val or 0) + unit:getCount() * (self.perCreature or 0)
    damage = math.max(1, math.min(damage, self.maxDamage or damage))

    self:markArmyFamilySpent(server, battle, unit)
    server:castSpell(battle, unit, spell, targets, damage)
end

return Script
'''
    p=ROOT/'Content/scripts/sepulchral/funeraryReprisal.lua'
    p.write_text(script,encoding='utf-8')


def update_configs() -> None:
    mod_path=ROOT/'mod.json'
    mod=json.loads(mod_path.read_text(encoding='utf-8'))
    mod['version']='2.1.0'
    mod['description']='Adds the neutral Tier 7 Sepulchral Lamassu and Abyssal Lamassu with production-quality rendered sprite keyframes, complete VCMI animation groups, portraits, map art, sounds, and Funerary Reprisal: a once-per-round army-shared Death Ripple response to surviving active melee attacks.'
    mod['changelog']={
        '2.1.0':[
            'Replaced every prototype geometric creature image with high-detail rendered Lamassu artwork.',
            'Rebuilt 434 battle frames from consistent rendered key poses, including cast, hit, death and resurrection.',
            'Replaced portraits, icons, map sprites, map attacks and Funerary Reprisal effect art.',
            'Updated the Lua combat script to the current VCMI Unit API: getBonuses({}), BonusList:filter and getSide().',
            'Added previews generated only from the actual PNG files included in this archive.'
        ],
        '1.0.0':['Initial prototype release; visual assets superseded by 2.0.0.']
    }
    mod_path.write_text(json.dumps(mod,indent=2)+"\n",encoding='utf-8')

    creatures_path=ROOT/'Content/config/sepulchral/creatures.json'
    creatures=json.loads(creatures_path.read_text(encoding='utf-8'))
    for key in ('sepulchralLamassu','abyssalLamassu'):
        ability=creatures[key]['abilities']['funeraryReprisal']
        ability['icon']='sepulchral/shared/funerary_reprise_64.png'
        ability['description']='{Funerary Reprisal}\nOnce per round for this army, the first Lamassu stack that survives an enemy active melee hit casts Death Ripple instead of retaliating. The wave affects all living stacks on both sides.'
    creatures_path.write_text(json.dumps(creatures,indent=2)+"\n",encoding='utf-8')


def update_docs() -> None:
    readme = '''# Sepulchral Lamassu — VCMI Mod 2.1.0

This replaces the rejected 1.0 prototype visuals. Every creature PNG in 2.0 is built from the rendered Lamassu key poses stored under `source/v2_keyframes`; the old geometric placeholder renderer is not included.

## Install

1. Close VCMI Launcher, VCMI Map Editor and the game.
2. Delete the previous folder if present:
   `%USERPROFILE%\\Documents\\My Games\\vcmi\\Mods\\sepulchral-lamassu`
3. Extract the `sepulchral-lamassu` folder from the ZIP into:
   `%USERPROFILE%\\Documents\\My Games\\vcmi\\Mods\\`
4. Confirm this exists:
   `%USERPROFILE%\\Documents\\My Games\\vcmi\\Mods\\sepulchral-lamassu\\mod.json`
5. Open VCMI Launcher and enable **Sepulchral Lamassu**.

## Engine requirement

VCMI 1.8.0 or newer is required for the combat-event Lua ability.

## Visual contents

- 434 rendered battle frames across two creatures.
- All 31 standard VCMI creature animation groups.
- 16 adventure-map frames.
- New portraits, army icons and map-attack images.
- 16-frame Funerary Reprisal effect.
- Preview images and GIFs made from the same PNG files that the game loads.

## Mechanic

A Lamassu has no normal retaliation. Once per round per army, the first Lamassu stack that survives an enemy active melee hit casts Death Ripple. Ranged attacks, spells, and retaliation received after the Lamassu's own attack do not trigger it. The cooldown is shared by base and upgraded stacks to prevent split-stack abuse.

A live VCMI launch is still the final runtime check because this build environment does not contain the proprietary Heroes III data files.
'''
    (ROOT/'README_FIRST.md').write_text(readme,encoding='utf-8')
    art = '''# V2 art pipeline

The 2.0 release does not use the primitive geometry generator from version 1.0.

1. High-detail creature key poses are stored as transparent PNGs under `source/v2_keyframes`.
2. `tools/rebuild_v2_assets.py` aligns those poses on one battle canvas and creates motion sequences without replacing the creature with simplified shapes.
3. The actual game sprites preserve the rendered anatomy, armour, wings, face and necromantic lighting of those sources.
4. `preview/Actual_Assets_Preview_v2.png` is assembled directly from packaged battle PNGs.

The key poses are original AI-assisted artwork created for this mod. No Heroes VII, Pinterest, WoG, HotA or Discord sprite files are redistributed.
'''
    (ROOT/'source/ART_PIPELINE_V2.md').write_text(art,encoding='utf-8')
    # Replace old source README language.
    (ROOT/'source/README.txt').write_text('Version 2 source material. See ART_PIPELINE_V2.md. The old procedural placeholder renderer was removed.\n',encoding='utf-8')


def copy_sources_and_tool() -> None:
    src_dir=ROOT/'source/v2_keyframes'
    if src_dir.exists(): shutil.rmtree(src_dir)
    src_dir.mkdir(parents=True)
    for form,cfg in FORMS.items():
        for p in cfg['keys']:
            shutil.copy2(p,src_dir/p.name)
    shutil.copy2(NEW_BOARD,ROOT/'source/generated_v2_design_board.png')
    # Copy the exact builder into the mod, but rewrite fixed paths to relative CLI inputs is unnecessary for inspection.
    tool=ROOT/'tools/rebuild_v2_assets.py'
    shutil.copy2(Path(__file__),tool)
    old=ROOT/'tools/build_sepulchral_lamassu_mod.py'
    if old.exists(): old.unlink()


def validate() -> str:
    errors=[]
    json_files=list(ROOT.rglob('*.json'))
    for p in json_files:
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'JSON {p.relative_to(ROOT)}: {e}')
    expected_groups=set(GROUP_COUNTS)
    total_frames=0
    for form,cfg in FORMS.items():
        battle=ROOT/'Content/sprites/sepulchral'/cfg['slug']/'battle'
        anim=json.loads((battle/'animation.json').read_text(encoding='utf-8'))
        groups={s['group'] for s in anim['sequences']}
        if groups!=expected_groups:
            errors.append(f'{form}: animation groups mismatch')
        for g,count in GROUP_COUNTS.items():
            for i in range(count):
                p=battle/f'g{g:02d}_{i:02d}.png'
                if not p.exists(): errors.append(f'missing {p.relative_to(ROOT)}'); continue
                im=Image.open(p).convert('RGBA')
                if im.size!=CANVAS: errors.append(f'wrong size {p.relative_to(ROOT)} {im.size}')
                if im.getchannel('A').getbbox() is None: errors.append(f'empty alpha {p.relative_to(ROOT)}')
                total_frames+=1
        map_dir=ROOT/'Content/sprites/sepulchral'/cfg['slug']/'map'
        for i in range(8):
            p=map_dir/f'map_{i:02d}.png'
            if not p.exists(): errors.append(f'missing map {p.relative_to(ROOT)}')
    for p in ROOT.rglob('*.wav'):
        if p.stat().st_size<1000: errors.append(f'suspicious WAV {p.relative_to(ROOT)}')
    lua=(ROOT/'Content/scripts/sepulchral/funeraryReprisal.lua').read_text(encoding='utf-8')
    for required in ['getBonuses({})', ':filter(', 'getSide()', 'server:castSpell', 'onAfterAttacked', 'onRoundStart']:
        if required not in lua: errors.append(f'Lua missing {required}')
    forbidden=['unitSide()', 'getBonuses(function']
    for bad in forbidden:
        if bad in lua: errors.append(f'Lua contains obsolete call {bad}')
    if errors:
        raise RuntimeError('\n'.join(errors))
    return f'PASSED: {len(json_files)} JSON files; {total_frames} battle PNG frames; 16 map frames; Lua API checks; sound presence.'


def write_manifest_and_qa(validation: str) -> None:
    manifest=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.name!='MANIFEST_SHA256.txt':
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            manifest.append(f'{h}  {p.relative_to(ROOT).as_posix()}')
    (ROOT/'MANIFEST_SHA256.txt').write_text('\n'.join(manifest)+'\n',encoding='utf-8')
    qa=f'''Sepulchral Lamassu VCMI 2.1.0 — Static QA Report
==================================================

{validation}

Visual replacement
------------------
- All version-1 geometric battle and map images were deleted and regenerated.
- Source key poses: 22 transparent high-detail rendered PNGs.
- Battle frames: 434, all 280x260 RGBA with non-empty alpha.
- Map frames: 16, all 96x96 RGBA.
- Preview is assembled from the same packaged PNGs loaded by VCMI.

Mechanic update
---------------
- COMBAT_EVENT_TRIGGER retained.
- Updated obsolete Unit API calls to current documented forms:
  getBonuses({{}}):filter(...) and getSide().
- Death Ripple targets all alive units; core spell immunity filtering excludes non-living targets.
- Shared once-per-round marker remains applied to all living base/upgraded Lamassu stacks on the same side.

Not performed here
------------------
- Live VCMI client/server launch, because this environment has no licensed Heroes III data installation.
'''
    (ROOT/'QA_REPORT.txt').write_text(qa,encoding='utf-8')
    OUT_QA.write_text(qa,encoding='utf-8')


def zip_mod() -> str:
    if OUT_ZIP.exists(): OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file():
                z.write(p,arcname=f'{ROOT.name}/{p.relative_to(ROOT).as_posix()}')
    with zipfile.ZipFile(OUT_ZIP) as z:
        bad=z.testzip()
        if bad: raise RuntimeError(f'ZIP integrity failed at {bad}')
        tops={n.split('/')[0] for n in z.namelist() if n}
        if tops!={ROOT.name}: raise RuntimeError(f'ZIP top folders: {tops}')
    digest=hashlib.sha256(OUT_ZIP.read_bytes()).hexdigest()
    OUT_CHECKSUM.write_text(f'{digest}  {OUT_ZIP.name}\n',encoding='utf-8')
    return digest


def main() -> None:
    if not ROOT.exists(): raise SystemExit(f'Missing mod root: {ROOT}')
    for form,cfg in FORMS.items():
        for p in cfg['keys']:
            if not p.exists(): raise SystemExit(f'Missing source key: {p}')
    if not NEW_BOARD.exists(): raise SystemExit(f'Missing board: {NEW_BOARD}')

    board=Image.open(NEW_BOARD).convert('RGB')
    copy_sources_and_tool()
    update_lua()
    update_configs()
    update_docs()
    create_ability_icon()
    create_effect_frames()

    preview_dir=ROOT/'preview'
    preview_dir.mkdir(exist_ok=True)
    # Remove old preview that demonstrated rejected geometry.
    old_preview=preview_dir/'Actual_Assets_Preview.png'
    if old_preview.exists(): old_preview.unlink()

    for form,cfg in FORMS.items():
        battle_dir=ROOT/'Content/sprites/sepulchral'/cfg['slug']/'battle'
        if battle_dir.exists():
            for p in battle_dir.glob('g*.png'): p.unlink()
        battle_dir.mkdir(parents=True,exist_ok=True)
        key_imgs=[clean_key(Image.open(p)) for p in cfg['keys']]
        for group,count in GROUP_COUNTS.items():
            frames=[]
            for i in range(count):
                fr=make_frame(form,group,i,key_imgs)
                fr.save(battle_dir/f'g{group:02d}_{i:02d}.png',optimize=True)
                frames.append(fr)
        save_animation_json(battle_dir/'animation.json',f"sepulchral/{cfg['slug']}/battle")
        map_dir=ROOT/'Content/sprites/sepulchral'/cfg['slug']/'map'
        if map_dir.exists():
            for p in map_dir.glob('map_*.png'): p.unlink()
        make_map_frames(form,battle_dir,map_dir)
        data_dir=ROOT/'Content/data/sepulchral'/cfg['slug']
        create_portraits_and_icons(board,form,data_dir,battle_dir)

        # Actual animation GIFs.
        for label,group in [('idle',2),('walk',0),('attack',12),('cast',31),('death',5)]:
            gif_frames=[Image.open(battle_dir/f'g{group:02d}_{i:02d}.png').convert('RGBA') for i in range(GROUP_COUNTS[group])]
            make_gif(gif_frames,preview_dir/f"{cfg['slug']}_{label}.gif")

    create_preview()
    validation=validate()
    write_manifest_and_qa(validation)
    digest=zip_mod()
    print(validation)
    print(f'ZIP: {OUT_ZIP} ({OUT_ZIP.stat().st_size} bytes)')
    print(f'SHA256: {digest}')
    print(f'Preview: {OUT_PREVIEW}')

if __name__=='__main__':
    main()
