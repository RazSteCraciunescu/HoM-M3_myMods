# V2 art pipeline

The 2.0 release does not use the primitive geometry generator from version 1.0.

1. High-detail creature key poses are stored as transparent PNGs under `source/v2_keyframes`.
2. `tools/rebuild_v2_assets.py` aligns those poses on one battle canvas and creates motion sequences without replacing the creature with simplified shapes.
3. The actual game sprites preserve the rendered anatomy, armour, wings, face and necromantic lighting of those sources.
4. `preview/Actual_Assets_Preview_v2.png` is assembled directly from packaged battle PNGs.

The key poses are original AI-assisted artwork created for this mod. No Heroes VII, Pinterest, WoG, HotA or Discord sprite files are redistributed.
