Version 2 source material. See ART_PIPELINE_V2.md. The old procedural placeholder renderer was removed.
