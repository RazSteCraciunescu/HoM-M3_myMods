local Base = require("combat/combatScript")

local Script = setmetatable({}, {__index = Base})
Script.__index = Script

local COOLDOWN_STACKING = "sepulchral-lamassu:funeraryReprisalUsed"
local COOLDOWN_SOURCE = "sepulchral-lamassu:funeraryReprisal"

function Script:cooldownBonuses(unit)
    return unit:getBonuses({}):filter(function(bonus)
        return bonus:getStacking() == COOLDOWN_STACKING
    end)
end

function Script:isSpent(unit)
    return self:cooldownBonuses(unit):size() > 0
end

function Script:clearCooldown(server, battle, unit)
    local bonuses = self:cooldownBonuses(unit)
    if bonuses:size() > 0 then
        server:removeUnitBonuses(battle, unit, bonuses)
    end
end

function Script:isFamilyUnit(unit)
    if not unit then return false end
    local key = unit:getCreature():getJsonKey()
    for _, familyKey in ipairs(self.family or {}) do
        if key == familyKey then return true end
    end
    return false
end

function Script:markArmyFamilySpent(server, battle, unit)
    local side = unit:getSide()
    local familyUnits = battle:getUnitsIf(function(candidate)
        return candidate:isAlive()
            and candidate:getSide() == side
            and self:isFamilyUnit(candidate)
    end)

    for _, candidate in ipairs(familyUnits) do
        server:addUnitBonus(battle, candidate, {
            type = "NONE",
            val = 0,
            duration = ENUM.BonusDuration.oneBattle,
            sourceType = ENUM.BonusSource.other,
            sourceID = COOLDOWN_SOURCE,
            stacking = COOLDOWN_STACKING,
            hidden = true
        }, false)
    end
end

function Script:onBattleStart(server, battle, unit)
    self:clearCooldown(server, battle, unit)
end

function Script:onRoundStart(server, battle, unit)
    self:clearCooldown(server, battle, unit)
end

function Script:onAfterAttacked(server, battle, unit, other, payload)
    -- The guardian must survive the blow, just as an ordinary retaliation requires a survivor.
    if not unit:isAlive() then return end
    if not other then return end

    -- Direct melee attacks only. Shots never trigger it.
    if payload.ranged then return end

    -- Do not trigger when the Lamassu attacked first and is receiving a retaliation / first strike.
    if self.activeAttacksOnly ~= false and payload.isCounter then return end

    if self:isSpent(unit) then return end

    local spell = LIBRARY:getSpellByName(self.spell or "core:deathRipple")
    if not spell then return end

    -- Hand every living battlefield unit to the spell. castSpell applies Death Ripple's own
    -- immunity rules, so undead, golems and other non-living units are filtered by the engine.
    local targets = battle:getUnitsIf(function(candidate)
        return candidate:isAlive()
    end)

    if #targets == 0 then return end

    local damage = (self.val or 0) + unit:getCount() * (self.perCreature or 0)
    damage = math.max(1, math.min(damage, self.maxDamage or damage))

    self:markArmyFamilySpent(server, battle, unit)
    server:castSpell(battle, unit, spell, targets, damage)
end

return Script
