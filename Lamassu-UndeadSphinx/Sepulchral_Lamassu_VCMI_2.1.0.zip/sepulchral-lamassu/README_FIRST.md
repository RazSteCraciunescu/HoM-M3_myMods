# Sepulchral Lamassu — VCMI Mod 2.1.0

This replaces the rejected 1.0 prototype visuals. Every creature PNG in 2.0 is built from the rendered Lamassu key poses stored under `source/v2_keyframes`; the old geometric placeholder renderer is not included.

## Install

1. Close VCMI Launcher, VCMI Map Editor and the game.
2. Delete the previous folder if present:
   `%USERPROFILE%\Documents\My Games\vcmi\Mods\sepulchral-lamassu`
3. Extract the `sepulchral-lamassu` folder from the ZIP into:
   `%USERPROFILE%\Documents\My Games\vcmi\Mods\`
4. Confirm this exists:
   `%USERPROFILE%\Documents\My Games\vcmi\Mods\sepulchral-lamassu\mod.json`
5. Open VCMI Launcher and enable **Sepulchral Lamassu**.

## Engine requirement

VCMI 1.8.0 or newer is required for the combat-event Lua ability.

## Visual contents

- 434 rendered battle frames across two creatures.
- All 31 standard VCMI creature animation groups.
- 16 adventure-map frames.
- New portraits, army icons and map-attack images.
- 16-frame Funerary Reprisal effect.
- Preview images and GIFs made from the same PNG files that the game loads.

## Mechanic

A Lamassu has no normal retaliation. Once per round per army, the first Lamassu stack that survives an enemy active melee hit casts Death Ripple. Ranged attacks, spells, and retaliation received after the Lamassu's own attack do not trigger it. The cooldown is shared by base and upgraded stacks to prevent split-stack abuse.

A live VCMI launch is still the final runtime check because this build environment does not contain the proprietary Heroes III data files.
