# Live VCMI test checklist

Test every clone in a tiny disposable map before creating final art.

## Editor and adventure map

- Both creatures appear with a list icon.
- Dragging each creature to the map shows a real sprite, not the missing-resource prohibition sign.
- Map idle is calm and does not pulse in size.
- Map sprite is not oversized compared with classic creatures.
- Both dwellings appear, are visitable and show opaque interiors.

## UI

- `iconSmall` is transparent and focuses on head/chest.
- `iconLarge` has the correct faction/town-style background.
- No presentation text, Roman numerals or labels are baked into icons.
- Recruitment/stat preview shows the whole creature, with feet near the bottom and head visible.

## Battle

- Base art faces right; defender is mirrored by the engine.
- Feet overlap the occupied hex rather than appearing one hex north-east.
- Idle silhouette stays the same size.
- Walk moves limbs; attack has a readable lunge; defend, hit and death are distinct.
- Corpse remains inside the canvas.
- Hover/fidget is not spasmically fast.

## Audio

- Attack, defend, hit, death and movement sounds play without clipping.

## Final release rule

Generate a contact sheet from the actual packaged PNGs. Never approve a mod only from concept art or a promotional poster.
