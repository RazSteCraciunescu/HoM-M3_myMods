# Future town integration

The two map dwellings are intentionally separate from any town. Their art, names and creature links can later be reused as town-building references.

Keep town-screen building art separate from adventure-map dwelling art. Town screens use different perspective, scale, masks, construction states and clickable areas.
