# Optional VCMI 1.8+ Lua mechanics

The installed template intentionally has no custom Lua dependency and therefore targets VCMI 1.7.5 or newer.

Use VCMI 1.8 development builds when you add target-dependent or event-driven mechanics such as:

- after-attack transmutation with same-tier checks;
- once-per-round reactions;
- custom battlefield state;
- multi-condition spell casting;
- exact health-preserving stack replacement.

Register a combat-event script in `mod.json` through a scripts config, then attach it with `COMBAT_EVENT_TRIGGER`.
Start from the official documentation rather than copying a mechanic blindly:

- https://vcmi.eu/modders/Lua/Combat_Event_Scripts/
- https://vcmi.eu/modders/Lua/API_Reference/
- https://vcmi.eu/modders/Lua_Reference/BattleServer/
- https://vcmi.eu/modders/Lua_Reference/Unit/

A copy-ready inactive skeleton is available in `examples/lua-1.8/`.
