# Inactive VCMI 1.8 combat-event skeleton

These files are examples only. They are deliberately outside `Content` and are not loaded by the template.

Use them for event-driven mechanics that cannot be expressed by normal creature bonuses, such as:

- an after-attack transmutation;
- a once-per-round reaction;
- conditional spell or damage logic;
- exact stack replacement while preserving current health.

Activation sequence:

1. Copy `emptyCombatReaction.lua` to `Content/scripts/<resource-root>/`.
2. Convert `scripts.jsonc` to strict JSON under `Content/config/<resource-root>/scripts.json`.
3. Add that scripts file to `mod.json` under `scripts`.
4. Copy the ability entry from `ability.jsonc` into the creature.
5. Replace all `YOUR_MOD`, `yourResourceRoot` and script identifiers.
6. Raise `compatibility.min` to the VCMI development version you actually test.
7. Implement only server-synchronized changes through supported battle APIs.
8. Test attacker/defender sides, retaliation, ranged attacks, summons, clones, save/load and multiplayer.

Official references are listed in `../ADVANCED_LUA_1_8_README.md`.
