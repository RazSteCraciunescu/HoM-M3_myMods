local Base = require("combat/combatScript")

local Script = setmetatable({}, { __index = Base })
Script.__index = Script

-- Inactive starting point for VCMI 1.8 development builds.
-- The parameters in this table come from the COMBAT_EVENT_TRIGGER bonus.
-- Do not mutate local unit tables and assume the game changed. Use supported
-- BattleServer methods so the result is synchronized and serializable.

function Script:onAfterAttacked(server, battle, unit, attacker, payload)
    -- Example safety gates. Keep or remove them according to the mechanic.
    if not unit or not unit:isAlive() then return end
    if not attacker or not attacker:isAlive() then return end
    if payload and payload.ranged then return end
    if payload and payload.isCounter then return end

    -- Add the mechanic here. Examples from prior live-tested work used:
    -- server:rollCombatAbility(...)
    -- server:castSpell(...)
    -- server:removeUnit(...)
    -- server:addUnit(...)
    -- server:damageUnit(...)
    -- server:refreshBattleUnits(...)
    -- server:showBattleAnimation(...)
end

function Script:onRoundStart(server, battle, round)
    -- Optional place to clear/reset a once-per-round state.
    -- Store persistent state only through a synchronized mechanism supported
    -- by the VCMI build you are targeting.
end

return Script
