@echo off
setlocal
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% "%~dp0tools\make_contact_sheet.py"
if errorlevel 1 (
  echo.
  echo Preview generation failed. Run SETUP_TEMPLATE_TOOLS.cmd first.
)
pause
