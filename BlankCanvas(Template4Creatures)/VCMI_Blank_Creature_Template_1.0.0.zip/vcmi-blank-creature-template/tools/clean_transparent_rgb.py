#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("Pillow is required. Run SETUP_TEMPLATE_TOOLS.cmd first.")
    raise SystemExit(2)

ROOT = Path(__file__).resolve().parents[1]
changed = 0
pixels_changed = 0

for path in (ROOT / "Content").rglob("*.png"):
    image = Image.open(path).convert("RGBA")
    data = list(image.getdata())
    output = []
    local = 0
    for red, green, blue, alpha in data:
        if alpha == 0 and (red != 0 or green != 0 or blue != 0):
            output.append((0, 0, 0, 0))
            local += 1
        else:
            output.append((red, green, blue, alpha))
    if local:
        image.putdata(output)
        image.save(path)
        changed += 1
        pixels_changed += local

print(f"Cleaned {pixels_changed} fully transparent pixels across {changed} PNG files.")
print("Semi-transparent edge pixels were not altered; inspect them visually on dark, light and terrain backgrounds.")
