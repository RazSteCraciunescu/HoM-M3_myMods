#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import wave
from collections import deque
from pathlib import Path

try:
    from PIL import Image, ImageChops
except ImportError:
    print("Pillow is required for visual validation.")
    print("Run SETUP_TEMPLATE_TOOLS.cmd, then run VALIDATE_TEMPLATE.cmd again.")
    raise SystemExit(2)

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []


def err(message: str) -> None:
    errors.append(message)


def warn(message: str) -> None:
    warnings.append(message)


def rel(path: Path) -> str:
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        err(f"JSON parse failed: {rel(path)}: {exc}")
        return {}


def has_hidden_rgb_under_full_transparency(image: Image.Image) -> bool:
    """Detect white/color matte data in fully transparent pixels."""
    rgba = image.convert("RGBA")
    r, g, b, a = rgba.split()
    fully_transparent = a.point(lambda value: 255 if value == 0 else 0)
    for channel in (r, g, b):
        hidden = ImageChops.multiply(channel, fully_transparent)
        if hidden.getextrema()[1] > 0:
            return True
    return False


def enclosed_transparent_holes(image: Image.Image) -> int:
    """Return count of transparent pixels not connected to canvas edge."""
    alpha = image.convert("RGBA").getchannel("A")
    w, h = alpha.size
    pix = alpha.load()
    seen: set[tuple[int, int]] = set()
    q: deque[tuple[int, int]] = deque()

    def add(x: int, y: int) -> None:
        if (x, y) not in seen and pix[x, y] <= 8:
            seen.add((x, y))
            q.append((x, y))

    for x in range(w):
        add(x, 0)
        add(x, h - 1)
    for y in range(h):
        add(0, y)
        add(w - 1, y)

    while q:
        x, y = q.popleft()
        for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if 0 <= nx < w and 0 <= ny < h:
                add(nx, ny)

    total_transparent = sum(1 for y in range(h) for x in range(w) if pix[x, y] <= 8)
    return max(0, total_transparent - len(seen))


# Reject accidental control characters in user-facing/config text.
text_suffixes = {".md", ".txt", ".json", ".jsonc", ".py"}
for path in ROOT.rglob("*"):
    if path.is_file() and path.suffix.lower() in text_suffixes:
        raw = path.read_bytes()
        bad = sorted({value for value in raw if value < 32 and value not in (9, 10, 13)})
        if bad:
            err(f"Control characters in text file {rel(path)}: byte values {bad}")

# Parse active JSON files.
for path in ROOT.rglob("*.json"):
    load_json(path)

mod = load_json(ROOT / "mod.json")
for section in ("creatures", "objects", "scripts", "artifacts", "spells"):
    for reference in mod.get(section, []):
        target = ROOT / "Content" / reference
        if not target.exists():
            err(f"Missing mod.json reference: Content/{reference}")

# All animation references.
for manifest in ROOT.rglob("animation.json"):
    data = load_json(manifest)
    for sequence in data.get("sequences", []):
        for reference in sequence.get("frames", []):
            target = ROOT / "Content" / "sprites" / reference
            if not target.exists():
                err(f"Missing frame referenced by {rel(manifest)}: {reference}")

# Creature graphics, sound and ability icon references.
creature_records: list[tuple[str, dict]] = []
for creature_file in (ROOT / "Content/config").rglob("creatures.json"):
    data = load_json(creature_file)
    for creature_id, creature in data.items():
        creature_records.append((creature_id, creature))
        graphics = creature.get("graphics", {})
        checks = [
            ("animation", "sprites"),
            ("map", "sprites"),
            ("mapAttackFromLeft", "data"),
            ("mapAttackFromRight", "data"),
            ("iconLarge", "data"),
            ("iconSmall", "data"),
        ]
        for key, bucket in checks:
            if key in graphics:
                target = ROOT / "Content" / bucket / graphics[key]
                if not target.exists():
                    err(f"{creature_id}: missing graphics.{key}: {graphics[key]}")
        for key, reference in creature.get("sound", {}).items():
            target = ROOT / "Content/sounds" / reference
            if not target.exists():
                err(f"{creature_id}: missing sound.{key}: {reference}")
        for ability_id, ability in creature.get("abilities", {}).items():
            icon = ability.get("icon") if isinstance(ability, dict) else None
            if icon:
                target = ROOT / "Content/data" / icon
                if not target.exists():
                    err(f"{creature_id}.{ability_id}: missing ability icon: {icon}")
                else:
                    image = Image.open(target).convert("RGBA")
                    if image.size != (48, 48):
                        err(f"{creature_id}.{ability_id}: ability icon must be 48x48: {icon} is {image.size}")

required_groups = {0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 30, 31, 32, 40, 41, 42, 50, 51}

# Battle frame dimensions, alpha, edge contact and idle stability.
for manifest in (ROOT / "Content/sprites").rglob("battle/animation.json"):
    data = load_json(manifest)
    groups = {int(sequence.get("group", -1)) for sequence in data.get("sequences", [])}
    missing = required_groups - groups
    if missing:
        err(f"{rel(manifest)} missing groups: {sorted(missing)}")

    idle_bboxes: list[tuple[int, int, int, int]] = []
    for sequence in data.get("sequences", []):
        group = int(sequence.get("group", -1))
        for reference in sequence.get("frames", []):
            path = ROOT / "Content/sprites" / reference
            if not path.exists():
                continue
            image = Image.open(path).convert("RGBA")
            if image.size != (450, 400):
                err(f"Battle frame must be 450x400: {rel(path)} is {image.size}")
            bbox = image.getchannel("A").getbbox()
            if not bbox:
                err(f"Empty battle frame: {rel(path)}")
                continue
            if bbox[0] <= 0 or bbox[1] <= 0 or bbox[2] >= image.width or bbox[3] >= image.height:
                warn(f"Artwork touches battle canvas edge: {rel(path)} bbox={bbox}")
            if has_hidden_rgb_under_full_transparency(image):
                warn(f"Hidden RGB exists under transparent battle pixels (possible white halo): {rel(path)}")
            if group == 2:
                idle_bboxes.append(bbox)

    if idle_bboxes:
        heights = [bbox[3] - bbox[1] for bbox in idle_bboxes]
        widths = [bbox[2] - bbox[0] for bbox in idle_bboxes]
        bottoms = [bbox[3] for bbox in idle_bboxes]
        if max(heights) - min(heights) > 5 or max(widths) - min(widths) > 8:
            warn(
                f"Idle silhouette changes size too much in {rel(manifest)}: "
                f"widths={min(widths)}..{max(widths)}, heights={min(heights)}..{max(heights)}"
            )
        median_bottom = sorted(bottoms)[len(bottoms) // 2]
        if not 250 <= median_bottom <= 285:
            warn(f"Idle feet/bottom are outside the tested battle anchor band in {rel(manifest)}: bottom={median_bottom}")

# Map frames.
for path in (ROOT / "Content/sprites").rglob("map/map_*.png"):
    image = Image.open(path).convert("RGBA")
    if image.size != (64, 64):
        err(f"Map creature frame must be 64x64: {rel(path)}")
    bbox = image.getchannel("A").getbbox()
    if not bbox:
        err(f"Empty map creature frame: {rel(path)}")
    else:
        if not 56 <= bbox[3] <= 64:
            warn(f"Map sprite feet/bottom are outside the tested anchor band: {rel(path)} bbox={bbox}")
    if has_hidden_rgb_under_full_transparency(image):
        warn(f"Hidden RGB exists under transparent map pixels (possible white halo): {rel(path)}")

# UI icons.
for path in (ROOT / "Content/data").rglob("icon_small.png"):
    image = Image.open(path).convert("RGBA")
    if image.size != (32, 32):
        err(f"Small icon must be 32x32: {rel(path)}")
    if image.getchannel("A").getbbox() is None:
        err(f"Small icon is empty: {rel(path)}")
    if has_hidden_rgb_under_full_transparency(image):
        warn(f"Hidden RGB under transparent small icon pixels: {rel(path)}")

for path in (ROOT / "Content/data").rglob("icon_large.png"):
    image = Image.open(path).convert("RGBA")
    if image.size != (58, 64):
        err(f"Large icon must be 58x64: {rel(path)}")
    corners = [image.getpixel((0, 0))[3], image.getpixel((57, 0))[3], image.getpixel((0, 63))[3], image.getpixel((57, 63))[3]]
    if min(corners) < 240:
        warn(f"Large icon corners are transparent; hero/town overlays may lack a faction background: {rel(path)}")

for path in (ROOT / "Content/data").rglob("*48.png"):
    if "shared" in path.parts:
        image = Image.open(path).convert("RGBA")
        if image.size != (48, 48):
            err(f"Ability icon should be 48x48: {rel(path)}")

# Dwellings: dimensions, outer alpha and enclosed transparent holes.
for path in (ROOT / "Content/sprites").rglob("dwellings/*/frame_*.png"):
    image = Image.open(path).convert("RGBA")
    if image.width > 110 or image.height > 110:
        warn(f"Dwelling may be oversized compared with the tested 96x96 baseline: {rel(path)} is {image.size}")
    if image.getchannel("A").getbbox() is None:
        err(f"Empty dwelling frame: {rel(path)}")
    holes = enclosed_transparent_holes(image)
    if holes > 12:
        warn(f"Dwelling contains {holes} enclosed transparent pixels; doors/windows/caves should usually be opaque dark: {rel(path)}")
    if has_hidden_rgb_under_full_transparency(image):
        warn(f"Hidden RGB exists under transparent dwelling pixels: {rel(path)}")

# WAV format.
for path in (ROOT / "Content/sounds").rglob("*.wav"):
    try:
        with wave.open(str(path), "rb") as wav:
            actual = (wav.getnchannels(), wav.getsampwidth(), wav.getframerate(), wav.getcomptype())
            expected = (1, 2, 44100, "NONE")
            if actual != expected:
                err(f"WAV must be mono PCM16 44.1kHz: {rel(path)} has {actual}")
    except Exception as exc:
        err(f"Bad WAV {rel(path)}: {exc}")

# Hash manifest.
entries: list[str] = []
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "MANIFEST_SHA256.txt":
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
(ROOT / "MANIFEST_SHA256.txt").write_text("\n".join(entries) + "\n", encoding="utf-8")

report = [
    "VCMI BLANK CREATURE TEMPLATE VALIDATION",
    f"Mod folder: {ROOT.name}",
    f"Files hashed: {len(entries)}",
    f"Errors: {len(errors)}",
    f"Warnings: {len(warnings)}",
    "",
]
if errors:
    report += ["ERRORS"] + [f"- {item}" for item in errors] + [""]
if warnings:
    report += ["WARNINGS"] + [f"- {item}" for item in warnings] + [""]
if not errors:
    report += [
        "RESULT: PASSED static validation.",
        "A live VCMI test is still required for engine/UI behavior, anchor calibration and visual quality.",
    ]
(ROOT / "QA_REPORT.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
print("\n".join(report))
raise SystemExit(1 if errors else 0)
