#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("Pillow is required. Run SETUP_TEMPLATE_TOOLS.cmd first.")
    raise SystemExit(2)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preview" / "ACTUAL_PACKAGED_ASSETS.png"
FONT_REGULAR = "C:/Windows/Fonts/arial.ttf"
FONT_BOLD = "C:/Windows/Fonts/arialbd.ttf"


def get_font(size: int, bold: bool = False):
    candidates = [FONT_BOLD if bold else FONT_REGULAR, "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            pass
    return ImageFont.load_default()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def paste_contained(canvas: Image.Image, source: Image.Image, box: tuple[int, int, int, int], checker: bool = False) -> None:
    x, y, w, h = box
    panel = Image.new("RGBA", (w, h), (25, 31, 42, 255))
    if checker:
        draw = ImageDraw.Draw(panel)
        cell = 14
        for yy in range(0, h, cell):
            for xx in range(0, w, cell):
                color = (73, 80, 91, 255) if ((xx // cell + yy // cell) % 2 == 0) else (105, 112, 122, 255)
                draw.rectangle((xx, yy, xx + cell - 1, yy + cell - 1), fill=color)
    image = source.convert("RGBA")
    image.thumbnail((w - 12, h - 12), Image.Resampling.LANCZOS)
    panel.alpha_composite(image, ((w - image.width) // 2, (h - image.height) // 2))
    canvas.alpha_composite(panel, (x, y))


mod = load_json(ROOT / "mod.json")
creatures: list[tuple[str, dict]] = []
for reference in mod.get("creatures", []):
    data = load_json(ROOT / "Content" / reference)
    creatures.extend(data.items())
creatures = creatures[:2]

W, H = 1700, 1180
image = Image.new("RGBA", (W, H), (17, 22, 30, 255))
draw = ImageDraw.Draw(image)
gold = (235, 196, 105, 255)
cyan = (116, 221, 226, 255)
white = (226, 231, 237, 255)
muted = (172, 181, 193, 255)

draw.text((36, 24), f"{mod.get('name', ROOT.name)} — ACTUAL PACKAGED ASSETS", font=get_font(42, True), fill=gold)
draw.text((38, 80), "Generated only from the PNG files currently inside this mod. Concept sheets are intentionally excluded.", font=get_font(20), fill=white)

# Creature columns.
column_w = 760
for idx, (creature_id, creature) in enumerate(creatures):
    x0 = 35 + idx * 815
    y0 = 125
    name = creature.get("name", {}).get("singular", creature_id)
    draw.rounded_rectangle((x0, y0, x0 + column_w, 900), radius=12, outline=(91, 105, 124, 255), width=2, fill=(20, 27, 37, 255))
    draw.text((x0 + 20, y0 + 15), name, font=get_font(29, True), fill=cyan)
    graphics = creature.get("graphics", {})

    # UI icons.
    large_path = ROOT / "Content/data" / graphics.get("iconLarge", "")
    small_path = ROOT / "Content/data" / graphics.get("iconSmall", "")
    if large_path.exists():
        large = Image.open(large_path).convert("RGBA").resize((174, 192), Image.Resampling.NEAREST)
        image.alpha_composite(large, (x0 + 20, y0 + 65))
        draw.text((x0 + 20, y0 + 264), "Large icon (58×64 ×3)", font=get_font(17), fill=muted)
    if small_path.exists():
        small = Image.open(small_path).convert("RGBA").resize((160, 160), Image.Resampling.NEAREST)
        paste_contained(image, small, (x0 + 230, y0 + 76, 180, 180), checker=True)
        draw.text((x0 + 230, y0 + 264), "Small icon (32×32 ×5)", font=get_font(17), fill=muted)

    # Map frame.
    map_manifest = ROOT / "Content/sprites" / graphics.get("map", "")
    if map_manifest.exists():
        sequences = load_json(map_manifest).get("sequences", [])
        refs = sequences[0].get("frames", []) if sequences else []
        if refs:
            map_frame = Image.open(ROOT / "Content/sprites" / refs[0]).convert("RGBA").resize((192, 192), Image.Resampling.NEAREST)
            paste_contained(image, map_frame, (x0 + 450, y0 + 65, 220, 200), checker=True)
            draw.text((x0 + 450, y0 + 264), "Adventure map frame", font=get_font(17), fill=muted)

    # Battle group samples.
    battle_manifest = ROOT / "Content/sprites" / graphics.get("animation", "")
    group_map: dict[int, list[str]] = {}
    if battle_manifest.exists():
        for seq in load_json(battle_manifest).get("sequences", []):
            group_map[int(seq.get("group", -1))] = seq.get("frames", [])
    samples = [(2, "Idle"), (0, "Walk"), (12, "Attack"), (4, "Defend"), (31, "Cast"), (5, "Death")]
    draw.text((x0 + 20, y0 + 310), "Battle groups", font=get_font(23, True), fill=gold)
    for sample_index, (group, label) in enumerate(samples):
        sx = x0 + 20 + (sample_index % 3) * 238
        sy = y0 + 350 + (sample_index // 3) * 245
        refs = group_map.get(group, [])
        if refs:
            ref = refs[len(refs) // 2]
            frame = Image.open(ROOT / "Content/sprites" / ref).convert("RGBA")
            bbox = frame.getchannel("A").getbbox()
            if bbox:
                bbox = (max(0, bbox[0] - 6), max(0, bbox[1] - 6), min(frame.width, bbox[2] + 6), min(frame.height, bbox[3] + 6))
                frame = frame.crop(bbox)
            paste_contained(image, frame, (sx, sy, 216, 185), checker=True)
        draw.text((sx + 4, sy + 192), f"Group {group}: {label}", font=get_font(17), fill=white)

# Ability icon and dwellings.
draw.rounded_rectangle((35, 925, 1665, 1145), radius=12, outline=(91, 105, 124, 255), width=2, fill=(20, 27, 37, 255))
draw.text((55, 945), "Shared ability icon and dwellings", font=get_font(25, True), fill=cyan)

ability_candidates = list((ROOT / "Content/data").rglob("*48.png"))
if ability_candidates:
    ability = Image.open(ability_candidates[0]).convert("RGBA").resize((144, 144), Image.Resampling.NEAREST)
    paste_contained(image, ability, (55, 985, 170, 145), checker=True)
    draw.text((235, 1030), "48×48 ability-icon template", font=get_font(19), fill=white)

x = 540
for manifest in list((ROOT / "Content/sprites").rglob("dwellings/*/animation.json"))[:2]:
    sequences = load_json(manifest).get("sequences", [])
    refs = sequences[0].get("frames", []) if sequences else []
    if not refs:
        continue
    frame = Image.open(ROOT / "Content/sprites" / refs[0]).convert("RGBA")
    paste_contained(image, frame, (x, 980, 190, 155), checker=True)
    draw.text((x, 955), manifest.parent.name, font=get_font(18, True), fill=gold)
    x += 290

OUT.parent.mkdir(parents=True, exist_ok=True)
image.convert("RGB").save(OUT, quality=95)
print(OUT)
