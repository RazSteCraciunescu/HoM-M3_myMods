#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

SOURCE_ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_NAMES = {"generated-mods", "__pycache__", ".git"}


def camel(value: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", value)
    if not parts:
        raise ValueError("Name must contain letters or numbers")
    return parts[0].lower() + "".join(part[:1].upper() + part[1:] for part in parts[1:])


def snake_from_camel(value: str) -> str:
    return re.sub(r"(?<!^)(?=[A-Z])", "_", value).lower()


def slugify(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", value.strip()).strip("-").lower()
    if not slug:
        raise ValueError("Invalid slug")
    return slug


def copytree(source: Path, destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns(*EXCLUDE_NAMES))


def replace_text_files(root: Path, replacements: list[tuple[str, str]]) -> None:
    text_extensions = {".json", ".jsonc", ".md", ".txt", ".cmd", ".py"}
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in text_extensions:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for old, new in replacements:
                text = text.replace(old, new)
            path.write_text(text, encoding="utf-8")


def rename_paths_deep(root: Path, replacements: list[tuple[str, str]]) -> None:
    for path in sorted(root.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        new_name = path.name
        for old, new in replacements:
            new_name = new_name.replace(old, new)
        if new_name != path.name:
            path.rename(path.with_name(new_name))


def pillow_available() -> bool:
    return importlib.util.find_spec("PIL") is not None


def build_preview_and_validate(destination: Path) -> None:
    if not pillow_available():
        raise SystemExit(
            "Pillow is required before validation/packaging. "
            "Run SETUP_TEMPLATE_TOOLS.cmd in the source template, then run the clone command again."
        )
    subprocess.run([sys.executable, str(destination / "tools/make_contact_sheet.py")], check=True)
    subprocess.run([sys.executable, str(destination / "tools/validate_mod.py")], check=True)


def make_zip(destination: Path, slug: str, output: Path) -> Path:
    zip_path = output / f"{slug}_1.0.0.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in destination.rglob("*"):
            if path.is_file():
                archive.write(path, Path(slug) / path.relative_to(destination))
    with zipfile.ZipFile(zip_path, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"ZIP integrity failure: {bad}")
        if not all(name.startswith(slug + "/") for name in archive.namelist()):
            raise RuntimeError("ZIP contains an invalid top-level layout")
    checksum = zip_path.with_name(zip_path.stem + "_SHA256.txt")
    checksum.write_text(f"{hashlib.sha256(zip_path.read_bytes()).hexdigest()}  {zip_path.name}\n", encoding="utf-8")
    return zip_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Clone the VCMI blank creature template into a collision-free new mod.")
    parser.add_argument("--mod-name", required=True, help='Display name, e.g. "Stone Lynx Creatures"')
    parser.add_argument("--base-name", required=True, help="Base creature singular name")
    parser.add_argument("--base-plural", required=True)
    parser.add_argument("--upgrade-name", required=True)
    parser.add_argument("--upgrade-plural", required=True)
    parser.add_argument("--slug", help="Folder/mod namespace; derived from mod name if omitted")
    parser.add_argument("--author", default="Custom VCMI mod author")
    parser.add_argument("--output", default=str(SOURCE_ROOT.parent / "generated-mods"))
    parser.add_argument("--zip", action="store_true", help="Validate and create a ready-to-install ZIP")
    args = parser.parse_args()

    slug = slugify(args.slug or args.mod_name)
    resource = camel(slug)
    base_id = camel(args.base_name)
    upgrade_id = camel(args.upgrade_name)
    base_folder = snake_from_camel(base_id)
    upgrade_folder = snake_from_camel(upgrade_id)

    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    destination = output / slug
    if destination == SOURCE_ROOT or SOURCE_ROOT in destination.parents:
        raise SystemExit("Output must not be inside the source template folder.")

    copytree(SOURCE_ROOT, destination)

    replacements = [
        ("VCMI Blank Creature Template", args.mod_name),
        ("Canvas Guardians Prime", args.upgrade_plural),
        ("Canvas Guardian Prime", args.upgrade_name),
        ("Canvas Guardians", args.base_plural),
        ("Canvas Guardian", args.base_name),
        ("canvasGuardianPrime", upgrade_id),
        ("canvasGuardian", base_id),
        ("canvas_guardian_prime", upgrade_folder),
        ("canvas_guardian", base_folder),
        ("vcmi-blank-creature-template", slug),
        ("blankcreature", resource),
        ("OpenAI-assisted template, based on live VCMI iteration findings", args.author),
        ("Canvas Workshop", f"{args.base_name} Dwelling"),
        ("Masterwork Atelier", f"{args.upgrade_name} Dwelling"),
        ("canvasWorkshop", base_id + "Dwelling"),
        ("masterworkAtelier", upgrade_id + "Dwelling"),
    ]
    replace_text_files(destination, replacements)
    rename_paths_deep(
        destination,
        [
            ("masterworkAtelier", upgrade_id + "Dwelling"),
            ("canvasWorkshop", base_id + "Dwelling"),
            ("canvas_guardian_prime", upgrade_folder),
            ("canvas_guardian", base_folder),
            ("blankcreature", resource),
        ],
    )

    # Generated evidence must belong to the new clone, not the source template.
    for path in [
        destination / "MANIFEST_SHA256.txt",
        destination / "QA_REPORT.txt",
        destination / "preview/ACTUAL_PACKAGED_ASSETS.png",
    ]:
        if path.exists():
            path.unlink()

    print(f"Created clone: {destination}")

    if args.zip:
        build_preview_and_validate(destination)
        zip_path = make_zip(destination, slug, output)
        print(f"Created validated ZIP: {zip_path}")
        print(f"Created checksum: {zip_path.with_name(zip_path.stem + '_SHA256.txt')}")
    else:
        if pillow_available():
            subprocess.run([sys.executable, str(destination / "tools/make_contact_sheet.py")], check=False)
        print("Next: edit the clone, run VALIDATE_TEMPLATE.cmd, run MAKE_ACTUAL_ASSETS_PREVIEW.cmd, then PACK_MOD.cmd.")


if __name__ == "__main__":
    main()
