#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Never package stale evidence.
subprocess.run([sys.executable, str(ROOT / "tools/make_contact_sheet.py")], check=True)
subprocess.run([sys.executable, str(ROOT / "tools/validate_mod.py")], check=True)

mod = json.loads((ROOT / "mod.json").read_text(encoding="utf-8"))
slug = ROOT.name
version = mod.get("version", "1.0.0")
output = ROOT.parent / f"{slug}_{version}.zip"
if output.exists():
    output.unlink()

with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in ROOT.rglob("*"):
        if path.is_file():
            archive.write(path, Path(slug) / path.relative_to(ROOT))

with zipfile.ZipFile(output, "r") as archive:
    bad = archive.testzip()
    if bad:
        raise RuntimeError(f"ZIP integrity failure: {bad}")
    if not all(name.startswith(slug + "/") for name in archive.namelist()):
        raise RuntimeError("ZIP contains an invalid top-level layout")

sha = hashlib.sha256(output.read_bytes()).hexdigest()
checksum = output.with_name(output.stem + "_SHA256.txt")
checksum.write_text(f"{sha}  {output.name}\n", encoding="utf-8")
print(output)
print(checksum)
