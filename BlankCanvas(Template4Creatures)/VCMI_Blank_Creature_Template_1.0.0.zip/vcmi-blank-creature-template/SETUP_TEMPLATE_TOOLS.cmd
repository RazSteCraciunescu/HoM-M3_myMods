@echo off
setlocal
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% -m pip install --user -r "%~dp0tools\requirements.txt"
if errorlevel 1 (
  echo.
  echo Setup failed. Confirm Python and pip are installed, then try again.
  pause
  exit /b 1
)
echo.
echo Template tools are ready.
pause
