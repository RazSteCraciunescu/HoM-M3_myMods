# VCMI Blank Creature Template 1.0.0

This package is both:

1. a ready-to-install neutral creature mod for visual/runtime calibration; and
2. a collision-safe source template for creating many independent creature mods.

It contains a base creature, an upgrade, two separate dwellings, complete battle groups, adventure-map sprites, correct icon roles, clean alpha edges, generated sounds, calibration guides, a clone tool, a validator and a packer.

## Install for a live test

Extract the top-level folder `vcmi-blank-creature-template` into:

```text
%USERPROFILE%\Documents\My Games\vcmi\Mods\
```

Confirm:

```text
%USERPROFILE%\Documents\My Games\vcmi\Mods\vcmi-blank-creature-template\mod.json
```

Enable **VCMI Blank Creature Template** in VCMI Launcher, then fully restart Map Editor.

The placeholder creatures are **Canvas Guardian** and **Canvas Guardian Prime**.

## Template tools

Run this once before using the validator or contact-sheet generator:

```text
SETUP_TEMPLATE_TOOLS.cmd
```

Main commands:

```text
CLONE_TEMPLATE.cmd                 Create an independent renamed copy
VALIDATE_TEMPLATE.cmd              Check JSON, paths, groups, dimensions, alpha and sounds
CLEAN_TRANSPARENT_RGB.cmd          Zero hidden RGB under fully transparent pixels
MAKE_ACTUAL_ASSETS_PREVIEW.cmd     Build a contact sheet from the packaged PNGs
PACK_MOD.cmd                       Validate, refresh evidence and create a ZIP
```

## First files to edit

```text
mod.json
Content\config\blankcreature\creatures.json
Content\config\blankcreature\dwellings.json
Content\data\blankcreature\...
Content\sprites\blankcreature\...
Content\sounds\blankcreature\...
```

Read `VCMI_Blank_Creature_Template_Customization_Guide.md` before manually renaming anything.
