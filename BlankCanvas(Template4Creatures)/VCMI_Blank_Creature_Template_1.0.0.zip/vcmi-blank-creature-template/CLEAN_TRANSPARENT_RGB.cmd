@echo off
setlocal
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% "%~dp0tools\clean_transparent_rgb.py"
pause
