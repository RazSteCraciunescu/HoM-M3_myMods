@echo off
setlocal
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% "%~dp0tools\validate_mod.py"
if errorlevel 2 (
  echo.
  echo Run SETUP_TEMPLATE_TOOLS.cmd once, then validate again.
)
pause
