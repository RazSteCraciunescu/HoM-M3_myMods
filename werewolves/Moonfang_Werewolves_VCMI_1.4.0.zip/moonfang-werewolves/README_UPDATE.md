# Moonfang Werewolves 1.4.0

Delete the previous `moonfang-werewolves` folder before installing. The tested Lycanthropy mechanic is unchanged. This release replaces battle movement/attacks and UI portrait treatment only.
