from __future__ import annotations

import hashlib
import json
import math
import os
import random
import shutil
import struct
import textwrap
import wave
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cv2
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps
from scipy import signal

ROOT = Path('/mnt/data/werewolf_work')
POSTER = Path('/mnt/data/a_detailed_promotional_mod_showcase_poster_for_a_h.png')
PACKAGE_ROOT = ROOT / 'Moonfang_Werewolves_v1.0.0'
MOD = PACKAGE_ROOT / 'moonfang-werewolves'
CONTENT = MOD / 'Content'
CONFIG = CONTENT / 'config' / 'moonfang'
SCRIPTS = CONTENT / 'scripts' / 'moonfang'
SPRITES = CONTENT / 'sprites' / 'moonfang'
DATA = CONTENT / 'data' / 'moonfang'
SOUNDS = CONTENT / 'sounds' / 'moonfang'
PREVIEW = MOD / 'preview'
SOURCE = MOD / 'source'
TOOLS = MOD / 'tools'
ZIP_PATH = ROOT / 'Moonfang_Werewolves_VCMI_1.0.0.zip'
SHA_PATH = ROOT / 'Moonfang_Werewolves_VCMI_1.0.0_SHA256.txt'

MOD_ID = 'moonfang-werewolves'
FORMS = {
    'moonborneWerewolf': {
        'slug': 'moonborne_werewolf',
        'name': 'Moonborne Werewolf',
        'plural': 'Moonborne Werewolves',
        'form': 'base',
        'target_height': 74,
        'accent': (116, 155, 224),
        'chance': 18,
        'stats': {
            'level': 4,
            'attack': 10,
            'defense': 9,
            'damage': {'min': 7, 'max': 10},
            'hitPoints': 32,
            'speed': 7,
            'growth': 4,
            'cost': {'gold': 370},
            'fightValue': 520,
            'aiValue': 650,
            'advMapAmount': {'min': 8, 'max': 16},
        },
        'description': (
            'A Moonborne Werewolf is a cursed hunter that moves on all fours until battle fury draws it upright. '
            'Its bite may spread controlled lycanthropy to a surviving living enemy stack of the same tier. '
            'The transformed stack remains on its original side and keeps exactly the health it had after the attack.'
        ),
        'upgrade': f'{MOD_ID}:moonfangAlpha',
    },
    'moonfangAlpha': {
        'slug': 'moonfang_alpha',
        'name': 'Moonfang Alpha',
        'plural': 'Moonfang Alphas',
        'form': 'alpha',
        'target_height': 86,
        'accent': (172, 85, 178),
        'chance': 25,
        'stats': {
            'level': 4,
            'attack': 12,
            'defense': 11,
            'damage': {'min': 9, 'max': 12},
            'hitPoints': 40,
            'speed': 8,
            'growth': 4,
            'cost': {'gold': 480},
            'fightValue': 700,
            'aiValue': 860,
            'advMapAmount': {'min': 6, 'max': 12},
        },
        'description': (
            'Moonfang Alphas are elder lycans that have mastered the change instead of being consumed by it. '
            'They are faster and harder to kill, and their same-tier lycanthropy is more reliable. '
            'A transformed victim stays loyal to its original army and retains its exact remaining health.'
        ),
        'upgrade': None,
    },
}

# Columns in the DALL-E concept sheet's generated animation tables.
ACTION_COL = {
    'idle': 0,
    'walk': 1,
    'attack_front': 2,
    'attack_up': 3,
    'attack_down': 4,
    'defend': 5,
    'damage': 6,
    'death': 7,
}

# Exact cell boundaries in the generated source poster.
X_BOUNDS = [15, 110, 213, 313, 412, 504, 584, 675, 778]
Y_ROWS = {
    'base': [(793, 843), (845, 914)],
    'alpha': [(971, 1035), (1037, 1088)],
}

FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_SERIF_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'


def font(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def ensure_dirs() -> None:
    if PACKAGE_ROOT.exists():
        shutil.rmtree(PACKAGE_ROOT)
    for d in [CONFIG, SCRIPTS, SPRITES, DATA, SOUNDS, PREVIEW, SOURCE, TOOLS]:
        d.mkdir(parents=True, exist_ok=True)


def save_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def crop_source_cells() -> Dict[str, Dict[str, List[Image.Image]]]:
    poster = Image.open(POSTER).convert('RGB')
    results: Dict[str, Dict[str, List[Image.Image]]] = {}
    for form, ranges in Y_ROWS.items():
        results[form] = {}
        for action, col in ACTION_COL.items():
            frames = []
            for row, (yt, yb) in enumerate(ranges):
                left = X_BOUNDS[col] + 5
                right = X_BOUNDS[col + 1] - 5
                crop = poster.crop((left, yt + 2, right, yb - 2))
                crop.save(SOURCE / f'{form}_{action}_{row}_raw.png')
                frames.append(remove_light_background(crop))
            results[form][action] = frames
    return results


def remove_light_background(image: Image.Image) -> Image.Image:
    """Extract the generated sprite from the light table cell without OCR or external assets."""
    rgb = np.array(image.convert('RGB'))
    h, w = rgb.shape[:2]
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    sat = hsv[:, :, 1]
    val = hsv[:, :, 2]
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

    # Generated cells use a pale, nearly neutral background. Dark or chromatic pixels are foreground seeds.
    fg = ((gray < 158) | (sat > 32) | ((rgb[:, :, 0] > rgb[:, :, 1] + 18) & (rgb[:, :, 0] > 85))).astype(np.uint8)
    fg[:2, :] = 0
    fg[-2:, :] = 0
    fg[:, :3] = 0
    fg[:, -3:] = 0

    kernel = np.ones((3, 3), np.uint8)
    fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, kernel)
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, kernel, iterations=2)

    n, labels, stats, centroids = cv2.connectedComponentsWithStats(fg, 8)
    if n <= 1:
        alpha = fg * 255
    else:
        # Keep the largest meaningful component and nearby fragments (blood, claws, ears, glow).
        candidates = []
        for i in range(1, n):
            area = stats[i, cv2.CC_STAT_AREA]
            x = stats[i, cv2.CC_STAT_LEFT]
            y = stats[i, cv2.CC_STAT_TOP]
            ww = stats[i, cv2.CC_STAT_WIDTH]
            hh = stats[i, cv2.CC_STAT_HEIGHT]
            if area >= 8 and x > 1 and x + ww < w - 1:
                candidates.append((area, i, (x, y, x + ww, y + hh)))
        if not candidates:
            alpha = fg * 255
        else:
            candidates.sort(reverse=True)
            _, main_id, main_box = candidates[0]
            mx1, my1, mx2, my2 = main_box
            keep = np.zeros_like(fg)
            for area, i, (x1, y1, x2, y2) in candidates:
                horizontal_gap = max(0, max(mx1 - x2, x1 - mx2))
                vertical_gap = max(0, max(my1 - y2, y1 - my2))
                if i == main_id or (horizontal_gap <= 10 and vertical_gap <= 10 and area >= 5):
                    keep[labels == i] = 1
            keep = cv2.dilate(keep, np.ones((3, 3), np.uint8), iterations=1)
            alpha = cv2.GaussianBlur((keep * 255).astype(np.uint8), (3, 3), 0.65)

    rgba = np.dstack([rgb, alpha])
    out = Image.fromarray(rgba, 'RGBA')
    bbox = out.getbbox()
    if bbox:
        out = out.crop(bbox)
    return out


def recolor_and_sharpen(sprite: Image.Image, form: str) -> Image.Image:
    # Preserve DALL-E source design while tightening contrast for the small HoMM3 battlefield scale.
    img = sprite.convert('RGBA')
    rgb = Image.merge('RGB', img.split()[:3])
    rgb = ImageEnhance.Contrast(rgb).enhance(1.12)
    rgb = ImageEnhance.Color(rgb).enhance(1.08 if form == 'base' else 1.16)
    rgb = rgb.filter(ImageFilter.UnsharpMask(radius=0.8, percent=115, threshold=2))
    r, g, b = rgb.split()
    if form == 'base':
        b = b.point(lambda p: min(255, int(p * 1.035 + 2)))
    else:
        r = r.point(lambda p: min(255, int(p * 1.035 + 2)))
        b = b.point(lambda p: min(255, int(p * 1.025)))
    return Image.merge('RGBA', (r, g, b, img.getchannel('A')))


def add_outline(sprite: Image.Image, radius: int = 2) -> Image.Image:
    alpha = sprite.getchannel('A')
    dilated = alpha.filter(ImageFilter.MaxFilter(radius * 2 + 1))
    outline_alpha = ImageChops.subtract(dilated, alpha)
    outline = Image.new('RGBA', sprite.size, (12, 11, 18, 0))
    outline.putalpha(outline_alpha.point(lambda p: int(p * 0.88)))
    out = Image.new('RGBA', sprite.size, (0, 0, 0, 0))
    out.alpha_composite(outline)
    out.alpha_composite(sprite)
    return out


def transform_sprite(
    sprite: Image.Image,
    target_height: int,
    scale: float = 1.0,
    angle: float = 0.0,
    flip: bool = False,
    opacity: float = 1.0,
    width_scale: float = 1.0,
) -> Image.Image:
    src = recolor_and_sharpen(sprite, 'base') if False else sprite
    if flip:
        src = ImageOps.mirror(src)
    ratio = (target_height * scale) / max(1, src.height)
    size = (max(1, int(src.width * ratio * width_scale)), max(1, int(src.height * ratio)))
    src = src.resize(size, Image.Resampling.LANCZOS)
    if angle:
        src = src.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
    if opacity < 1.0:
        a = src.getchannel('A').point(lambda p: int(p * max(0.0, min(1.0, opacity))))
        src.putalpha(a)
    return add_outline(src, 1)


def draw_glow(layer: Image.Image, center: Tuple[int, int], radius: int, accent: Tuple[int, int, int], strength: float) -> None:
    glow = Image.new('RGBA', layer.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    cx, cy = center
    for r in range(radius, 2, -3):
        alpha = int(5 + 42 * strength * (1 - r / max(radius, 1)))
        gd.ellipse((cx - r, cy - int(r * 0.45), cx + r, cy + int(r * 0.45)), outline=(*accent, alpha), width=2)
    glow = glow.filter(ImageFilter.GaussianBlur(2.2))
    layer.alpha_composite(glow)


def draw_particles(layer: Image.Image, seed: int, accent: Tuple[int, int, int], intensity: float = 1.0, area=(40, 18, 145, 110)) -> None:
    rng = random.Random(seed)
    d = ImageDraw.Draw(layer)
    x1, y1, x2, y2 = area
    count = max(1, int(13 * intensity))
    for _ in range(count):
        x = rng.randint(x1, x2)
        y = rng.randint(y1, y2)
        rad = rng.choice([1, 1, 1, 2])
        alpha = rng.randint(70, 180)
        d.ellipse((x-rad, y-rad, x+rad, y+rad), fill=(*accent, alpha))


def draw_slash(layer: Image.Image, direction: str, phase: float, accent: Tuple[int, int, int]) -> None:
    if phase <= 0:
        return
    slash = Image.new('RGBA', layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(slash)
    alpha = int(210 * min(1.0, phase))
    if direction == 'up':
        boxes = [(86, 18, 153, 91), (94, 23, 159, 95), (101, 29, 164, 99)]
        starts = [205, 208, 210]
        ends = [303, 307, 310]
    elif direction == 'down':
        boxes = [(87, 45, 154, 116), (95, 41, 160, 112), (103, 37, 166, 108)]
        starts = [42, 39, 37]
        ends = [140, 137, 134]
    else:
        boxes = [(84, 27, 155, 101), (93, 30, 162, 103), (101, 34, 168, 106)]
        starts = [218, 220, 222]
        ends = [318, 320, 322]
    for i, box in enumerate(boxes):
        color = (220, 230, 255, max(20, alpha - i * 45)) if i < 2 else (*accent, max(20, alpha - 80))
        d.arc(box, starts[i], ends[i], fill=color, width=max(1, 4-i))
    slash = slash.filter(ImageFilter.GaussianBlur(0.65))
    layer.alpha_composite(slash)


def draw_dust(layer: Image.Image, seed: int, amount: float) -> None:
    rng = random.Random(seed)
    dust = Image.new('RGBA', layer.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(dust)
    for _ in range(int(10 * amount)):
        x = rng.randint(49, 112)
        y = rng.randint(102, 116)
        r = rng.randint(1, 3)
        d.ellipse((x-r, y-r//2, x+r, y+r//2+1), fill=(104, 89, 78, rng.randint(30, 105)))
    dust = dust.filter(ImageFilter.GaussianBlur(1.0))
    layer.alpha_composite(dust)


@dataclass
class FrameSpec:
    action: str
    row: int = 0
    scale: float = 1.0
    angle: float = 0.0
    dx: int = 0
    dy: int = 0
    opacity: float = 1.0
    width_scale: float = 1.0
    flip: bool = False
    slash: float = 0.0
    slash_direction: str = 'front'
    aura: float = 0.0
    particles: float = 0.0
    dust: float = 0.0


def idle_specs(n=8) -> List[FrameSpec]:
    bob = [0, -1, -2, -1, 0, 1, 0, -1]
    return [FrameSpec('idle', i % 2, scale=1.0 + (0.006 if i in (2, 3) else 0), dy=bob[i % len(bob)]) for i in range(n)]


def fidget_specs() -> List[FrameSpec]:
    vals = [
        FrameSpec('idle', 0), FrameSpec('idle', 1, angle=-1), FrameSpec('attack_up', 0, scale=0.99, dy=-1),
        FrameSpec('attack_up', 1, scale=1.01, dy=-2, aura=0.18), FrameSpec('idle', 1, angle=1),
        FrameSpec('idle', 0), FrameSpec('idle', 1, dx=1), FrameSpec('idle', 0),
    ]
    return vals


def move_specs() -> List[FrameSpec]:
    bob = [0, -2, -1, 1, 0, -2, -1, 1]
    scales = [1.0, 1.015, 1.0, 0.99, 1.0, 1.015, 1.0, 0.99]
    return [FrameSpec('walk', i % 2, scale=scales[i], dy=bob[i], angle=(-1 if i % 4 == 1 else 1 if i % 4 == 3 else 0), dust=0.55) for i in range(8)]


def hit_specs() -> List[FrameSpec]:
    return [
        FrameSpec('idle', 0), FrameSpec('damage', 0, dx=-2, angle=-2), FrameSpec('damage', 1, dx=-7, angle=-5),
        FrameSpec('damage', 0, dx=-3, angle=-2), FrameSpec('idle', 1, dx=-1),
    ]


def defend_specs() -> List[FrameSpec]:
    return [
        FrameSpec('idle', 0), FrameSpec('defend', 0, dx=-1, scale=0.99), FrameSpec('defend', 1, dx=-2, scale=0.98),
        FrameSpec('defend', 1, dx=-2, scale=0.98), FrameSpec('defend', 0), FrameSpec('idle', 1),
    ]


def attack_specs(direction: str, magical=False, group=False) -> List[FrameSpec]:
    action = {'front': 'attack_front', 'up': 'attack_up', 'down': 'attack_down'}[direction]
    dy = {'front': 0, 'up': -4, 'down': 3}[direction]
    aura = 0.85 if magical else 0.0
    slash_mult = 1.0 if not group else 1.25
    return [
        FrameSpec('idle', 0),
        FrameSpec(action, 0, dx=1, dy=dy//3, aura=aura*0.20),
        FrameSpec(action, 0, dx=4, dy=dy*2//3, scale=1.015, aura=aura*0.45),
        FrameSpec(action, 1, dx=9, dy=dy, scale=1.035, slash=0.72*slash_mult, slash_direction=direction, aura=aura, particles=0.7 if magical else 0.0),
        FrameSpec(action, 1, dx=11, dy=dy, scale=1.025, slash=1.0*slash_mult, slash_direction=direction, aura=aura*0.8, particles=1.0 if magical else 0.0),
        FrameSpec(action, 0, dx=5, dy=dy//2, slash=0.45*slash_mult, slash_direction=direction, aura=aura*0.35),
        FrameSpec('idle', 1, dx=1),
        FrameSpec('idle', 0),
    ]


def death_specs(ranged=False) -> List[FrameSpec]:
    recoil = 6 if ranged else -3
    return [
        FrameSpec('idle', 0),
        FrameSpec('damage', 0, dx=recoil//2, angle=-3 if not ranged else 3),
        FrameSpec('damage', 1, dx=recoil, angle=-8 if not ranged else 8, scale=0.98),
        FrameSpec('damage', 1, dx=recoil+2, dy=8, angle=-19 if not ranged else 19, scale=0.91, opacity=0.88),
        FrameSpec('death', 0, dy=1, opacity=0.78),
        FrameSpec('death', 0, dy=1),
        FrameSpec('death', 1, dy=1),
        FrameSpec('death', 1, dy=1),
    ]


def turn_specs(right=False) -> List[FrameSpec]:
    widths = [1.0, 0.78, 0.52, 0.28, 0.52, 0.78, 1.0]
    specs=[]
    for i, ws in enumerate(widths):
        specs.append(FrameSpec('idle', i%2, width_scale=ws, flip=(right and i>=3) or ((not right) and i>=4), dy=-1 if i in (2,3,4) else 0))
    return specs


def movement_edge_specs(start=True) -> List[FrameSpec]:
    if start:
        return [FrameSpec('idle', 0), FrameSpec('walk', 0, scale=0.99, dy=1), FrameSpec('walk', 1, dy=-1, dust=0.35)]
    return [FrameSpec('walk', 1, dy=-1, dust=0.30), FrameSpec('walk', 0, dy=1), FrameSpec('idle', 0)]


def teleport_specs(start=True) -> List[FrameSpec]:
    values=[]
    seq=range(8) if start else reversed(range(8))
    for i in seq:
        f=i/7
        values.append(FrameSpec('idle', i%2, scale=1.0-0.35*f, dy=-int(13*f), opacity=1.0-f*0.92, aura=0.4+0.5*f, particles=0.4+0.8*f))
    return values


def render_frame(
    source: Dict[str, List[Image.Image]],
    spec: FrameSpec,
    target_height: int,
    accent: Tuple[int, int, int],
    form: str,
    seed: int,
    canvas_size=(160, 120),
) -> Image.Image:
    canvas = Image.new('RGBA', canvas_size, (0, 0, 0, 0))
    src = recolor_and_sharpen(source[spec.action][spec.row % 2], form)
    effective_height = int(target_height * 0.48) if spec.action == 'death' else target_height
    obj = transform_sprite(src, effective_height, spec.scale, spec.angle, spec.flip, spec.opacity, spec.width_scale)
    # Keep a common battlefield baseline so every frame occupies the same logical hex.
    x = (canvas.width - obj.width) // 2 + spec.dx - 5
    y = (canvas.height - 7) - obj.height + spec.dy
    if spec.aura:
        glow_radius = int((42 + 10*spec.aura) * canvas.width / 160)
        draw_glow(canvas, (canvas.width // 2 + spec.dx, int(canvas.height * 0.60) + spec.dy), glow_radius, accent, spec.aura)
    if spec.particles:
        draw_particles(canvas, seed, accent, spec.particles)
    if spec.dust:
        draw_dust(canvas, seed, spec.dust)
    canvas.alpha_composite(obj, (x, y))
    if spec.slash:
        draw_slash(canvas, spec.slash_direction, spec.slash, accent)
    return canvas


def build_battle_animation(form_data: dict, source: Dict[str, List[Image.Image]]) -> Tuple[dict, Dict[int, List[Path]]]:
    slug = form_data['slug']
    form = form_data['form']
    target_height = form_data['target_height']
    accent = tuple(form_data['accent'])
    out_dir = SPRITES / slug / 'battle'
    out_dir.mkdir(parents=True, exist_ok=True)

    group_specs: Dict[int, List[FrameSpec]] = {
        0: move_specs(),
        1: fidget_specs(),
        2: idle_specs(),
        3: hit_specs(),
        4: defend_specs(),
        5: death_specs(False),
        6: death_specs(True),
        7: turn_specs(False),
        8: turn_specs(True),
        11: attack_specs('up'),
        12: attack_specs('front'),
        13: attack_specs('down'),
        14: attack_specs('up'),
        15: attack_specs('front'),
        16: attack_specs('down'),
        17: attack_specs('up', magical=True),
        18: attack_specs('front', magical=True),
        19: attack_specs('down', magical=True),
        20: movement_edge_specs(True),
        21: movement_edge_specs(False),
        22: [FrameSpec('death', 1)],
        23: [FrameSpec('death', 1)],
        24: list(reversed(death_specs(False))),
        30: attack_specs('up', magical=True),
        31: attack_specs('front', magical=True),
        32: attack_specs('down', magical=True),
        40: attack_specs('up', magical=True, group=True),
        41: attack_specs('front', magical=True, group=True),
        42: attack_specs('down', magical=True, group=True),
        50: teleport_specs(True),
        51: teleport_specs(False),
    }
    sequences=[]
    paths_by_group: Dict[int, List[Path]]={}
    for group, specs in group_specs.items():
        filenames=[]
        paths=[]
        for idx, spec in enumerate(specs):
            filename=f'g{group:02d}_{idx:02d}.png'
            frame=render_frame(source, spec, target_height, accent, form, seed=hash((slug, group, idx)) & 0xffffffff)
            frame.save(out_dir/filename, optimize=True)
            filenames.append(filename)
            paths.append(out_dir/filename)
        sequences.append({'group': group, 'frames': filenames, 'generateShadow': 1, 'generateOverlay': 1})
        paths_by_group[group]=paths
    animation={'basepath': f'moonfang/{slug}/battle', 'sequences': sequences}
    save_json(out_dir/'animation.json', animation)
    return animation, paths_by_group


def build_map_animation(form_data: dict, source: Dict[str, List[Image.Image]]) -> dict:
    slug=form_data['slug']
    form=form_data['form']
    accent=tuple(form_data['accent'])
    out_dir=SPRITES/slug/'map'
    out_dir.mkdir(parents=True, exist_ok=True)
    (DATA/slug).mkdir(parents=True, exist_ok=True)
    filenames=[]
    for i in range(8):
        spec=FrameSpec('walk', i%2, scale=0.68 + (0.01 if i in (2,6) else 0), dy=[0,-1,-2,-1,0,1,0,-1][i], aura=0.10 if i in (2,6) else 0.0)
        frame=render_frame(source, spec, int(form_data['target_height']*0.68), accent, form, seed=1200+i, canvas_size=(72,72))
        # Reposition from battle baseline to adventure-map baseline.
        bbox=frame.getbbox()
        map_frame=Image.new('RGBA',(72,72),(0,0,0,0))
        if bbox:
            obj=frame.crop(bbox)
            if obj.height>58:
                ratio=58/obj.height
                obj=obj.resize((max(1,int(obj.width*ratio)),58),Image.Resampling.LANCZOS)
            map_frame.alpha_composite(obj,((72-obj.width)//2,65-obj.height))
        filename=f'map_{i:02d}.png'
        map_frame.save(out_dir/filename,optimize=True)
        filenames.append(filename)
    anim={'basepath':f'moonfang/{slug}/map','sequences':[{'group':0,'frames':filenames,'generateShadow':2,'generateOverlay':1}]}
    save_json(out_dir/'animation.json',anim)

    # Adventure-map attack portraits.
    for side, flip in [('right',False),('left',True)]:
        spec=FrameSpec('attack_front',1,scale=0.72,dx=4,slash=0.0,slash_direction='front',flip=flip,aura=0.15)
        frame=render_frame(source,spec,int(form_data['target_height']*0.70),accent,form,seed=330 if flip else 331,canvas_size=(72,72))
        bbox=frame.getbbox()
        out=Image.new('RGBA',(72,72),(0,0,0,0))
        if bbox:
            obj=frame.crop(bbox)
            if obj.height>62:
                rr=62/obj.height
                obj=obj.resize((max(1,int(obj.width*rr)),62),Image.Resampling.LANCZOS)
            out.alpha_composite(obj,((72-obj.width)//2,68-obj.height))
        out.save(DATA/slug/f'map_attack_{side}.png',optimize=True)
    return anim


def make_icon_background(size: Tuple[int,int], accent: Tuple[int,int,int]) -> Image.Image:
    w,h=size
    im=Image.new('RGBA',size,(9,15,28,255))
    px=im.load()
    for y in range(h):
        for x in range(w):
            d=math.hypot(x-w*0.55,y-h*0.35)/max(w,h)
            glow=max(0,1-d*1.8)
            px[x,y]=(int(8+accent[0]*0.14*glow),int(14+accent[1]*0.14*glow),int(26+accent[2]*0.18*glow),255)
    d=ImageDraw.Draw(im)
    d.ellipse((w*0.60,-h*0.12,w*1.05,h*0.34),fill=(220,228,242,225))
    d.ellipse((w*0.69,-h*0.08,w*1.09,h*0.29),fill=(18,27,45,255))
    return im


def build_icons(form_data: dict, source: Dict[str, List[Image.Image]]) -> None:
    slug=form_data['slug']; form=form_data['form']; accent=tuple(form_data['accent'])
    out_dir=DATA/slug
    out_dir.mkdir(parents=True,exist_ok=True)
    cut=recolor_and_sharpen(source['idle'][0],form)
    # Build at high resolution first for cleaner borders.
    card=make_icon_background((232,256),accent)
    ratio=205/max(cut.height,1)
    obj=cut.resize((max(1,int(cut.width*ratio)),205),Image.Resampling.LANCZOS)
    obj=add_outline(obj,2)
    card.alpha_composite(obj,((232-obj.width)//2,238-obj.height))
    d=ImageDraw.Draw(card)
    for i,c in enumerate([(230,205,128,255),(105,72,32,255),(18,14,10,255)]):
        d.rounded_rectangle((i+1,i+1,230-i,254-i),radius=12-i,outline=c,width=2)
    # Large and small VCMI portraits.
    large=card.resize((58,64),Image.Resampling.LANCZOS)
    small=card.resize((32,32),Image.Resampling.LANCZOS)
    large.save(out_dir/'icon_large.png',optimize=True)
    small.save(out_dir/'icon_small.png',optimize=True)
    card.save(out_dir/'portrait_232x256.png',optimize=True)


def build_ability_icon() -> None:
    out=DATA/'shared'
    out.mkdir(parents=True,exist_ok=True)
    for size in (32,64,128):
        im=Image.new('RGBA',(size,size),(10,12,27,255))
        d=ImageDraw.Draw(im)
        # Moon and claw marks.
        d.ellipse((size*0.11,size*0.08,size*0.79,size*0.76),fill=(214,222,244,255))
        d.ellipse((size*0.28,size*0.02,size*0.91,size*0.66),fill=(23,26,50,255))
        for off in (-0.12,0,0.12):
            box=(size*(0.28+off),size*0.34,size*(0.78+off),size*0.96)
            d.arc(box,205,305,fill=(185,89,225,255),width=max(1,size//14))
        d.rounded_rectangle((1,1,size-2,size-2),radius=max(2,size//9),outline=(215,181,91,255),width=max(1,size//20))
        im.save(out/f'lycanthropy_{size}.png',optimize=True)


def build_effect_animation() -> None:
    out=SPRITES/'effects'/'lycanthropy'
    out.mkdir(parents=True,exist_ok=True)
    files=[]
    accent=(175,88,232)
    for i in range(12):
        f=i/11
        im=Image.new('RGBA',(128,128),(0,0,0,0))
        glow=Image.new('RGBA',im.size,(0,0,0,0))
        d=ImageDraw.Draw(glow)
        radius=int(12+47*math.sin(math.pi*f))
        alpha=int(40+170*math.sin(math.pi*f))
        d.ellipse((64-radius,64-int(radius*0.65),64+radius,64+int(radius*0.65)),outline=(*accent,alpha),width=max(2,int(5*(1-f)+1)))
        # Crescent and particles.
        moon_r=int(10+14*math.sin(math.pi*f))
        d.ellipse((64-moon_r,64-moon_r,64+moon_r,64+moon_r),fill=(225,229,250,int(alpha*0.75)))
        d.ellipse((64-moon_r//3,59-moon_r,64+moon_r+4,65+moon_r),fill=(40,27,70,int(alpha*0.85)))
        draw_particles(glow,9000+i,accent,0.3+0.8*math.sin(math.pi*f),(18,18,110,110))
        glow=glow.filter(ImageFilter.GaussianBlur(1.3))
        im.alpha_composite(glow)
        fn=f'effect_{i:02d}.png'; im.save(out/fn,optimize=True); files.append(fn)
    save_json(out/'animation.json',{'basepath':'moonfang/effects/lycanthropy','sequences':[{'group':0,'frames':files,'generateShadow':0,'generateOverlay':0}]})


def normalize_audio(x: np.ndarray, peak=0.92) -> np.ndarray:
    x=np.asarray(x,dtype=np.float64)
    m=np.max(np.abs(x)) if x.size else 1.0
    if m>0:
        x=x/m*peak
    return np.clip(x,-1,1)


def envelope(n:int, attack:float, release:float, sr:int) -> np.ndarray:
    env=np.ones(n)
    a=max(1,int(attack*sr)); r=max(1,int(release*sr))
    env[:min(a,n)]=np.linspace(0,1,min(a,n))
    env[max(0,n-r):]=np.linspace(1,0,min(r,n))
    return env


def lowpass_noise(n:int, sr:int, cutoff:float, rng:np.random.Generator) -> np.ndarray:
    noise=rng.normal(0,1,n)
    sos=signal.butter(4,cutoff,btype='low',fs=sr,output='sos')
    return signal.sosfilt(sos,noise)


def bandpass_noise(n:int,sr:int,lo:float,hi:float,rng:np.random.Generator)->np.ndarray:
    noise=rng.normal(0,1,n)
    sos=signal.butter(4,[lo,hi],btype='band',fs=sr,output='sos')
    return signal.sosfilt(sos,noise)


def growl(duration:float,sr:int,base:float,seed:int,depth=1.0)->np.ndarray:
    rng=np.random.default_rng(seed)
    n=int(duration*sr); t=np.arange(n)/sr
    wobble=1+0.12*np.sin(2*np.pi*5.2*t)+0.055*np.sin(2*np.pi*11.7*t)
    freq=base*wobble*(1-0.10*t/max(duration,0.01))
    phase=2*np.pi*np.cumsum(freq)/sr
    voiced=np.sin(phase)+0.42*np.sin(2.02*phase+0.3)+0.24*np.sin(3.07*phase+1.2)
    noise=bandpass_noise(n,sr,110,1650,rng)
    x=(0.62*voiced+0.38*noise)*envelope(n,0.035,0.12,sr)
    # Pulsed throat resonance.
    x*=0.72+0.28*np.maximum(0,np.sin(2*np.pi*(7.2+depth)*t))
    return normalize_audio(x,0.75)


def howl(duration:float,sr:int,base:float,seed:int,descending=False)->np.ndarray:
    rng=np.random.default_rng(seed)
    n=int(duration*sr); t=np.arange(n)/sr
    if descending:
        f=base*(1.25-0.72*(t/duration))
    else:
        f=base*(0.86+0.12*np.sin(np.pi*t/duration)+0.05*np.sin(2*np.pi*1.7*t))
    phase=2*np.pi*np.cumsum(f)/sr
    voiced=np.sin(phase)+0.33*np.sin(2*phase+0.2)+0.14*np.sin(3*phase+0.8)
    breath=bandpass_noise(n,sr,250,2500,rng)
    x=(0.78*voiced+0.22*breath)*envelope(n,0.09,0.22,sr)
    x*=0.78+0.22*np.sin(2*np.pi*4.4*t)**2
    return normalize_audio(x,0.82)


def add_at(base:np.ndarray,clip:np.ndarray,start:int,gain:float=1.0)->None:
    end=min(len(base),start+len(clip))
    if end>start:
        base[start:end]+=clip[:end-start]*gain


def thump(sr:int,seed:int,duration=0.16,pitch=62)->np.ndarray:
    rng=np.random.default_rng(seed); n=int(duration*sr); t=np.arange(n)/sr
    phase=2*np.pi*np.cumsum(pitch*(1-0.55*t/duration))/sr
    x=np.sin(phase)*np.exp(-t*22)+lowpass_noise(n,sr,240,rng)*np.exp(-t*28)*0.55
    return normalize_audio(x,0.65)


def synth_sound(kind:str,form:str,sr=44100)->np.ndarray:
    alpha=form=='alpha'; base=69 if alpha else 82; seed_base=7200+(100 if alpha else 0)
    rng=np.random.default_rng(seed_base+sum(map(ord,kind)))
    if kind=='attack':
        dur=0.82; n=int(dur*sr); x=np.zeros(n)
        add_at(x,growl(0.68,sr,base,seed_base+1,1.3),0,0.80)
        whoosh=bandpass_noise(int(0.34*sr),sr,650,6500,rng)*envelope(int(0.34*sr),0.02,0.12,sr)
        add_at(x,normalize_audio(whoosh,0.62),int(0.18*sr),0.72)
        add_at(x,thump(sr,seed_base+2,0.18,48 if alpha else 56),int(0.44*sr),0.78)
    elif kind=='defend':
        dur=0.52; n=int(dur*sr); x=growl(dur,sr,base*0.86,seed_base+3,0.7)*0.76
        add_at(x,thump(sr,seed_base+4,0.14,52),int(0.07*sr),0.5)
    elif kind=='killed':
        dur=1.35; n=int(dur*sr); x=howl(dur,sr,base*2.25,seed_base+5,descending=True)
        scrape=bandpass_noise(n,sr,160,2800,rng)*np.exp(-np.arange(n)/sr*2.8)
        x+=0.22*scrape
    elif kind=='move':
        dur=0.55; n=int(dur*sr); x=np.zeros(n)
        add_at(x,thump(sr,seed_base+6,0.15,55),int(0.05*sr),0.68)
        add_at(x,thump(sr,seed_base+7,0.15,59),int(0.31*sr),0.66)
        scrape=bandpass_noise(n,sr,180,1300,rng)*envelope(n,0.02,0.15,sr)
        x+=scrape*0.12
    elif kind=='startMoving':
        dur=0.30; n=int(dur*sr); x=np.zeros(n)
        add_at(x,thump(sr,seed_base+8,0.17,54),int(0.08*sr),0.72)
        x+=bandpass_noise(n,sr,250,1900,rng)*envelope(n,0.01,0.12,sr)*0.08
    elif kind=='endMoving':
        dur=0.34; n=int(dur*sr); x=np.zeros(n)
        add_at(x,thump(sr,seed_base+9,0.19,49),int(0.06*sr),0.82)
        add_at(x, growl(0.26,sr,base*0.72,seed_base+10,0.4), 0, 0.20)
    elif kind=='wince':
        dur=0.48; n=int(dur*sr); t=np.arange(n)/sr
        f=(410 if alpha else 480)*(1-0.52*t/dur)
        phase=2*np.pi*np.cumsum(f)/sr
        yelp=(np.sin(phase)+0.24*np.sin(2.1*phase))*envelope(n,0.018,0.19,sr)
        yelp+=bandpass_noise(n,sr,500,4200,rng)*envelope(n,0.01,0.16,sr)*0.22
        x=yelp
    elif kind=='howl':
        x=howl(1.75,sr,base*2.35,seed_base+11,descending=False)
    elif kind=='lycanthropy':
        dur=1.05; n=int(dur*sr); t=np.arange(n)/sr
        shimmer=np.sin(2*np.pi*(480+740*t)*t)+0.45*np.sin(2*np.pi*(780+1150*t)*t)
        shimmer*=envelope(n,0.03,0.32,sr)
        magic=bandpass_noise(n,sr,500,7000,rng)*envelope(n,0.02,0.35,sr)
        x=0.45*shimmer+0.34*magic
        add_at(x,growl(0.75,sr,base*0.78,seed_base+12,0.6),int(0.18*sr),0.34)
    else:
        raise ValueError(kind)
    return normalize_audio(x,0.90)


def write_wav(path:Path,x:np.ndarray,sr=44100)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    pcm=(normalize_audio(x)*32767).astype('<i2')
    with wave.open(str(path),'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr); wf.writeframes(pcm.tobytes())


def build_sounds(form_data:dict)->None:
    slug=form_data['slug']; form=form_data['form']; out=SOUNDS/slug; out.mkdir(parents=True,exist_ok=True)
    for kind in ['attack','defend','killed','startMoving','endMoving','move','wince','howl','lycanthropy']:
        write_wav(out/f'{kind}.wav',synth_sound(kind,form))


def build_configs() -> None:
    creatures={}
    for cid,f in FORMS.items():
        stats=f['stats']
        abilities={
            'sameTierLycanthropy': {
                'type':'COMBAT_EVENT_TRIGGER',
                'subtype':f'{MOD_ID}:sameTierLycanthropy',
                'val':f['chance'],
                'addInfo':{
                    'creature':f'{MOD_ID}:{cid}',
                    'transmuteBy':'health',
                    'meleeOnly':True,
                    'activeAttackOnly':True,
                    'excludeSummoned':True,
                    'excludeClones':True,
                },
            },
            'lycanthropyImmunity': {'type':'TRANSMUTATION_IMMUNITY'},
        }
        creature={
            'name':{'singular':f['name'],'plural':f['plural']},
            'description':f['description'],
            'faction':'neutral',
            'level':stats['level'],
            'cost':stats['cost'],
            'speed':stats['speed'],
            'hitPoints':stats['hitPoints'],
            'attack':stats['attack'],
            'defense':stats['defense'],
            'damage':stats['damage'],
            'fightValue':stats['fightValue'],
            'aiValue':stats['aiValue'],
            'growth':stats['growth'],
            'horde':0,
            'advMapAmount':stats['advMapAmount'],
            'doubleWide':False,
            'hasDoubleWeek':False,
            'excludeFromRandomization':False,
            'special':False,
            'abilities':abilities,
            'graphics':{
                'animation':f"moonfang/{f['slug']}/battle/animation.json",
                'map':f"moonfang/{f['slug']}/map/animation.json",
                'mapAttackFromLeft':f"moonfang/{f['slug']}/map_attack_left.png",
                'mapAttackFromRight':f"moonfang/{f['slug']}/map_attack_right.png",
                'iconLarge':f"moonfang/{f['slug']}/icon_large.png",
                'iconSmall':f"moonfang/{f['slug']}/icon_small.png",
                'animationTime':{'walk':0.82,'attack':0.84,'idle':1.25},
                'timeBetweenFidgets':3.5,
            },
            'sound':{
                'attack':f"moonfang/{f['slug']}/attack.wav",
                'defend':f"moonfang/{f['slug']}/defend.wav",
                'killed':f"moonfang/{f['slug']}/killed.wav",
                'startMoving':f"moonfang/{f['slug']}/startMoving.wav",
                'endMoving':f"moonfang/{f['slug']}/endMoving.wav",
                'move':f"moonfang/{f['slug']}/move.wav",
                'wince':f"moonfang/{f['slug']}/wince.wav",
            },
        }
        if f['upgrade']:
            creature['upgrades']=[f['upgrade']]
        creatures[cid]=creature
    save_json(CONFIG/'creatures.json',creatures)

    script_cfg={
        'sameTierLycanthropy':{
            'implements':'combatEvent',
            'script':'moonfang/sameTierLycanthropy',
            'patches':[],
            'priority':0,
            'schema':{
                'type':'object',
                'properties':{
                    'creature':{'type':'string'},
                    'transmuteBy':{'type':'string','enum':['health','count']},
                    'meleeOnly':{'type':'boolean'},
                    'activeAttackOnly':{'type':'boolean'},
                    'excludeSummoned':{'type':'boolean'},
                    'excludeClones':{'type':'boolean'},
                },
                'required':['creature'],
                'additionalProperties':False,
            },
            'description':(
                '{Same-tier Lycanthropy}\nAfter a non-lethal melee attack, has a ${val}% chance to transform the '
                'surviving enemy stack into this werewolf form. It affects only living creatures of the same tier, '
                'preserves the victim stack\'s exact remaining health, leaves it on its original side, and does not '
                'trigger on retaliation, summoned stacks, or clones.'
            ),
        }
    }
    save_json(CONFIG/'scripts.json',script_cfg)

    mod_json={
        'name':'Moonfang Werewolves',
        'description':(
            'Adds the neutral Tier 4 Moonborne Werewolf and its Moonfang Alpha upgrade, with original generated '
            'battle/map art, complete animation groups, original procedural sounds, and a custom same-tier-only '
            'Lycanthropy combat event.'
        ),
        'modType':'Creatures',
        'version':'1.0.0',
        'author':'OpenAI-assisted custom mod package',
        'language':'english',
        'compatibility':{'min':'1.8.0'},
        'keepDisabled':False,
        'licenseName':'CC0-1.0 for original package assets and code, to the extent permitted',
        'creatures':['config/moonfang/creatures.json'],
        'scripts':['config/moonfang/scripts.json'],
        'changelog':{
            '1.0.0':[
                'Added Moonborne Werewolf and Moonfang Alpha.',
                'Added same-tier-only post-melee Lycanthropy with exact health preservation.',
                'Added complete battle animation group coverage, map animation, portraits, effects and sounds.',
            ]
        },
    }
    save_json(MOD/'mod.json',mod_json)


def build_lua() -> None:
    lua=r'''local Base = require("combat/combatScript")

local Script = setmetatable({}, {__index = Base})
Script.__index = Script

--- Same-tier-only lycanthropy for the Moonfang Werewolves mod.
---
--- Parameters supplied by the COMBAT_EVENT_TRIGGER bonus:
--- val                 percentage chance to trigger
--- creature            creature identifier used for the replacement stack
--- transmuteBy         "health" (default) or "count"
--- meleeOnly           ignore ranged attacks when true
--- activeAttackOnly    ignore retaliations / first strikes when true
--- excludeSummoned     ignore summoned victims when true
--- excludeClones       ignore Clone-spell victims when true

function Script:isImmune(unit)
    return unit:hasBonuses({type = "TRANSMUTATION_IMMUNITY"})
end

function Script:replacementShape(victim, creature)
    if self.transmuteBy == "count" then
        return victim:getCount(), 0
    end

    -- Preserve the victim's exact CURRENT living health, not its pre-attack count.
    -- We create enough new creatures to hold that health, then damage the top one
    -- by the excess. This means Lycanthropy never heals or inflates the target.
    local health = victim:getAvailableHealth()
    local maxHealth = creature:getMaxHealth()
    local count = math.max(math.ceil(health / maxHealth), 1)
    local excessHealth = count * maxHealth - health
    return count, excessHealth
end

function Script:onAfterAttack(server, battle, unit, other, payload)
    -- A dead attacker cannot spread the curse. It may have died to retaliation.
    if not unit:isAlive() then return end

    -- The requested mechanic affects only a surviving attacked stack.
    if not other or not other:isAlive() or not other:isLiving() then return end

    -- Werewolves are melee creatures; do not allow future ranged bonuses to spread it.
    if self.meleeOnly ~= false and payload and payload.ranged then return end

    -- Active attacks only: no retaliation / first-strike conversion.
    if self.activeAttackOnly ~= false and payload and payload.isCounter then return end

    -- Avoid disposable Clone or summoned-stack exploits.
    if self.excludeSummoned ~= false and other:isSummoned() then return end
    if self.excludeClones ~= false and other:isClone() then return end

    -- Core balance rule: attacker and target must have the exact same creature tier.
    if unit:creatureLevel() ~= other:creatureLevel() then return end

    if self:isImmune(other) then return end
    if not server:rollCombatAbility(battle, unit, self.val or 0) then return end

    local creature = self.creature and LIBRARY:getCreatureByName(self.creature) or unit:getCreature()
    if other:getCreature():getJsonKey() == creature:getJsonKey() then return end

    local count, excessHealth = self:replacementShape(other, creature)
    if count == nil then return end

    -- Read state before removing the original unit. Removal turns it into a ghost.
    local position = other:getPosition()
    local side = other:getSide()

    server:removeUnit(battle, other)
    local replacement = server:addUnit(battle, {
        count = count,
        type = creature,
        side = side,
        position = position,
        summoned = false
    })

    if replacement and excessHealth > 0 then
        server:damageUnit(battle, replacement, excessHealth)
    end

    server:refreshBattleUnits(battle)
end

return Script
'''
    (SCRIPTS/'sameTierLycanthropy.lua').write_text(lua,encoding='utf-8')


def battle_background(size=(160,120))->Image.Image:
    w,h=size
    im=Image.new('RGB',size,(87,69,52))
    d=ImageDraw.Draw(im)
    for y in range(h):
        c=(74+int(22*y/h),58+int(17*y/h),45+int(11*y/h))
        d.line((0,y,w,y),fill=c)
    rng=random.Random(422)
    for _ in range(140):
        x=rng.randrange(w); y=rng.randrange(h); r=rng.choice([1,1,2])
        d.ellipse((x-r,y-r,x+r,y+r),fill=(76+rng.randrange(25),61+rng.randrange(18),45+rng.randrange(18)))
    # faint hex floor
    for cx in range(-20,w+30,34):
        for cy in range(77,h+20,20):
            xx=cx+(17 if (cy//20)%2 else 0)
            d.polygon([(xx,cy-10),(xx+15,cy-5),(xx+15,cy+5),(xx,cy+10),(xx-15,cy+5),(xx-15,cy-5)],outline=(112,91,67))
    return im


def make_gif(paths:Sequence[Path],out:Path,durations:int=95)->None:
    bg=battle_background()
    frames=[]
    for p in paths:
        fr=Image.open(p).convert('RGBA')
        comp=bg.convert('RGBA')
        comp.alpha_composite(fr)
        frames.append(comp.convert('P',palette=Image.Palette.ADAPTIVE,colors=255))
    frames[0].save(out,save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=False,disposal=2)


def build_previews(group_paths:Dict[str,Dict[int,List[Path]]]) -> None:
    # Animated GIFs for the user to inspect before launching VCMI.
    for cid,groups in group_paths.items():
        slug=FORMS[cid]['slug']
        for name,gid in [('idle',2),('walk',0),('attack_front',12),('attack_up',11),('attack_down',13),('defend',4),('damage',3),('death',5),('special',18),('resurrection',24)]:
            make_gif(groups[gid],PREVIEW/f'{slug}_{name}.gif',95 if name!='death' else 120)

    # Contact sheet for every group, using the action climax or middle frame.
    group_names={0:'Move',1:'Hover/Fidget',2:'Idle',3:'Hit',4:'Defend',5:'Death',6:'Ranged death',7:'Turn left',8:'Turn right',11:'Attack up',12:'Attack front',13:'Attack down',14:'Shoot up*',15:'Shoot front*',16:'Shoot down*',17:'Special up',18:'Special front',19:'Special down',20:'Move start',21:'Move end',22:'Dead',23:'Ranged dead',24:'Resurrection',30:'Cast up',31:'Cast front',32:'Cast down',40:'Group attack up',41:'Group attack front',42:'Group attack down',50:'Teleport start',51:'Teleport end'}
    for cid,groups in group_paths.items():
        rows=math.ceil(len(group_names)/4)
        sheet=Image.new('RGB',(4*220,rows*165),(13,18,29))
        d=ImageDraw.Draw(sheet)
        for idx,(gid,name) in enumerate(group_names.items()):
            x=(idx%4)*220; y=(idx//4)*165
            d.rounded_rectangle((x+5,y+5,x+214,y+159),radius=8,fill=(28,36,51),outline=(143,112,54),width=2)
            p=groups[gid][min(len(groups[gid])-1,max(0,len(groups[gid])//2))]
            fr=Image.open(p).convert('RGBA')
            bg=battle_background().convert('RGBA'); bg.alpha_composite(fr)
            bg=bg.resize((192,144),Image.Resampling.LANCZOS)
            sheet.paste(bg.convert('RGB'),(x+14,y+11))
            d.rectangle((x+14,y+130,x+206,y+154),fill=(8,11,19))
            d.text((x+18,y+134),f'{gid}: {name}',font=font(FONT_BOLD,13),fill=(235,229,207))
        sheet.save(PREVIEW/f"{FORMS[cid]['slug']}_all_animation_groups.png",quality=95)

    build_stats_preview(group_paths)


def build_stats_preview(group_paths:Dict[str,Dict[int,List[Path]]])->None:
    W,H=1200,760
    im=Image.new('RGB',(W,H),(8,14,26)); d=ImageDraw.Draw(im)
    # gradient / star texture
    for y in range(H):
        c=(8+int(8*y/H),14+int(10*y/H),26+int(16*y/H))
        d.line((0,y,W,y),fill=c)
    rng=random.Random(881)
    for _ in range(260):
        x=rng.randrange(W); y=rng.randrange(H); a=rng.randrange(80,210)
        d.point((x,y),fill=(a,a,min(255,a+25)))
    d.ellipse((475,-210,850,165),fill=(224,230,243))
    d.ellipse((560,-235,905,125),fill=(20,27,45))
    d.text((W//2,36),'MOONFANG WEREWOLVES',font=font(FONT_SERIF_BOLD,48),anchor='ma',fill=(239,220,157),stroke_width=2,stroke_fill=(52,31,16))
    d.text((W//2,92),'Neutral Tier 4 creature pair for VCMI 1.8+',font=font(FONT_REG,22),anchor='ma',fill=(207,217,235))

    cards=[('moonborneWerewolf',55),('moonfangAlpha',625)]
    for cid,x in cards:
        f=FORMS[cid]; stats=f['stats']; accent=tuple(f['accent'])
        d.rounded_rectangle((x,135,x+520,690),radius=20,fill=(17,25,41),outline=(201,162,79),width=3)
        icon=Image.open(DATA/f['slug']/'portrait_232x256.png').convert('RGBA').resize((186,205),Image.Resampling.LANCZOS)
        im.paste(icon.convert('RGB'),(x+24,160))
        title_size = 23 if cid == 'moonborneWerewolf' else 27
        d.text((x+230,165),f['name'],font=font(FONT_SERIF_BOLD,title_size),fill=(240,224,170))
        d.text((x+230,204),'Base form' if cid=='moonborneWerewolf' else 'Upgraded form',font=font(FONT_BOLD,17),fill=accent)
        stat_lines=[
            f"Attack {stats['attack']}     Defense {stats['defense']}",
            f"Damage {stats['damage']['min']}–{stats['damage']['max']}     Health {stats['hitPoints']}",
            f"Speed {stats['speed']}     Growth {stats['growth']}",
            f"Cost {stats['cost']['gold']} gold     AI {stats['aiValue']}",
            f"Lycanthropy {f['chance']}%",
        ]
        for i,line in enumerate(stat_lines):
            d.text((x+230,240+i*34),line,font=font(FONT_BOLD if i==4 else FONT_REG,17),fill=(229,231,236) if i<4 else (212,132,236))
        # Representative animation strip.
        frames=[]
        for gid in (2,0,12,4,3,5):
            p=group_paths[cid][gid][len(group_paths[cid][gid])//2]
            fr=Image.open(p).convert('RGBA')
            bg=battle_background().convert('RGBA'); bg.alpha_composite(fr)
            frames.append(bg.resize((75,56),Image.Resampling.LANCZOS).convert('RGB'))
        for i,fr in enumerate(frames):
            im.paste(fr,(x+24+i*81,390))
        labels=['Idle','Walk','Attack','Defend','Hit','Death']
        for i,label in enumerate(labels):
            d.text((x+61+i*81,450),label,font=font(FONT_REG,11),anchor='ma',fill=(203,207,216))
        # Ability box.
        d.rounded_rectangle((x+24,482,x+496,650),radius=12,fill=(11,18,31),outline=accent,width=2)
        ability=Image.open(DATA/'shared'/'lycanthropy_64.png').convert('RGBA')
        im.paste(ability.convert('RGB'),(x+38,501))
        d.text((x+118,503),'Same-tier Lycanthropy',font=font(FONT_BOLD,19),fill=(235,221,183))
        wrapped=textwrap.wrap('After a surviving same-tier living stack is hit by an active melee attack, it may transform into the attacking form. It stays on its original side and keeps its exact remaining health.',52)
        for j,line in enumerate(wrapped):
            d.text((x+118,536+j*20),line,font=font(FONT_REG,14),fill=(212,216,227))
        d.text((x+38,621),'No retaliation • no dead stacks • no tier mismatch • no summons/clones',font=font(FONT_BOLD,10),fill=(176,189,215))
    d.text((W//2,722),'Full PNG animation groups • adventure-map animation • portraits • original procedural WAV sounds',font=font(FONT_REG,18),anchor='ma',fill=(202,208,222))
    im.save(PREVIEW/'Moonfang_Werewolves_preview.png',quality=96)


def build_docs() -> None:
    readme=r'''MOONFANG WEREWOLVES v1.0.0
VCMI neutral creature mod

WHAT THIS ADDS
==============
1. Moonborne Werewolf — neutral Tier 4 base creature.
2. Moonfang Alpha — neutral Tier 4 upgraded form.
3. Exact same-tier-only Lycanthropy:
   - checked AFTER a melee attack;
   - target must still be alive;
   - attacker and target must both be the same creature tier;
   - transformed stack remains on the defending/original side;
   - transformed stack keeps its exact remaining health;
   - never triggers on retaliation, ranged attacks, summoned stacks, clones, non-living units, or immune units.
4. Complete battle PNG animation coverage, map animations, portraits, effects and original procedural sounds.

IMPORTANT ENGINE REQUIREMENT
============================
This exact mechanic uses VCMI's custom combat-event Lua scripting and therefore requires a VCMI 1.8.0 beta/development build or newer.
The current 1.7.x stable line can load ordinary new creatures, but cannot express the requested target-dependent same-tier rule exactly.

EXACT WINDOWS INSTALLATION
==========================
1. Install VCMI and import legal Heroes III Complete or Shadow of Death data in VCMI Launcher.
2. Close VCMI Launcher, the game and Map Editor.
3. Extract the downloaded ZIP.
4. Copy the single folder named:

      moonfang-werewolves

   into:

      %USERPROFILE%\Documents\My Games\vcmi\Mods\

5. The final path MUST be exactly:

      %USERPROFILE%\Documents\My Games\vcmi\Mods\moonfang-werewolves\mod.json

   Do not leave an extra nested folder such as:

      ...\moonfang-werewolves\moonfang-werewolves\mod.json

6. Start VCMI Launcher.
7. Open the Mods page, locate “Moonfang Werewolves”, and enable it.
8. Start VCMI Map Editor from the same 1.8+ build.
9. Create a small test map and place Moonborne Werewolves or Moonfang Alphas from the neutral monster list.
10. Save the map, start it, and test attacks against surviving Tier 4 living creatures.

FAST MECHANIC TEST
==================
- Put 30 Moonborne Werewolves on one hero.
- Put 40 Swordsmen, Medusas, Vampires, Demons, Pegasi, or another Tier 4 living unit on the opposing hero.
- Attack repeatedly until the 18% base-form effect triggers.
- Repeat with Moonfang Alphas for the 25% upgraded effect.
- Then attack a Tier 1 stack and a Tier 7 stack: neither can transform.
- Kill a target outright: it cannot transform.
- Retaliate: retaliation cannot trigger the effect.

WHERE TO EDIT BALANCE LATER
===========================
Open:

  Content\config\moonfang\creatures.json

The fields attack, defense, damage, hitPoints, speed, growth, cost, fightValue and aiValue are plainly editable.
The Lycanthropy percentages are the “val” fields in each creature's sameTierLycanthropy ability.

TROUBLESHOOTING
===============
- Mod not listed: verify the exact final path ending in moonfang-werewolves\mod.json.
- Launcher says incompatible: install a VCMI 1.8.0 beta/development build or newer.
- Creature loads but script fails: inspect VCMI_Client_log.txt and VCMI_Server_log.txt under Documents\My Games\vcmi.
- Purple/checkerboard or missing image: confirm the ZIP was fully extracted and Content\sprites and Content\data exist.
- No sound: confirm Content\sounds exists and Windows did not block/quarantine extracted WAV files.

PREVIEWS
========
Open preview\Moonfang_Werewolves_preview.png and the animated GIFs before launching the game.

STATIC VALIDATION
=================
See QA_REPORT.txt. The package was validated for strict JSON syntax, referenced-file existence, animation-group completeness, PNG alpha, WAV format, Lua structural checks, and ZIP integrity. Runtime behavior still needs the first real VCMI 1.8+ test on your Windows installation.
'''
    (MOD/'README_FIRST.txt').write_text(readme,encoding='utf-8')

    description='''# english

A neutral Tier 4 creature pair built for VCMI:

- **Moonborne Werewolf** — fast base form, 18% same-tier Lycanthropy.
- **Moonfang Alpha** — tougher upgraded form, 25% same-tier Lycanthropy.

The conversion happens only after an active melee attack against a surviving living creature stack of the same tier. The victim remains on its original side and keeps its exact post-attack health. The script excludes retaliations, ranged attacks, summons and clones.

The package contains complete VCMI PNG animation groups, adventure-map animation, portraits, an effect set, original procedurally synthesized WAV sounds, source crops, previews, editable JSON, and the Lua source.

**Requires VCMI 1.8.0 beta/development or newer.**
'''
    (MOD/'description.md').write_text(description,encoding='utf-8')

    balance='''# Balance notes

## Moonborne Werewolf — Tier 4

| Statistic | Value |
|---|---:|
| Attack | 10 |
| Defense | 9 |
| Damage | 7–10 |
| Health | 32 |
| Speed | 7 |
| Growth | 4 |
| Cost | 370 gold |
| Fight value | 520 |
| AI value | 650 |
| Lycanthropy | 18% |

## Moonfang Alpha — Tier 4 upgrade

| Statistic | Value |
|---|---:|
| Attack | 12 |
| Defense | 11 |
| Damage | 9–12 |
| Health | 40 |
| Speed | 8 |
| Growth | 4 |
| Cost | 480 gold |
| Fight value | 700 |
| AI value | 860 |
| Lycanthropy | 25% |

## Why the mechanic is constrained

The target must survive and have the same creature level as the attacker. The replacement stays on the original side, so Lycanthropy does not recruit enemies into the werewolf army. Exact remaining hit points are retained by spawning enough werewolves to hold that health and immediately applying the excess as damage to the top creature. It therefore cannot heal a one-hit-point survivor into a full-health werewolf.

The ability is intentionally disabled for retaliation, ranged attacks, non-living targets, summoned units and clones. Both forms also have transmutation immunity, preventing recursive lycan-on-lycan conversion.
'''
    (MOD/'BALANCE_NOTES.md').write_text(balance,encoding='utf-8')

    tech='''# Technical implementation

## Main configuration

- `Content/config/moonfang/creatures.json` — creature definitions, stats, upgrade relation, graphics and sounds.
- `Content/config/moonfang/scripts.json` — registers the custom combat-event script.
- `Content/scripts/moonfang/sameTierLycanthropy.lua` — target validation and transformation logic.

## Asset directories

- `Content/sprites/moonfang/<form>/battle/` — complete battle animation groups as transparent PNG files plus `animation.json`.
- `Content/sprites/moonfang/<form>/map/` — adventure-map animation.
- `Content/data/moonfang/<form>/` — creature portraits and map attack stills.
- `Content/sounds/moonfang/<form>/` — PCM 16-bit mono WAV effects.
- `Content/sprites/moonfang/effects/lycanthropy/` — standalone transformation-effect frames for future scripting/UI integration.

## VCMI animation groups supplied

0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 30, 31, 32, 40, 41, 42, 50 and 51.

The creature is melee-only, so ranged groups 14–16 are defensive completeness/future-proofing and are not used by its current stats.

## Art and audio provenance

The creature designs began with an original DALL-E-generated concept/animation showcase made specifically for this request. The production frames were extracted from that generated source, cleaned, retouched, outlined, aligned and expanded into complete consistent animation sequences by the included builder. No WoG, HotA, Warcraft, Ubisoft or Discord creator sprite/sound files are redistributed.

All included WAV files were synthesized procedurally for this package; they are not recordings copied from another game.
'''
    (MOD/'TECHNICAL_NOTES.md').write_text(tech,encoding='utf-8')

    tuning='''# Tuning guide

Open `Content/config/moonfang/creatures.json` in VS Code or Notepad++.

## Change stats

For either creature, edit:

```json
"attack": 10,
"defense": 9,
"damage": { "min": 7, "max": 10 },
"hitPoints": 32,
"speed": 7,
"growth": 4,
"cost": { "gold": 370 }
```

## Change Lycanthropy chance

Find the ability named `sameTierLycanthropy` and edit `val`:

```json
"val": 18
```

Use an integer from 0 to 100.

## Make a future faction use the creatures

Change `"faction": "neutral"` to the target faction identifier and add the creature IDs to that faction's town dwelling configuration. Keep the IDs stable (`moonborneWerewolf`, `moonfangAlpha`) so existing maps/saves can still resolve them.

## Change art or sounds

Replace PNG/WAV files while keeping the same file names, or edit their paths in `creatures.json`. Battle frame canvases are 160×120 with transparent alpha and a shared bottom baseline.
'''
    (MOD/'TUNING_GUIDE.md').write_text(tuning,encoding='utf-8')

    license_text='''CC0 1.0 Universal dedication for the original package code, procedural audio, generated/derived graphics, documentation and build tooling, to the extent the package creator is legally able to dedicate them.

This package does not include Heroes of Might and Magic III, VCMI binaries, HotA, WoG, Warcraft, or third-party creator assets. All trademarks and original game rights remain with their respective owners. VCMI's own engine license is not changed by this package.
'''
    (MOD/'LICENSE.txt').write_text(license_text,encoding='utf-8')

    # Copy concept source and builder for future edits.
    shutil.copy2(POSTER,SOURCE/'concept_reference_DALLE.png')
    (SOURCE/'README.txt').write_text('The concept image is a generated visual reference. Its printed concept stats are not authoritative; use BALANCE_NOTES.md and creatures.json for final values.\n',encoding='utf-8')
    shutil.copy2(Path(__file__),TOOLS/'build_moonfang_mod.py')


def basic_lua_check(text:str)->List[str]:
    errors=[]
    required=['require("combat/combatScript")','function Script:onAfterAttack','unit:creatureLevel()','other:creatureLevel()','other:isAlive()','payload.isCounter','server:rollCombatAbility','server:removeUnit','server:addUnit','server:damageUnit','server:refreshBattleUnits','return Script']
    for token in required:
        if token not in text:
            errors.append(f'Missing Lua token: {token}')
    # Crude but useful structural count for this generated script.
    if text.count('function ') != text.count('\nend'):
        errors.append(f'Lua function/end count differs: {text.count("function ")} functions vs {text.count(chr(10)+"end")} line-end blocks')
    return errors


def validate_and_report(group_paths:Dict[str,Dict[int,List[Path]]])->None:
    errors=[]; warnings=[]
    json_files=list(MOD.rglob('*.json'))
    for p in json_files:
        try:
            json.loads(p.read_text(encoding='utf-8'))
        except Exception as e:
            errors.append(f'JSON parse failed: {p.relative_to(MOD)}: {e}')

    # Verify creature references.
    cfg=json.loads((CONFIG/'creatures.json').read_text(encoding='utf-8'))
    for cid,c in cfg.items():
        refs=[]
        g=c['graphics']; s=c['sound']
        refs += [('sprites',g['animation']),('sprites',g['map'])]
        refs += [('data',g['mapAttackFromLeft']),('data',g['mapAttackFromRight']),('data',g['iconLarge']),('data',g['iconSmall'])]
        refs += [('sounds',v) for v in s.values()]
        for root,rel in refs:
            actual=CONTENT/root/rel
            if not actual.exists():
                errors.append(f'Missing reference for {cid}: {root}/{rel}')

    required_groups={0,1,2,3,4,5,6,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,30,31,32,40,41,42,50,51}
    frame_count=0
    for cid,groups in group_paths.items():
        missing=required_groups-set(groups)
        if missing: errors.append(f'{cid} missing groups: {sorted(missing)}')
        for gid,paths in groups.items():
            if not paths: errors.append(f'{cid} group {gid} has no frames')
            for p in paths:
                frame_count+=1
                try:
                    im=Image.open(p)
                    if im.mode!='RGBA': warnings.append(f'Frame not RGBA: {p.relative_to(MOD)}')
                    if im.size!=(160,120): errors.append(f'Unexpected battle frame size {im.size}: {p.relative_to(MOD)}')
                    if im.getchannel('A').getbbox() is None: errors.append(f'Fully transparent frame: {p.relative_to(MOD)}')
                except Exception as e:
                    errors.append(f'PNG read failed: {p.relative_to(MOD)}: {e}')

    wav_files=list((CONTENT/'sounds').rglob('*.wav'))
    for p in wav_files:
        try:
            with wave.open(str(p),'rb') as wf:
                if wf.getnchannels()!=1: errors.append(f'WAV is not mono: {p.relative_to(MOD)}')
                if wf.getsampwidth()!=2: errors.append(f'WAV is not PCM16: {p.relative_to(MOD)}')
                if wf.getframerate()!=44100: errors.append(f'WAV sample rate is not 44100: {p.relative_to(MOD)}')
                if wf.getnframes()<1000: errors.append(f'WAV too short: {p.relative_to(MOD)}')
        except Exception as e:
            errors.append(f'WAV read failed: {p.relative_to(MOD)}: {e}')

    lua=(SCRIPTS/'sameTierLycanthropy.lua').read_text(encoding='utf-8')
    errors.extend(basic_lua_check(lua))

    report=[
        'MOONFANG WEREWOLVES v1.0.0 — STATIC QA REPORT',
        '================================================',
        f'Result: {"PASSED" if not errors else "FAILED"}',
        f'JSON files parsed: {len(json_files)}',
        f'Battle PNG frames checked: {frame_count}',
        f'WAV files checked: {len(wav_files)}',
        f'Creature forms: {len(FORMS)}',
        f'Animation groups per form: {len(required_groups)}',
        '',
        'Checks performed:',
        '- strict JSON parsing',
        '- all creature graphic and sound references exist',
        '- all documented creature animation groups exist',
        '- battle frames are non-empty RGBA 160x120 PNG files',
        '- sounds are readable mono PCM16 44.1 kHz WAV files',
        '- Lua contains the required event, same-tier, survival, roll, replacement and refresh operations',
        '',
        'Runtime limitation:',
        'This environment does not contain the user\'s proprietary Heroes III data or a Windows VCMI 1.8+ runtime, so the first live engine test must be performed on the user\'s installation.',
    ]
    if warnings:
        report += ['', 'Warnings:'] + [f'- {w}' for w in warnings]
    if errors:
        report += ['', 'Errors:'] + [f'- {e}' for e in errors]
    (MOD/'QA_REPORT.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    if errors:
        raise RuntimeError('\n'.join(errors))


def write_manifest_and_zip() -> None:
    # File hashes inside the mod.
    entries=[]
    for p in sorted(MOD.rglob('*')):
        if p.is_file() and p.name!='MANIFEST_SHA256.txt':
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            entries.append(f'{h}  {p.relative_to(MOD).as_posix()}')
    (MOD/'MANIFEST_SHA256.txt').write_text('\n'.join(entries)+'\n',encoding='utf-8')

    if ZIP_PATH.exists(): ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(MOD.rglob('*')):
            if p.is_file():
                z.write(p,Path(MOD.name)/p.relative_to(MOD))
    with zipfile.ZipFile(ZIP_PATH,'r') as z:
        bad=z.testzip()
        if bad: raise RuntimeError(f'ZIP integrity failed at {bad}')
        names=z.namelist()
        if not names or any(not n.startswith('moonfang-werewolves/') for n in names):
            raise RuntimeError('ZIP top-level folder is incorrect')
    sha=hashlib.sha256(ZIP_PATH.read_bytes()).hexdigest()
    SHA_PATH.write_text(f'{sha}  {ZIP_PATH.name}\n',encoding='utf-8')


def main() -> None:
    ensure_dirs()
    sources=crop_source_cells()
    group_paths={}
    for cid,f in FORMS.items():
        source=sources[f['form']]
        _,groups=build_battle_animation(f,source)
        group_paths[cid]=groups
        build_map_animation(f,source)
        build_icons(f,source)
        build_sounds(f)
    build_ability_icon()
    build_effect_animation()
    build_configs()
    build_lua()
    build_docs()
    build_previews(group_paths)
    validate_and_report(group_paths)
    write_manifest_and_zip()
    print(f'Built: {ZIP_PATH}')
    print(f'SHA256: {SHA_PATH.read_text().strip()}')
    print(f'Files: {sum(1 for p in MOD.rglob("*") if p.is_file())}')
    print(f'Size: {ZIP_PATH.stat().st_size/1024/1024:.2f} MiB')


if __name__=='__main__':
    main()
