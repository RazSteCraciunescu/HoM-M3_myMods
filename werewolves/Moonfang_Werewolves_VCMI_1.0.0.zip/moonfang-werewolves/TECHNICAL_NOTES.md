# Technical implementation

## Main configuration

- `Content/config/moonfang/creatures.json` — creature definitions, stats, upgrade relation, graphics and sounds.
- `Content/config/moonfang/scripts.json` — registers the custom combat-event script.
- `Content/scripts/moonfang/sameTierLycanthropy.lua` — target validation and transformation logic.

## Asset directories

- `Content/sprites/moonfang/<form>/battle/` — complete battle animation groups as transparent PNG files plus `animation.json`.
- `Content/sprites/moonfang/<form>/map/` — adventure-map animation.
- `Content/data/moonfang/<form>/` — creature portraits and map attack stills.
- `Content/sounds/moonfang/<form>/` — PCM 16-bit mono WAV effects.
- `Content/sprites/moonfang/effects/lycanthropy/` — standalone transformation-effect frames for future scripting/UI integration.

## VCMI animation groups supplied

0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 30, 31, 32, 40, 41, 42, 50 and 51.

The creature is melee-only, so ranged groups 14–16 are defensive completeness/future-proofing and are not used by its current stats.

## Art and audio provenance

The creature designs began with an original DALL-E-generated concept/animation showcase made specifically for this request. The production frames were extracted from that generated source, cleaned, retouched, outlined, aligned and expanded into complete consistent animation sequences by the included builder. No WoG, HotA, Warcraft, Ubisoft or Discord creator sprite/sound files are redistributed.

All included WAV files were synthesized procedurally for this package; they are not recordings copied from another game.
