MOONFANG WEREWOLVES v1.0.0
VCMI neutral creature mod

WHAT THIS ADDS
==============
1. Moonborne Werewolf — neutral Tier 4 base creature.
2. Moonfang Alpha — neutral Tier 4 upgraded form.
3. Exact same-tier-only Lycanthropy:
   - checked AFTER a melee attack;
   - target must still be alive;
   - attacker and target must both be the same creature tier;
   - transformed stack remains on the defending/original side;
   - transformed stack keeps its exact remaining health;
   - never triggers on retaliation, ranged attacks, summoned stacks, clones, non-living units, or immune units.
4. Complete battle PNG animation coverage, map animations, portraits, effects and original procedural sounds.

IMPORTANT ENGINE REQUIREMENT
============================
This exact mechanic uses VCMI's custom combat-event Lua scripting and therefore requires a VCMI 1.8.0 beta/development build or newer.
The current 1.7.x stable line can load ordinary new creatures, but cannot express the requested target-dependent same-tier rule exactly.

EXACT WINDOWS INSTALLATION
==========================
1. Install VCMI and import legal Heroes III Complete or Shadow of Death data in VCMI Launcher.
2. Close VCMI Launcher, the game and Map Editor.
3. Extract the downloaded ZIP.
4. Copy the single folder named:

      moonfang-werewolves

   into:

      %USERPROFILE%\Documents\My Games\vcmi\Mods\

5. The final path MUST be exactly:

      %USERPROFILE%\Documents\My Games\vcmi\Mods\moonfang-werewolves\mod.json

   Do not leave an extra nested folder such as:

      ...\moonfang-werewolves\moonfang-werewolves\mod.json

6. Start VCMI Launcher.
7. Open the Mods page, locate “Moonfang Werewolves”, and enable it.
8. Start VCMI Map Editor from the same 1.8+ build.
9. Create a small test map and place Moonborne Werewolves or Moonfang Alphas from the neutral monster list.
10. Save the map, start it, and test attacks against surviving Tier 4 living creatures.

FAST MECHANIC TEST
==================
- Put 30 Moonborne Werewolves on one hero.
- Put 40 Swordsmen, Medusas, Vampires, Demons, Pegasi, or another Tier 4 living unit on the opposing hero.
- Attack repeatedly until the 18% base-form effect triggers.
- Repeat with Moonfang Alphas for the 25% upgraded effect.
- Then attack a Tier 1 stack and a Tier 7 stack: neither can transform.
- Kill a target outright: it cannot transform.
- Retaliate: retaliation cannot trigger the effect.

WHERE TO EDIT BALANCE LATER
===========================
Open:

  Content\config\moonfang\creatures.json

The fields attack, defense, damage, hitPoints, speed, growth, cost, fightValue and aiValue are plainly editable.
The Lycanthropy percentages are the “val” fields in each creature's sameTierLycanthropy ability.

TROUBLESHOOTING
===============
- Mod not listed: verify the exact final path ending in moonfang-werewolves\mod.json.
- Launcher says incompatible: install a VCMI 1.8.0 beta/development build or newer.
- Creature loads but script fails: inspect VCMI_Client_log.txt and VCMI_Server_log.txt under Documents\My Games\vcmi.
- Purple/checkerboard or missing image: confirm the ZIP was fully extracted and Content\sprites and Content\data exist.
- No sound: confirm Content\sounds exists and Windows did not block/quarantine extracted WAV files.

PREVIEWS
========
Open preview\Moonfang_Werewolves_preview.png and the animated GIFs before launching the game.

STATIC VALIDATION
=================
See QA_REPORT.txt. The package was validated for strict JSON syntax, referenced-file existence, animation-group completeness, PNG alpha, WAV format, Lua structural checks, and ZIP integrity. Runtime behavior still needs the first real VCMI 1.8+ test on your Windows installation.
