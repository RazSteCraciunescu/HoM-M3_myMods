# Tuning guide

Open `Content/config/moonfang/creatures.json` in VS Code or Notepad++.

## Change stats

For either creature, edit:

```json
"attack": 10,
"defense": 9,
"damage": { "min": 7, "max": 10 },
"hitPoints": 32,
"speed": 7,
"growth": 4,
"cost": { "gold": 370 }
```

## Change Lycanthropy chance

Find the ability named `sameTierLycanthropy` and edit `val`:

```json
"val": 18
```

Use an integer from 0 to 100.

## Make a future faction use the creatures

Change `"faction": "neutral"` to the target faction identifier and add the creature IDs to that faction's town dwelling configuration. Keep the IDs stable (`moonborneWerewolf`, `moonfangAlpha`) so existing maps/saves can still resolve them.

## Change art or sounds

Replace PNG/WAV files while keeping the same file names, or edit their paths in `creatures.json`. Battle frame canvases are 160×120 with transparent alpha and a shared bottom baseline.
