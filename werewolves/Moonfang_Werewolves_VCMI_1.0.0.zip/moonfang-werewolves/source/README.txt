The concept image is a generated visual reference. Its printed concept stats are not authoritative; use BALANCE_NOTES.md and creatures.json for final values.
