# Balance notes

## Moonborne Werewolf — Tier 4

| Statistic | Value |
|---|---:|
| Attack | 10 |
| Defense | 9 |
| Damage | 7–10 |
| Health | 32 |
| Speed | 7 |
| Growth | 4 |
| Cost | 370 gold |
| Fight value | 520 |
| AI value | 650 |
| Lycanthropy | 18% |

## Moonfang Alpha — Tier 4 upgrade

| Statistic | Value |
|---|---:|
| Attack | 12 |
| Defense | 11 |
| Damage | 9–12 |
| Health | 40 |
| Speed | 8 |
| Growth | 4 |
| Cost | 480 gold |
| Fight value | 700 |
| AI value | 860 |
| Lycanthropy | 25% |

## Why the mechanic is constrained

The target must survive and have the same creature level as the attacker. The replacement stays on the original side, so Lycanthropy does not recruit enemies into the werewolf army. Exact remaining hit points are retained by spawning enough werewolves to hold that health and immediately applying the excess as damage to the top creature. It therefore cannot heal a one-hit-point survivor into a full-health werewolf.

The ability is intentionally disabled for retaliation, ranged attacks, non-living targets, summoned units and clones. Both forms also have transmutation immunity, preventing recursive lycan-on-lycan conversion.
