# english

A neutral Tier 4 creature pair built for VCMI:

- **Moonborne Werewolf** — fast base form, 18% same-tier Lycanthropy.
- **Moonfang Alpha** — tougher upgraded form, 25% same-tier Lycanthropy.

The conversion happens only after an active melee attack against a surviving living creature stack of the same tier. The victim remains on its original side and keeps its exact post-attack health. The script excludes retaliations, ranged attacks, summons and clones.

The package contains complete VCMI PNG animation groups, adventure-map animation, portraits, an effect set, original procedurally synthesized WAV sounds, source crops, previews, editable JSON, and the Lua source.

**Requires VCMI 1.8.0 beta/development or newer.**
