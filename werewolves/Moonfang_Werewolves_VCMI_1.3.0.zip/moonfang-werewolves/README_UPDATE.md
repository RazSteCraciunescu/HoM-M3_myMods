# Moonfang Werewolves 1.2.0

## Visual corrections

- Battle sprites are approximately two-thirds the previous size and use a compact bottom-right-anchored canvas.
- Idle and map frames are normalized to a stable height, so breathing/pointing no longer makes the creature grow and shrink.
- White matte islands connected to transparency have been removed.
- Map and battle idle playback is slower.
- Both creature icons now use an original neutral landscape background.
- Transmutation Immunity and Same-tier Lycanthropy both have properly filled 32x32 icons.

## Dwellings

- Howler's Den recruits Moonborne Werewolves.
- Moonfang Lair recruits Moonfang Alphas.

The tested conversion logic is unchanged. VCMI casualty bookkeeping and the post-defeat neutral-map disguise quirk remain unchanged.
