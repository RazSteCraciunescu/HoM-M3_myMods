# Editing visuals and dwellings — version 1.2.0

## Creature files

- `moonborneWerewolf` battle: `Content\sprites\moonfang\moonborne_werewolf\battle\`
- `moonborneWerewolf` map: `Content\sprites\moonfang\moonborne_werewolf\map\`
- `moonfangAlpha` battle: `Content\sprites\moonfang\moonfang_alpha\battle\`
- `moonfangAlpha` map: `Content\sprites\moonfang\moonfang_alpha\map\`

Every battle frame is **112x96 RGBA**. Keep the visible creature close to the **bottom-right** of the transparent canvas; the right and bottom margins are the anchor used to align the model to its occupied battle hex.

Every adventure-map frame is **48x48 RGBA** and bottom-centered. The map manifest repeats frames to slow the idle loop; edit the frame list in each `map\animation.json` to change map animation speed.

Large creature icons are 58x64. Small army/exchange icons are 32x32. Map-attack images are 48x48.

## Animation timing

Edit `Content\config\moonfang\creatures.json`:

- `graphics.animationTime.idle` controls the length of the idle/preview sequence.
- `graphics.animationTime.walk` controls movement playback.
- `graphics.animationTime.attack` affects shooting/casting timing where supported.
- `graphics.timeBetweenFidgets` controls how often the hover/fidget sequence is played.

Do not restore `basepath` inside animation manifests. Each frame is intentionally referenced through a complete VCMI resource path.

## Ability artwork

Replace `Content\data\moonfang\shared\lycanthropy_32.png` and `transmutation_immunity_32.png`. Ability artwork must stay on a 32x32 transparent canvas, with the visible symbol filling roughly 27–29 pixels so it is neither clipped nor tiny.

Lycanthropy VFX: `Content\sprites\moonfang\effects\lycanthropy\`. Effect frames are **112x112 RGBA**.

## External dwellings

The two active map dwellings are under:

`Content\sprites\moonfang\dwellings\`

Each dwelling uses eight 112x112 RGBA frames. Names, recruited creatures, masks and animation references are configured in:

`Content\config\moonfang\dwellings.json`

Town-ready facade art that is not yet attached to a faction is under:

`future-town\dwellings\`

Each folder contains a 240x180 town facade and a 58x64 building icon.

## Validate

Double-click `VALIDATE_VISUALS.cmd`, or run:

```text
py -3 tools\validate_visual_resources.py
```
