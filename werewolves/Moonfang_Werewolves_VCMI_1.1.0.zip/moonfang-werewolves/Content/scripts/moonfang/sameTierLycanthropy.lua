local Base = require("combat/combatScript")

local Script = setmetatable({}, {__index = Base})
Script.__index = Script

--- Same-tier-only lycanthropy for the Moonfang Werewolves mod.
---
--- Parameters supplied by the COMBAT_EVENT_TRIGGER bonus:
--- val                 percentage chance to trigger
--- creature            creature identifier used for the replacement stack
--- transmuteBy         "health" (default) or "count"
--- meleeOnly           ignore ranged attacks when true
--- activeAttackOnly    ignore retaliations / first strikes when true
--- excludeSummoned     ignore summoned victims when true
--- excludeClones       ignore Clone-spell victims when true
--- effectAnimation     optional one-shot VCMI animation shown after conversion
--- effectSound         optional sound played with the conversion animation

function Script:isImmune(unit)
    return unit:hasBonuses({type = "TRANSMUTATION_IMMUNITY"})
end

function Script:replacementShape(victim, creature)
    if self.transmuteBy == "count" then
        return victim:getCount(), 0
    end

    -- Preserve the victim's exact CURRENT living health, not its pre-attack count.
    -- We create enough new creatures to hold that health, then damage the top one
    -- by the excess. This means Lycanthropy never heals or inflates the target.
    local health = victim:getAvailableHealth()
    local maxHealth = creature:getMaxHealth()
    local count = math.max(math.ceil(health / maxHealth), 1)
    local excessHealth = count * maxHealth - health
    return count, excessHealth
end

function Script:onAfterAttack(server, battle, unit, other, payload)
    -- A dead attacker cannot spread the curse. It may have died to retaliation.
    if not unit:isAlive() then return end

    -- The requested mechanic affects only a surviving attacked stack.
    if not other or not other:isAlive() or not other:isLiving() then return end

    -- Werewolves are melee creatures; do not allow future ranged bonuses to spread it.
    if self.meleeOnly ~= false and payload and payload.ranged then return end

    -- Active attacks only: no retaliation / first-strike conversion.
    if self.activeAttackOnly ~= false and payload and payload.isCounter then return end

    -- Avoid disposable Clone or summoned-stack exploits.
    if self.excludeSummoned ~= false and other:isSummoned() then return end
    if self.excludeClones ~= false and other:isClone() then return end

    -- Core balance rule: attacker and target must have the exact same creature tier.
    if unit:creatureLevel() ~= other:creatureLevel() then return end

    if self:isImmune(other) then return end
    if not server:rollCombatAbility(battle, unit, self.val or 0) then return end

    local creature = self.creature and LIBRARY:getCreatureByName(self.creature) or unit:getCreature()
    if other:getCreature():getJsonKey() == creature:getJsonKey() then return end

    local count, excessHealth = self:replacementShape(other, creature)
    if count == nil then return end

    -- Read state before removing the original unit. Removal turns it into a ghost.
    local position = other:getPosition()
    local side = other:getSide()

    server:removeUnit(battle, other)
    local replacement = server:addUnit(battle, {
        count = count,
        type = creature,
        side = side,
        position = position,
        summoned = false
    })

    if replacement and excessHealth > 0 then
        server:damageUnit(battle, replacement, excessHealth)
    end

    server:refreshBattleUnits(battle)

    -- Purely cosmetic. Failure to display a development-build-specific effect must
    -- never cancel the already completed transformation.
    if replacement and self.effectAnimation then
        pcall(function()
            server:showBattleAnimation(
                battle,
                { replacement },
                self.effectAnimation,
                self.effectSound or "",
                1.0,
                false
            )
        end)
    end
end

return Script
