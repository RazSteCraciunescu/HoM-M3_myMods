# Editing Moonfang Werewolf Visuals

## Creature icons

Replace these files without changing their names:

- `Content\data\moonfang\moonborne_werewolf\icon_large.png` — 58x64 RGBA
- `Content\data\moonfang\moonborne_werewolf\icon_small.png` — 32x32 RGBA
- `Content\data\moonfang\moonfang_alpha\icon_large.png` — 58x64 RGBA
- `Content\data\moonfang\moonfang_alpha\icon_small.png` — 32x32 RGBA

Do not put creature names, captions, statistics or presentation borders inside the image.

## Battle animation frames

Base creature:

`Content\sprites\moonfang\moonborne_werewolf\battle\`

Upgrade:

`Content\sprites\moonfang\moonfang_alpha\battle\`

Keep every frame 160x120 RGBA and keep the existing file names.

Important groups:

- `g00` movement
- `g01` mouse-over/fidget
- `g02` idle
- `g03` taking damage
- `g04` defend
- `g05` death
- `g07` / `g08` turn
- `g11`, `g12`, `g13` melee attack up/horizontal/down
- `g20` / `g21` movement start/end
- `g22` corpse
- `g24` resurrection
- `g30`, `g31`, `g32` cast up/horizontal/down

Do not restore a `basepath` property in `animation.json`. Version 1.1.0 deliberately lists every frame with its complete VCMI resource path.

## Adventure-map animation

Replace `map_00.png` through `map_07.png` in each creature's `map` folder. Keep them 72x72 RGBA.

## Map attack images

Replace:

- `Content\data\moonfang\moonborne_werewolf\map_attack_left.png`
- `Content\data\moonfang\moonborne_werewolf\map_attack_right.png`
- `Content\data\moonfang\moonfang_alpha\map_attack_left.png`
- `Content\data\moonfang\moonfang_alpha\map_attack_right.png`

Keep the existing 72x72 RGBA canvas.

## Lycanthropy ability icon

Replace:

`Content\data\moonfang\shared\lycanthropy_32.png`

Keep it 32x32 with a small margin so it stays inside the ability box.

## Lycanthropy effect

Frames:

`Content\sprites\moonfang\effects\lycanthropy\effect_00.png` through `effect_15.png`

Keep them 128x128 RGBA. Their order is listed in:

`Content\sprites\moonfang\effects\lycanthropy\animation.json`

The script requests this animation after a successful conversion:

`Content\scripts\moonfang\sameTierLycanthropy.lua`

## Validate after editing

Double-click:

`VALIDATE_VISUALS.cmd`

or run:

`py -3 tools\validate_visual_resources.py`
