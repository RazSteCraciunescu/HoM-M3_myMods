@echo off
setlocal
cd /d "%~dp0"
py -3 tools\validate_visual_resources.py
if errorlevel 1 (
  echo.
  echo VALIDATION FAILED.
  pause
  exit /b 1
)
echo.
echo VALIDATION PASSED.
pause
