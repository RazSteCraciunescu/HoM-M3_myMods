from __future__ import annotations

import json
import struct
import sys
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTENT = ROOT / "Content"
ERRORS: list[str] = []
CHECKED = 0


def error(message: str) -> None:
    ERRORS.append(message)


def read_png(path: Path) -> tuple[int, int, int]:
    raw = path.read_bytes()
    if raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG")
    if raw[12:16] != b"IHDR":
        raise ValueError("missing IHDR")
    width, height, bit_depth, colour_type = struct.unpack(">IIBB", raw[16:26])
    return width, height, colour_type


def check_json(path: Path) -> dict:
    global CHECKED
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        CHECKED += 1
        return data
    except Exception as exc:
        error(f"Invalid JSON: {path.relative_to(ROOT)}: {exc}")
        return {}


def check_png(path: Path, expected: tuple[int, int] | None = None) -> None:
    global CHECKED
    if not path.is_file():
        error(f"Missing PNG: {path.relative_to(ROOT)}")
        return
    try:
        w, h, colour_type = read_png(path)
        if expected and (w, h) != expected:
            error(f"Wrong PNG size: {path.relative_to(ROOT)} = {w}x{h}, expected {expected[0]}x{expected[1]}")
        if colour_type not in (4, 6):
            error(f"PNG has no alpha channel: {path.relative_to(ROOT)} (colour type {colour_type})")
        CHECKED += 1
    except Exception as exc:
        error(f"Invalid PNG: {path.relative_to(ROOT)}: {exc}")


def sprite_resource(resource: str) -> Path:
    return CONTENT / "sprites" / resource


def data_resource(resource: str) -> Path:
    return CONTENT / "data" / resource


def sound_resource(resource: str) -> Path:
    return CONTENT / "sounds" / resource


mod = check_json(ROOT / "mod.json")
creatures = check_json(CONTENT / "config" / "moonfang" / "creatures.json")
scripts = check_json(CONTENT / "config" / "moonfang" / "scripts.json")

if mod.get("version") != "1.1.0":
    error("mod.json version is not 1.1.0")

for creature_key, creature in creatures.items():
    graphics = creature.get("graphics", {})
    if graphics.get("mapMask") != ["VV", "VA"]:
        error(f"{creature_key}: mapMask is not the expected standard creature mask")

    for field in ("animation", "map"):
        resource = graphics.get(field)
        path = sprite_resource(resource) if resource else Path()
        if not resource or not path.is_file():
            error(f"{creature_key}: missing {field} resource: {resource}")
            continue
        manifest = check_json(path)
        if "basepath" in manifest:
            error(f"{creature_key}: {field} manifest still uses basepath")
        for seq in manifest.get("sequences", []):
            for frame in seq.get("frames", []):
                if "/" not in frame:
                    error(f"{creature_key}: non-explicit frame path: {frame}")
                check_png(sprite_resource(frame))

    for field, size in (("iconLarge", (58, 64)), ("iconSmall", (32, 32))):
        resource = graphics.get(field)
        if not resource:
            error(f"{creature_key}: missing {field}")
        else:
            check_png(data_resource(resource), size)

    for field in ("mapAttackFromLeft", "mapAttackFromRight"):
        resource = graphics.get(field)
        if not resource:
            error(f"{creature_key}: missing {field}")
        else:
            check_png(data_resource(resource), (72, 72))

    ability = creature.get("abilities", {}).get("sameTierLycanthropy", {})
    if ability.get("icon") != "moonfang/shared/lycanthropy_32.png":
        error(f"{creature_key}: wrong or missing Lycanthropy icon")
    else:
        check_png(data_resource(ability["icon"]), (32, 32))

    add_info = ability.get("addInfo", {})
    effect = add_info.get("effectAnimation")
    if not effect:
        error(f"{creature_key}: effectAnimation missing")
    else:
        effect_manifest = check_json(sprite_resource(effect))
        if "basepath" in effect_manifest:
            error("Lycanthropy effect manifest still uses basepath")
        for seq in effect_manifest.get("sequences", []):
            for frame in seq.get("frames", []):
                check_png(sprite_resource(frame), (128, 128))

    effect_sound = add_info.get("effectSound")
    if not effect_sound or not sound_resource(effect_sound).is_file():
        error(f"{creature_key}: missing effectSound: {effect_sound}")

    for sound_key, resource in creature.get("sound", {}).items():
        path = sound_resource(resource)
        if not path.is_file():
            error(f"{creature_key}: missing sound {sound_key}: {resource}")
        else:
            try:
                with wave.open(str(path), "rb") as wav:
                    if wav.getnchannels() not in (1, 2):
                        error(f"Unsupported WAV channels: {path.relative_to(ROOT)}")
                CHECKED += 1
            except Exception as exc:
                error(f"Invalid WAV: {path.relative_to(ROOT)}: {exc}")

lua = (CONTENT / "scripts" / "moonfang" / "sameTierLycanthropy.lua").read_text(encoding="utf-8")
for required in ("showBattleAnimation", "refreshBattleUnits", "creatureLevel", "removeUnit", "addUnit"):
    if required not in lua:
        error(f"Lua script missing expected operation: {required}")

if ERRORS:
    print("Moonfang Werewolves visual validation FAILED")
    for item in ERRORS:
        print(" -", item)
    sys.exit(1)

print(f"Moonfang Werewolves visual validation PASSED ({CHECKED} resources checked)")
