# Moonfang Werewolves 1.1.0 — Visual Repair

This release keeps the already working same-tier Lycanthropy mechanic and repairs the visual resources used by VCMI 1.8 development builds.

## Replace the old version

1. Close VCMI, VCMI Launcher and VCMI Map Editor.
2. Delete the old folder completely:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\moonfang-werewolves`

3. Extract the new `moonfang-werewolves` folder into:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\`

4. Confirm this exact file exists:

   `%USERPROFILE%\Documents\My Games\vcmi\Mods\moonfang-werewolves\mod.json`

5. Open VCMI Launcher and enable **Moonfang Werewolves**.
6. Fully close and reopen Map Editor before checking an existing map.

Do not merge 1.1.0 over the old folder. Delete the old folder first so stale animation manifests cannot remain.

## Repaired

- Battle animations use explicit complete PNG resource paths.
- Adventure-map and Map Editor animations use explicit complete PNG resource paths.
- Both creatures have a standard map mask.
- Large and small icons were rebuilt from the actual sprite art and contain no labels or presentation text.
- Lycanthropy has a correctly sized 32x32 ability icon.
- The transformation VFX manifest was repaired and the combat script now requests that VFX and its sound after a successful conversion.
- Creature IDs, statistics, chance values, target restrictions, sounds and upgrade relationship are unchanged.

## Intentionally unchanged

VCMI currently reports a transformed original stack as removed and a new werewolf stack as created. This can make the victory casualty page show both the original creatures and the transformed werewolves. The conversion logic is otherwise correct, so this release does not risk the working mechanic to alter that bookkeeping.

A surviving neutral army may retain its original adventure-map disguise after defeating the attacker, even though its actual stack has become werewolves. This is left as a harmless werewolf-themed disguise rather than adding fragile adventure-map object mutation code.

See `EDITING_VISUALS.md` for exact asset locations and dimensions.
